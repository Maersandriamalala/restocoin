﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using Windows.UI.Popups;


namespace TropiKaly.Utilitaire
{
    class HttpPost
    {
        public static string error = "error";
        public static string errorNotInternetConnection = "errorNotInternetConnection ";
        public static async Task<string> postData(String uri, String jsonData)
        {
            HttpClient httpClient  = new HttpClient();
            String responseBody = "";
            bool webExeptionError = false;
            bool httRequestError = false;
            
            if (System.Net.NetworkInformation.NetworkInterface.GetIsNetworkAvailable())
            {
                try
                {

                    httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    HttpResponseMessage wcfResponse = await httpClient.PostAsync(uri, new StringContent(jsonData, Encoding.UTF8, "application/json"));
                     responseBody = await wcfResponse.Content.ReadAsStringAsync();

                     if (responseBody.Contains("Service Temporarily Unavailable")) {
                         httRequestError = true;
                         webExeptionError = true;
                         responseBody = error;
                     }

                }
                catch (System.Net.WebException swe) {
                    webExeptionError = true;
                    responseBody = error;
                }
                catch (HttpRequestException hre)
                {
                    httRequestError = true;
                    responseBody = error;
                      
                }
                catch (TaskCanceledException)
                {
                    return responseBody;
                }
                catch (Exception ex)
                {
                    responseBody = error;
                }
                finally
                {

                    if (httpClient != null)
                    {
                        httpClient.Dispose();
                        httpClient = null;
                    }
                   
                }
            }
            else {

                responseBody = errorNotInternetConnection;
            }
            
             return responseBody;
        }
    }
}
