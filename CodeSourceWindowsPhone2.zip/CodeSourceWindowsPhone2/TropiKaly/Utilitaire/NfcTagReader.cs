﻿using NfcReader;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Networking.Proximity;
using Windows.Storage.Streams;

namespace TropiKaly.Utilitaire
{
    class NfcTagReader
    {
        public static string ReadText(ProximityMessage message)
        {
            var output = "";
            List<NdefRecord> recordList = new List<NdefRecord>();
            using (var buf = DataReader.FromBuffer(message.Data))
            {
                NdefRecordUtility.ReadNdefRecord(buf, recordList);

                for (int i = 0, recordNumber = 0, spRecordNumber = 0; i < recordList.Count; i++)
                {
                    NdefRecord record = recordList.ElementAt(i);

                    if (!record.IsSpRecord)
                    {
                        if (System.Text.Encoding.UTF8.GetString(record.Type, 0, record.TypeLength) == "Sp")
                        {
                           
                            continue;
                        }
                        else
                        {
                            recordNumber++;
                           
                        }
                    }
                    else
                    {
                        if (spRecordNumber == 0)
                        {
                            recordNumber++;
                            
                        }

                        spRecordNumber++;
                      
                    }

                

                    string typeName = NdefRecordUtility.GetTypeNameFormat(record);

                    if (record.TypeLength > 0)
                    {
                        
                    }

                    if ((record.Il) && (record.IdLength > 0))
                    {
                       
                    }

                    if ((record.PayloadLength > 0) && (record.Payload != null))
                    {
                        if ((record.Tnf == 0x01)
                            && (System.Text.Encoding.UTF8.GetString(record.Type, 0, record.TypeLength) == "U"))
                        {
                            
                        }
                        else if ((record.Tnf == 0x01)
                            && (System.Text.Encoding.UTF8.GetString(record.Type, 0, record.TypeLength) == "T"))
                        {
                            NdefTextRtd text = new NdefTextRtd();
                         
                            NdefRecordUtility.ReadTextRtd(record, text);
                            output = output + text.Text;
                        }
                        else
                        {
                            if (record.Tnf == 0x01)
                            {
                                
                            }
                        }
                    }

                    if (!record.IsSpRecord)
                    {
                        
                    }
                }
            }

            return output;
        }
    }
}
