﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TropiKaly.Utilitaire
{
    public class LocalSettingUtilitaire
    {
        public static void AjouterValeur(String nomAAjouter,Object o)
        {
            var localSettings = Windows.Storage.ApplicationData.Current.LocalSettings;

            localSettings.Values.Add(nomAAjouter, o);
        }
        public static  void SuprimerValeur(String nomObjet)
        {
            var localSettings = Windows.Storage.ApplicationData.Current.LocalSettings;

            localSettings.Values.Remove(nomObjet);
        }
        public static  bool KeyExist(String nomObjet)
        { 
            var localSettings = Windows.Storage.ApplicationData.Current.LocalSettings;
            var test = localSettings.Values["uidUser"];
            var testBool = localSettings.Values.ContainsKey("uidUser");
            return localSettings.Values[nomObjet]!=null;
        }
        public static String getKeyValue(String keyName){
            var localSettings = Windows.Storage.ApplicationData.Current.LocalSettings;
            var test = localSettings.Values["uidUser"];
            return (String)test;
        }
       
    }
}
