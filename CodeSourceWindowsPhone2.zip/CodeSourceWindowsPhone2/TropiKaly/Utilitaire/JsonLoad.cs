﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using Windows.UI.Xaml;
using System.Net.Http;
using System.Net.NetworkInformation;
using Windows.UI.Popups;


namespace TropiKaly.Utilitaire
{
    public class DownloadCompleteData : EventArgs
    {
        public String data{ get; set; }
    }

    class download_data
    {

        public event EventHandler<DownloadCompleteData> downloadDatacomplete;

        public void get_data(String url)
        {
            DownloadDataAsync(url);
        }


        async void DownloadDataAsync(String url)
        {
           
                try
                {
                    HttpClient client = new HttpClient();
                    Task<string> getStringTask = client.GetStringAsync(url);
                    string urlContents = await getStringTask;

                    DownloadCompleteData data_to_send = new DownloadCompleteData();
                    data_to_send.data = urlContents;

                    DownloadDataCompleteEvent(data_to_send);
                }
                
                catch (Exception) // a more specific exception would be better
                {
                
                }

          
            

        }

        protected virtual void DownloadDataCompleteEvent(DownloadCompleteData e)
        {
            EventHandler<DownloadCompleteData> handler = downloadDatacomplete;
            if (handler != null)
            {
                handler(this, e);
            }
        }

    //class JsonLoad

    //{
    //    private static string jsonText;

    //    public static  async Task<string>  getJsonTextFromUrl(String url) {
    //       return await loadJsonAsync(url);
    //        //return jsonText;
            
    //    }
    //    private static async Task<string> loadJsonAsync(string url)
    //    {
    //        //No exception handling has been performed in the code and should be adjust as per requirements.
    //        HttpClient http = new System.Net.Http.HttpClient();
    //        HttpResponseMessage response = await http.GetAsync(url).ConfigureAwait(false);
    //        return  await response.Content.ReadAsStringAsync();
    //    }

       
    }
}
