﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Media.Imaging;

namespace TropiKaly.Utilitaire
{
    public class WebPathToImage : IValueConverter
    {
        public WebPathToImage() { 
        }
        public object Convert(object value, Type targetType, object parameter, string language)
        {
            if (value == null) return null;
            // the below class you will find in Stephen's answer mentioned above
            return new TaskCompletionNotifier<BitmapImage>(GetImage((String)value));
        }

        public object ConvertBack(object value, Type targetType, object parameter, string language)
        { throw new NotImplementedException(); }

        private async Task<BitmapImage> GetImage(string path)
        {
            HttpClient webCLient = new HttpClient();
            var responseStream = await webCLient.GetStreamAsync(path);
            var memoryStream = new MemoryStream();
            await responseStream.CopyToAsync(memoryStream);
            memoryStream.Position = 0;
            var bitmap = new BitmapImage();
            await bitmap.SetSourceAsync(memoryStream.AsRandomAccessStream());
            return bitmap;
        }
    }
}
