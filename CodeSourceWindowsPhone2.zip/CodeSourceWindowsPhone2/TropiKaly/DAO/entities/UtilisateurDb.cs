﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TropiKaly.DAO.entities
{
    public class UtilisateurDb
    {
         [SQLite.PrimaryKey, SQLite.AutoIncrement]
        public int idUtilisateur { get; set; }
         public String nom { get; set; }
         public String idTagNfc { get; set; } 
        public UtilisateurDb () { 
        
        }
        public  bool  checkIfUserDbExist() {
            using (var dbConn = new SQLiteConnection(App.DB_PATH))
            {
                var existingUser = dbConn.ExecuteScalar<int>("select count(*) from UtilisateurDb where idTagNfc='" + idTagNfc + "'"
                            );
                return existingUser != 0;
            }
            
        }
        public static bool checkIfThereAreUsersInDb()
        {
            using (var dbConn = new SQLiteConnection(App.DB_PATH))
            {
                var existingUser = dbConn.ExecuteScalar<int>("select count(*) from UtilisateurDb"
                            );
                return existingUser != 0;
            }

        }
        public void Insert()
        {
            using (var dbConn = new SQLiteConnection(App.DB_PATH))
            {
               
                    if (!checkIfUserDbExist())
                    {
                        dbConn.RunInTransaction(() =>
                        {
                            dbConn.Insert(this);
                        });
                    }
               
            }
        }
        public static UtilisateurDb getUtitilaeurDbByIdTagNfc(String idTagNfc)
        {
            using (var dbConn = new SQLiteConnection(App.DB_PATH))
            {

                var existingUser = dbConn.Query<UtilisateurDb>("select * from UtilisateurDb where idTagNfc='" +idTagNfc+"'"
                               ).FirstOrDefault();
                return existingUser;
            }
        }
        public static UtilisateurDb getUtilistateurInDb() {
            using (var dbConn = new SQLiteConnection(App.DB_PATH))
            {

                var existingUser = dbConn.Query<UtilisateurDb>("select * from UtilisateurDb"
                               ).FirstOrDefault();
                return existingUser;
            }
        }
    }
}
