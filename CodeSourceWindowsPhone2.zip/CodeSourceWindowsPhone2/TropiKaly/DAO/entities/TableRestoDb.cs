﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TropiKaly.DAO.entities
{
    class TableRestoDb
    {
        public int id_tableResto{ get; set; }
        public int numero { get; set; }
        public string nom { get; set; }
        public string uidDelaTable { get; set; }
        public int nbrPlace { get; set; }

    }
}
