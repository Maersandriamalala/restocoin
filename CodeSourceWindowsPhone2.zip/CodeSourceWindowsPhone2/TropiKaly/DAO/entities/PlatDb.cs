﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Media.Imaging;

namespace TropiKaly.DAO.entities
{
   public  class PlatDb
    {
        [SQLite.PrimaryKey, SQLite.AutoIncrement]
        public int idPlat { get; set; }
        public String nom { get; set; }

        public String image { get; set; }
        public String description { get; set; }
        public Int64 prix { get; set; }
        public Int32 tempsCuisson { get; set; }
       

       // public BitmapImage bitMapImage { get; set; }
        public PlatDb() { 
        
        }
        public PlatDb Insert()
        {
            using (var dbConn = new SQLiteConnection(App.DB_PATH))
            {
                //regarder si cela existe 
              // this.nom= this.nom.Replace("'", "''");
               //this.description = this.description.Replace("'", "''");
                String sql = "select count(*) from PlatDb where nom =? and  prix=? and description=? and tempsCuisson=?";
                SQLiteCommand scmd = dbConn.CreateCommand(sql,new Object[]{nom,prix,description,tempsCuisson});
                var existingPlat = scmd.ExecuteScalar<int>();
                //var existingPlat = dbConn.ExecuteScalar<int>("select count(*) from PlatDb where nom ='" + nom+"' and  prix="+
                //        prix+" and description='"+description+"' and tempsCuisson="+tempsCuisson
                //        );


                    if (existingPlat == 0)
                    {
                        dbConn.RunInTransaction(() =>
                        {
                            dbConn.Insert(this);
                        });
                    }
                    String sqlselect = "select * from PlatDb where nom =? and  prix=? and description=? and tempsCuisson=?";
                    SQLiteCommand scmd2 = dbConn.CreateCommand(sqlselect, new Object[] { nom, prix, description, tempsCuisson });    
                    var test = scmd2.ExecuteQuery<PlatDb>().FirstOrDefault();
                   
                    return scmd2.ExecuteQuery<PlatDb>().FirstOrDefault();
                    //return dbConn.Query<PlatDb>("select * from PlatDb where nom ='" + nom + "' and  prix=" +
                    //    prix + " and description='" + description + "' and tempsCuisson=" + tempsCuisson
                    //           ).FirstOrDefault();

            }
        }
        public static  List<PlatDb> selectAllPlats() {
            using (var dbConn = new SQLiteConnection(App.DB_PATH))
            {
                List<PlatDb> myList = dbConn.Table<PlatDb>().ToList<PlatDb>();

                return myList;
            }
        }
        public static PlatDb getPlatById(int id) {
            using (var dbConn = new SQLiteConnection(App.DB_PATH))
            {
               
                var existingPlat = dbConn.Query<PlatDb>("select * from PlatDb where idPlat=" + id
                               ).FirstOrDefault();
                return existingPlat;
            }
        }
        public static int getMaxIdPlat()
        {
            using (var dbConn = new SQLiteConnection(App.DB_PATH))
            {
                var maxIdPlat = dbConn.ExecuteScalar<int>("select max(idPlat) from PlatDb"
                               );
                return (int)maxIdPlat;
            }
        }
        
    }
}
