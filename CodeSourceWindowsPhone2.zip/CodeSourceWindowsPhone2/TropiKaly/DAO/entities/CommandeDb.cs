﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace TropiKaly.DAO.entities
{
    
    public class CommandeDb
    {
        [SQLite.PrimaryKey, SQLite.AutoIncrement]
        public int idCommande { get; set; }
        public DateTime daty { get; set; }
        public int idPlat { get; set; }
         public bool estPaye { get; set; }
         public bool estPasser { get; set; }
         public int quantite { get; set; }
         public string uidUser { get; set; }
        public CommandeDb() { 
        }
        public CommandeDb(DateTime d,bool espP,int lp)
        {
            this.daty = d;
            this.estPaye = espP;
            this.idPlat = lp ;
            estPasser = false;
        }
        private List<CommandeDb> getCommandeBydaty() {
            using (var dbConn = new SQLiteConnection(App.DB_PATH))
            {
                List<CommandeDb>listCommandes = dbConn.Query<CommandeDb>("select * from CommandeDb where not estPasser").ToList();
                List<CommandeDb> lesCommandes = listCommandes.Where(c => c.daty == this.daty).ToList();

                return lesCommandes  ;
            }                    

        }
        public void Insert()
        {
            using (var dbConn = new SQLiteConnection(App.DB_PATH))
            {
                dbConn.RunInTransaction(() =>
                {
                    dbConn.Insert(this);
                });
            }
        }
        public static List<CommandeDb> ReadCommandes()
        {
            using (var dbConn = new SQLiteConnection(App.DB_PATH))
            {
                List<CommandeDb> myList = dbConn.Table<CommandeDb>().ToList<CommandeDb>();
               
                return myList;
            }
        }
        //set commande passer par la table=true
        public void updateSetEstPasserTrue() {
            using (var dbConn = new SQLiteConnection(App.DB_PATH))
            {
                
               
                //String requete="Update CommandeDb set estPasser= where daty='"+this.daty+"'";
                //dbConn.Execute(requete);
               
                List<CommandeDb> nouveaux = this.getCommandeBydaty();
                foreach (CommandeDb cmd in nouveaux) {
                    cmd.estPasser = true;
                    dbConn.Update(cmd);
                }
                //this.idCommande = nouveau.idCommande;
                //nouveau = this;
                
               
               
            } 
        }
        public static List<CommandeDb> ReadCommandesGroupAndOrderByDateAndIdPlat()
        {
            
            using (var dbConn = new SQLiteConnection(App.DB_PATH))
            {
                List<CommandeDb> myList = dbConn.Query<CommandeDb>("select * from commandeDb  where not estPasser and uidUser='"+TropiKaly.DataModel.Utilisateur.getUidUserInLocalString()+"' order by daty desc"
                              ).ToList();
                
                List<CommandeDb> resultGroupedByIdPlat = myList
            .GroupBy(l => l.idPlat)
            .Select(cl => new CommandeDb
            {
                idPlat = cl.First().idPlat,
                daty = cl.First().daty,
                estPaye=cl.First().estPaye,
                quantite = cl.Sum(l=>l.quantite)
                
               
            }).ToList();


                
                return resultGroupedByIdPlat;
            }
        } 
    }
}
