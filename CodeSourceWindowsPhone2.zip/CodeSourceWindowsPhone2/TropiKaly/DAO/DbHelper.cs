﻿using SQLite;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TropiKaly.DAO.entities;
using Windows.Storage;

namespace TropiKaly.DAO
{
    class DbHelper
    {
        
        SQLiteConnection dbConn;
        String databaseName;
        public DbHelper(String databaseName) {
            this.databaseName = databaseName;
        }
        public void createDatabase() {
            string DB_PATH=Path.Combine(Path.Combine(ApplicationData.Current.LocalFolder.Path, databaseName+".sqlite"));
            //using (var dbConn = new SQLiteConnection(App.DB_PATH))
            //{
               
            //           dbConn.DropTable<CommandeDb>();
            //           dbConn.CreateTable<CommandeDb>();
            //           dbConn.Dispose();
            //           dbConn.Close();
                
            //} 
           // if (!CheckFileExists(databaseName+".sqlite").Result)
            //{
                bool ret=createTables(DB_PATH);
            //}
        }
        //Create Tabble 
        private Boolean createTables(string DB_PATH)
        {
            
               
            try
            {
              
                    using (dbConn = new SQLiteConnection(DB_PATH))
                    {
                        dbConn.CreateTable<CommandeDb>();
                        dbConn.CreateTable<PlatDb>();
                        dbConn.CreateTable<UtilisateurDb>();

                    }
               
                return true;
            }
            catch
            {
                return false;
            }
        }
        private async Task<bool> CheckFileExists(string fileName)
        {
            try
            {
                var store = await Windows.Storage.ApplicationData.Current.LocalFolder.GetFileAsync(fileName);
                return true;
            }
            catch
            {
                return false;
            }
        } 
 
    }
}
