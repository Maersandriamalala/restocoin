﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Data.Json;

namespace TropiKaly.DataModel
{
    public class ReservationTable
    {
        public TableResto tableResto { get; set; }
        public string daty { get; set; }
        public Utilisateur utilisateur { get; set; }
        public ReservationTable() { 
        }

        public static List<ReservationTable > getListReservationFromJson(String json)
        {
            json = json.Insert(0, "{\"Reservations\":");
            json = json.Insert(json.Length, "}");

            //var json = await Utilitaire.JsonLoad.getJsonTextFromUrl(urlJson);
            JsonObject jsonObject = JsonObject.Parse(json);
            JsonArray jsonArray = jsonObject["Reservations"].GetArray();
            List<ReservationTable> ret = new List<ReservationTable>();
            foreach (JsonValue tableRestoValue in jsonArray)
            {
                JsonObject tableObject = tableRestoValue.GetObject();
                ReservationTable reserv = new ReservationTable();
                reserv.daty =tableObject["daty"].ToString();
                TableResto tableResto = new TableResto();
                JsonObject jObjectTable = tableObject["tableResto"].GetObject();
                tableResto.nom = jObjectTable["nom"].GetString();
                tableResto.nbrPlace = Int32.Parse(jObjectTable["nbrPlace"].GetNumber().ToString());
                tableResto.numero=Int32.Parse(jObjectTable["numero"].GetNumber().ToString());
                tableResto.idTagNfc = jObjectTable["idTagNfc"].GetString();
                reserv.tableResto = tableResto;
                ret.Add(reserv);
            }
            return ret;
        }
    }
}
