﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TropiKaly.DAO.entities;

namespace TropiKaly.DataModel
{
    class Commande
    {
        public DateTime daty { get; set; }
        public String datyDisplay
        {
            get
            {
                return "Du " + this.daty.Date.ToString("dd-MM-yyyy");
            }

        } 
        public List<Plat> plats { get; set; }
       public  bool estPaye { get; set; }
        [JsonIgnore]
       public bool estPasser { get; set; }
        public int quantite { get; set; }
        [JsonIgnore]
        public String quantiteDisplay
        {
            get
            {
                if(quantite>1)
                return  this.quantite.ToString()+" plats";
                else
                    return this.quantite.ToString() + " plat";

            }

        }
        public long total { get; set; }
       [JsonIgnore]
        public string totalDisplay
        {
            get
            {
                return "Total : " + this.total.ToString()+"Ar";
            }

        }
        [JsonIgnore]
       public string uidUser { get; set; }
        public Commande() {
            this.plats = new List<Plat>();
        }
        public void addPlatToCommande(Plat p) {
            this.plats.Add(p);
        }
       
        //assigner les quantité de chaque plat
        public void assignerQuantiteDeChaquePlatDeLaCommande() { 
            
        }

        public void insertIntoDb(){
            
            foreach (Plat p in this.plats) {
               
                Plat newPlat = p.insertPlat();
               
                
                CommandeDb cmd = new CommandeDb();
                cmd.uidUser = this.uidUser;
                cmd.uidUser = Utilisateur.getUidUserInLocalString();
                cmd.estPaye = false;
                cmd.daty = this.daty;
                 //retrouver l'id du plat dans le db
                cmd.idPlat = newPlat.idPlat;
                cmd.quantite = this.quantite;
                cmd.estPasser = this.estPasser;
                
                cmd.Insert();
             }
        }
        public void updateSetEstPasserTrue() {

            CommandeDb cmd = new CommandeDb();
            cmd.estPaye = false;
            cmd.daty = this.daty;
            //retrouver l'id du plat dans le db
            cmd.quantite = this.quantite;
            cmd.estPasser = this.estPasser;
            cmd.updateSetEstPasserTrue();
        }
        public static List<Commande> getAllCommandesFromDbGroupedByPlatsAndDate()
        {
            List<Commande> ret = new List<Commande>();
            List<CommandeDb> listCommandeDbGrouped = CommandeDb.ReadCommandesGroupAndOrderByDateAndIdPlat();
            List<int> listIdPlatParDate = new List<int>();
            List<int> listQuantiteParPlat = new List<int>();
            var resultGroupedByDaty = listCommandeDbGrouped
            .GroupBy(l => l.daty)
            .Select(comDb => new 
            {
                //idPlat = cl.First().idPlat,
                listIdPlatParDate=comDb.Select(cm=>cm.idPlat).ToList(),
                listQuantiteParPlat = comDb.Select(cm => cm.quantite).ToList(),
                

                daty = comDb.First().daty,
                estPaye = comDb.First().estPaye,
                quantite = comDb.Sum(s=>s.quantite),
                estPasser=comDb.First().estPasser

            }).ToList();
            Int64 totalPrixCommande = 0;
            foreach (var result in resultGroupedByDaty) {
                Commande cm = new Commande();
                cm.daty = result.daty;
                cm.estPaye = result.estPaye;
                cm.estPasser = result.estPasser;
                cm.quantite = result.quantite;
                int i=0;
                foreach (int vPlat in result.listIdPlatParDate) {
                    
                    Plat p=Plat.getPlatFromDbById(vPlat);
                    if (p != null)
                    {
                        p.quantite = result.listQuantiteParPlat[i];
                        p.prixTotalCommande = p.quantite * p.prix;
                        totalPrixCommande = totalPrixCommande + p.prixTotalCommande;
                        cm.plats.Add(p);
                    }
                    i++;
                }
                cm.total = totalPrixCommande;
               
                ret.Add(cm);
            }
           

            
            return ret;
        }

    }
}
