﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Data.Json;

namespace TropiKaly.DataModel
{
    public class TableResto
    {
        public int numero { get; set; }
        public string nom { get; set; }
        public int nbrPlace { get; set; }
        public String idTagNfc { get; set; }
        public TableResto()
        {
        }
        public TableResto(int num, string n, int nbP,string _idTagNfc) {
            numero = num;
            nom = n;
            nbrPlace = nbP;
            this.idTagNfc = _idTagNfc;
        }
        public static  List<TableResto> getListTableRestoFromJson(String json)
        {
           json= json.Insert(0, "{\"Tables\":");
            json=json.Insert(json.Length, "}");

            //var json = await Utilitaire.JsonLoad.getJsonTextFromUrl(urlJson);
            JsonObject jsonObject = JsonObject.Parse(json);
            JsonArray jsonArray = jsonObject["Tables"].GetArray();
            List<TableResto> ret = new List<TableResto>();
            foreach (JsonValue tableRestoValue in jsonArray)
            {
                JsonObject tableObject = tableRestoValue.GetObject();
                TableResto tabResto=new TableResto(Int32.Parse(tableObject["numero"].GetNumber().ToString()),
                    tableObject["nom"].GetString(),
                    Int32.Parse(tableObject["nbrPlace"].GetNumber().ToString()),
                     tableObject["idTagNfc"].GetString()
                    );
                var test = 2;
              
                ret.Add(tabResto);
            }
            return ret;
        }
    }
}
