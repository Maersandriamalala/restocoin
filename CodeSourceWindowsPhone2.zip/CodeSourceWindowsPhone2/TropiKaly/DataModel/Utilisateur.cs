﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TropiKaly.DAO.entities;
using TropiKaly.Utilitaire;

namespace TropiKaly.DataModel
{
    public class Utilisateur
    {
        public string nom { get; set; }
       
        public string idTagNfc { get; set; }
        [JsonIgnore]
        private string urlCheckUser="http://restonode-maersdev.rhcloud.com/connexionClient";
        private string urlInscrireUser = "http://restonode-maersdev.rhcloud.com/ajoutClient";
        public bool checkIfUserExist() {
            UtilisateurDb userdb = new UtilisateurDb();
            userdb.idTagNfc = idTagNfc;
            userdb.nom = nom;
            return userdb.checkIfUserDbExist();

        }
        public void Insert()
        {
            UtilisateurDb userdb = new UtilisateurDb();
            userdb.idTagNfc = idTagNfc;
            userdb.nom = nom;
            userdb.Insert();
        }
        public Utilisateur getUtitilsateurByIdTagNfc() {
            UtilisateurDb userdb = UtilisateurDb.getUtitilaeurDbByIdTagNfc(this.idTagNfc);
            Utilisateur ret = new Utilisateur();
            ret.idTagNfc = userdb.idTagNfc;
            ret.nom = userdb.nom;
            return ret;
        }
        public static bool checkifThereareUsersInDb() {
            return UtilisateurDb.checkIfThereAreUsersInDb();
        }
        public static Utilisateur getUtilistateurInDb()
        {
            UtilisateurDb userDb = UtilisateurDb.getUtilistateurInDb();
            Utilisateur ret = new Utilisateur();
            ret.idTagNfc = userDb.idTagNfc;
            ret.nom = userDb.nom;
            return ret;
        }
        public void insertUserToLocalSetting() {
            if(!userInLocalSetting())
            LocalSettingUtilitaire.AjouterValeur("uidUser",this.idTagNfc);

        }
        public static  bool userInLocalSetting() {
            return LocalSettingUtilitaire.KeyExist("uidUser");
        }
        public static String getUidUserInLocalString() {
            return LocalSettingUtilitaire.getKeyValue("uidUser");
        }
        public static void removeUserFromLocalSetting() {
            LocalSettingUtilitaire.SuprimerValeur("uidUser");
        }

        //verifier avec le web service si l'utilisateur est enregistrer
        //0 si n'est pas enregisrer
        //1 si enregistrer
        //2 si erreur
        //3 si pas de connection internet
        public async Task<int>  estEnregistrerDansLeServeur() {
            download_data dwl = new download_data();
         
          
                string json = JsonConvert.SerializeObject(this);
                
                String reponseDuPOst=await Utilitaire.HttpPost.postData(urlCheckUser, json);
                if (reponseDuPOst.Contains("nom") && reponseDuPOst.Contains("idTagNfc")) {
                    return 1;
                }
                if (reponseDuPOst == HttpPost.error)
                {
                    return 2;
                }
                if (reponseDuPOst == HttpPost.errorNotInternetConnection) {
                    return 3;
                }
           
            return 0;
        }
        public async Task<int> enregistrerDansLeserveur() {
            

            string json = JsonConvert.SerializeObject(this);
           
          
            String reponseDuPOst = await Utilitaire.HttpPost.postData(urlInscrireUser, json);
            if (reponseDuPOst.Contains("nom") && reponseDuPOst.Contains("idTagNfc"))
            {
                return 1;
            }
            if (reponseDuPOst == HttpPost.error)
            {
                return 2;
            }
            if (reponseDuPOst == HttpPost.errorNotInternetConnection)
            {
                return 3;
            }
            return 0;

        }
       

    }
}
