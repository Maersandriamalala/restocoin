﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TropiKaly.DataModel
{
    class CommandeTable
    {
        public Commande commande { get; set; }
        public DateTime datePassageCommande { get; set; }
        public string id_table { get; set; }
        public TableResto tableResto { get; set; }
        public Utilisateur utilisateur { get; set; }
        public CommandeTable() {
            this.datePassageCommande = DateTime.Now.Date;
        }

    }
}
