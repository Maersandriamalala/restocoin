﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TropiKaly.DAO.entities;
using Windows.Data.Json;
using Windows.UI.Xaml.Media.Imaging;

namespace TropiKaly.DataModel
{
   public  class Plat
    {
       public int idPlat { get; set; }
public String nom   { get;  set; }
       //pour controler si l'on veut afficher une image du web (cas ou il ya une connexion internet)
       //sinon une image par defaut
       [JsonIgnore]
public Object imagePlatObject { get; set; }
public String image { get; set; }
public String description { get; set; }
public Int64 prix { get; set; }
       //necessaire pour la commande
public int quantite { get; set; }
       //prix total par commande
public Int64 prixTotalCommande { get; set; }
       [JsonIgnore]
public String prixTotalCommandeDisplay
{
    get
    {
        return  prixTotalCommande.ToString()+"Ar";
    }

} 
public Int32 tempsCuisson { get; set; }
       [JsonIgnore]
public BitmapImage bitMapImage { get; set; }
public List<Ingredient> ingredients { get; set; }
        private ObservableCollection<Plat> _plats = new ObservableCollection<Plat>();
        
        public Plat() { 
        }

        public Plat(String n, String ima, String d, Int64 p, Int32 tmp, List<Ingredient> li)
        {
            nom = n;
            description = d;
            prix = p;
            tempsCuisson = tmp;
            ingredients = li;
            image=ima;
        }
        public Plat(String n, String ima, String d, Int64 p, Int32 tmp)
        {
            nom = n;
            description = d;
            prix = p;
            tempsCuisson = tmp;
            image=ima;
            
        }
        
        public List<Plat> getListPlatFromJson(String json) {
            json = json.Insert(0, "{\"Plats\":");
            json = json.Insert(json.Length, "}");
            //var json = await Utilitaire.JsonLoad.getJsonTextFromUrl(urlJson);
            JsonObject jsonObject = JsonObject.Parse(json);
            JsonArray jsonArray = jsonObject["Plats"].GetArray();
            List<Plat> ret = new List<Plat>();
            foreach (JsonValue platValue in jsonArray)
            {
                JsonObject platObject = platValue.GetObject();
                Plat plat = new Plat(platObject["nom"].GetString(), platObject["image"].GetString(),
                    platObject["description"].GetString(),
                   long.Parse(platObject["prix"].GetNumber().ToString()),
                    Int32.Parse(platObject["tempsCuisson"].GetNumber().ToString()));
                plat.bitMapImage = new BitmapImage(new Uri(plat.image, UriKind.Absolute));
                ret.Add(plat);
            }
            return ret;
        }
        
       //db
        public static  Plat getPlatFromDbById(int id) {
            PlatDb plD = new PlatDb();
            plD = PlatDb.getPlatById(id);
            if(plD!=null){
            Plat ret = new Plat();
            ret.idPlat = plD.idPlat;
            ret.image = plD.image;
            ret.prix = plD.prix;
            ret.tempsCuisson = plD.tempsCuisson;
            ret.nom = plD.nom;
            ret.description=plD.description;
            return ret;
            }
            return null;
        }
       public Plat insertPlat(){
           PlatDb plD = new PlatDb();
           plD.image = this.image;
           plD.description = this.description;
           plD.nom = this.nom;
           plD.tempsCuisson = this.tempsCuisson;
           plD.prix = this.prix;
           Plat retour = new Plat();
           PlatDb ret= plD.Insert();
           retour.idPlat = ret.idPlat;
           retour.image = ret.image;
           retour.nom = ret.nom;
           retour.prix = ret.prix;
           retour.tempsCuisson = ret.tempsCuisson;
           retour.description = ret.description;
           return retour;
       }
       public static int getMaxIdPlatDb() {
           return PlatDb.getMaxIdPlat();
       }



    }
}
