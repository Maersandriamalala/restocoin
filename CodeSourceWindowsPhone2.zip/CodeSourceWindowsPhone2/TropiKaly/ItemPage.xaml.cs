﻿using TropiKaly.Common;
using TropiKaly.Data;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Windows.Input;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Graphics.Display;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Popups;

// Pour en savoir plus sur le modèle Application Hub, consultez la page http://go.microsoft.com/fwlink/?LinkID=391641

namespace TropiKaly
{
    /// <summary>
    /// Page qui affiche les détails d'un élément appartenant à un groupe.
    /// </summary>
    public sealed partial class ItemPage : Page
    {
        private readonly NavigationHelper navigationHelper;
        private readonly ObservableDictionary defaultViewModel = new ObservableDictionary();

        public ItemPage()
        {
            this.InitializeComponent();

            this.navigationHelper = new NavigationHelper(this);
            this.navigationHelper.LoadState += this.NavigationHelper_LoadState;
            this.navigationHelper.SaveState += this.NavigationHelper_SaveState;
        } 

        /// <summary>
        /// Obtient le <see cref="NavigationHelper"/> associé à ce <see cref="Page"/>.
        /// </summary>
        public NavigationHelper NavigationHelper
        {
            get { return this.navigationHelper; }
        }

        /// <summary>
        /// Obtient le modèle d'affichage pour ce <see cref="Page"/>.
        /// Cela peut être remplacé par un modèle d'affichage fortement typé.
        /// </summary>
        public ObservableDictionary DefaultViewModel
        {
            get { return this.defaultViewModel; }
        }

        /// <summary>
        /// Remplit la page à l'aide du contenu passé lors de la navigation. Tout état enregistré est également
        /// fourni lorsqu'une page est recréée à partir d'une session antérieure.
        /// </summary>
        /// <param name="sender">
        /// La source de l'événement, en général <see cref="NavigationHelper"/>.
        /// </param>
        /// <param name="e">Données d'événement qui fournissent le paramètre de navigation transmis à
        /// <see cref="Frame.Navigate(Type, Object)"/> lors de la requête initiale de cette page et
        /// un dictionnaire d'état conservé par cette page durant une session
        /// antérieure.  L'état n'aura pas la valeur Null lors de la première visite de la page.</param>
        private async void NavigationHelper_LoadState(object sender, LoadStateEventArgs e)
        {
            // TODO: créez un modèle de données approprié pour le domaine posant problème pour remplacer les exemples de données
            var item = await SampleDataSource.GetItemAsync((string)e.NavigationParameter);
            this.DefaultViewModel["Item"] = item;
        }

        /// <summary>
        /// Conserve l'état associé à cette page en cas de suspension de l'application ou de
        /// suppression de la page du cache de navigation.  Les valeurs doivent être conformes aux
        /// exigences en matière de sérialisation de <see cref="SuspensionManager.SessionState"/>.
        /// </summary>
        /// <param name="sender">La source de l'événement, en général <see cref="NavigationHelper"/>.</param>
        /// <param name="e">Données d'événement qui fournissent un dictionnaire vide à remplir à l'aide de l'
        /// état sérialisable.</param>
        private void NavigationHelper_SaveState(object sender, SaveStateEventArgs e)
        {
            // TODO: enregistrer l'état unique de la page ici.
        }

        #region Inscription de NavigationHelper

        /// <summary>
        /// Les méthodes fournies dans cette section sont utilisées simplement pour permettre
        /// NavigationHelper pour répondre aux méthodes de navigation de la page.
        /// <para>
        /// La logique spécifique à la page doit être placée dans les gestionnaires d'événements pour le
        /// <see cref="NavigationHelper.LoadState"/>
        /// et <see cref="NavigationHelper.SaveState"/>.
        /// Le paramètre de navigation est disponible dans la méthode LoadState
        /// en plus de l'état de page conservé durant une session antérieure.
        /// </para>
        /// </summary>
        /// <param name="e">Fournit des données pour les méthodes de navigation et
        /// les gestionnaires d'événements qui ne peuvent pas annuler la requête de navigation.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            this.navigationHelper.OnNavigatedTo(e);
        }

        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            this.navigationHelper.OnNavigatedFrom(e);
        }

        #endregion
        //appBar
        private void appBarHomeClicked(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(HubPage));
        }
        private void seDeconnecter(object sender, RoutedEventArgs e)
        {
            //Message Box.
            MessageDialog msg = new MessageDialog("Voullez vous vraiment vous deconnecter", "Deconnection!");

            //Commands
            msg.Commands.Add(new UICommand("Non", new UICommandInvokedHandler(DeconnectionHandlers)));
            msg.Commands.Add(new UICommand("Oui", new UICommandInvokedHandler(DeconnectionHandlers)));

            msg.ShowAsync();

        }
        public void DeconnectionHandlers(IUICommand commandLabel)
        {
            var Actions = commandLabel.Label;
            switch (Actions)
            {
                //Okay Button.
                case "Non":
                    this.Focus(Windows.UI.Xaml.FocusState.Pointer);
                    break;
                //Quit Button.
                case "Oui":
                    {
                        TropiKaly.DataModel.Utilisateur.removeUserFromLocalSetting();
                        Frame.Navigate(typeof(Login));

                        break;
                    }
                //end.
            }
        }

        private void appBarQuitterClicked(object sender, RoutedEventArgs e)
        {
            //Message Box.
            MessageDialog msg = new MessageDialog("Voullez vous vraiment fermer l'application?");

            //Commands
            msg.Commands.Add(new UICommand("Non", new UICommandInvokedHandler(QuitterHandlers)));
            msg.Commands.Add(new UICommand("Oui", new UICommandInvokedHandler(QuitterHandlers)));

            msg.ShowAsync();

        }
        public void QuitterHandlers(IUICommand commandLabel)
        {
            var Actions = commandLabel.Label;
            switch (Actions)
            {
                //Okay Button.
                case "Non":
                    this.Focus(Windows.UI.Xaml.FocusState.Pointer);
                    break;
                //Quit Button.
                case "Oui":
                    {
                        Application.Current.Exit();
                        break;
                    }
                //end.
            }
        }
        private void appBarContactClicked(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(Contact));
        }
    }
}
