﻿using NfcReader;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using TropiKaly.Common;
using TropiKaly.DataModel;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Networking.Proximity;
using Windows.Storage.Streams;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// Pour en savoir plus sur le modèle d’élément Page vierge, consultez la page http://go.microsoft.com/fwlink/?LinkID=390556

namespace TropiKaly
{
    /// <summary>
    /// Une page vide peut être utilisée seule ou constituer une page de destination au sein d'un frame.
    /// </summary>
    public sealed partial class Login : Page
    {
        private readonly NavigationHelper navigationHelper;
        private readonly ObservableDictionary defaultViewModel = new ObservableDictionary();
        // The list of records 
        private List<NdefRecord> recordList;

        // The subscription ID from ProximityDevice
        private long subscriptionId;

        // ProximityDevice instance
        private ProximityDevice device;
        private TextBox textBoxNom = new TextBox();
        private string textBoxNomText;
       
      
       
     
 

        // The log content which will be filled with the details of each
        // detected NFC tag
        private string logText;
        public Login()
        {
            this.InitializeComponent();
            this.navigationHelper = new NavigationHelper(this);
            this.navigationHelper.LoadState += this.NavigationHelper_LoadState;
            this.navigationHelper.SaveState += this.NavigationHelper_SaveState;
            recordList = new List<NdefRecord>();
            device = ProximityDevice.GetDefault();
    
            device.DeviceArrived += this.DeviceArrived;
            device.DeviceDeparted += this.DeviceDeparted;
            SubscribeForMessage();
        }
       

        public NavigationHelper NavigationHelper
        {
            get { return this.navigationHelper; }
        }

        /// <summary>
        /// Obtient le modèle d'affichage pour ce <see cref="Page"/>.
        /// Cela peut être remplacé par un modèle d'affichage fortement typé.
        /// </summary>
        public ObservableDictionary DefaultViewModel
        {
            get { return this.defaultViewModel; }
        }
        /// <summary>
        /// Remplit la page à l'aide du contenu passé lors de la navigation. Tout état enregistré est également
        /// fourni lorsqu'une page est recréée à partir d'une session antérieure.
        /// </summary>
        /// <param name="sender">
        /// La source de l'événement ; en général <see cref="NavigationHelper"/>
        /// </param>
        /// <param name="e">Données d'événement qui fournissent le paramètre de navigation transmis à
        /// <see cref="Frame.Navigate(Type, Object)"/> lors de la requête initiale de cette page et
        /// un dictionnaire d'état conservé par cette page durant une session
        /// antérieure.  L'état n'aura pas la valeur Null lors de la première visite de la page.</param>
        private async void NavigationHelper_LoadState(object sender, LoadStateEventArgs e)
        {



        }
        private void NavigationHelper_SaveState(object sender, SaveStateEventArgs e)
        {
            // TODO: enregistrer l'état unique de la page ici.
        }
        //NFC Reader
        /// <summary>
        /// Gets called when a detected NFC device is disconnected after arrival.
        /// </summary>
        /// <param name="sender">ProximityDevice instance</param>
        private void DeviceDeparted(ProximityDevice sender)
        {

            logText = logText + "\nLost at " + DateTime.Now.Hour + ":" + DateTime.Now.Minute + ":" + DateTime.Now.Second + "\n";
        }

        /// <summary>
        /// Gets called when a NFC device is detected.
        /// </summary>
        /// <param name="sender">ProximityDevice instance</param>
        private void DeviceArrived(ProximityDevice sender)
        {

            logText = "\nDetected at " + DateTime.Now.Hour + ":" + DateTime.Now.Minute + ":" + DateTime.Now.Second;
           
        }

        /// <summary>
        /// Gets called when a message is received. Updates the UI by adding
        /// the details into the log and scrolling the log if necessary.
        /// Note that subscription for messages needs to be redone.
        /// </summary>
        /// <param name="sender">ProximityDevice instance</param>
        /// <param name="message">A message to be handled.</param>
        private async void MessageReceived(ProximityDevice sender, ProximityMessage message)
        {


            if (device != null)
            {
                device.StopSubscribingForMessage(subscriptionId);
            }
            String uidUser=Utilitaire.NfcTagReader.ReadText(message);
            String nomUtilisateur = "";
            this.Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, () =>
            {
                nomUtilisateur = nomUser.Text;

            }).AsTask().Wait();
            if ( nomUtilisateur.Trim().Length!=0)
            {
                //si l'utilisateur n'est pas encore enregistrer dans la base locale alors on l'enregistre
                Utilisateur utilisateur = new Utilisateur();
                utilisateur.nom = nomUtilisateur;
               
                utilisateur.idTagNfc = uidUser;
                int estEnregistrerServeur = await utilisateur.estEnregistrerDansLeServeur();
                if (estEnregistrerServeur==1)
                {
                    utilisateur.Insert();
                    //on enregistre l'utilisateur dans le localSetting
                    utilisateur.insertUserToLocalSetting();
                    //rediriger ver la page d'acceuil
                    this.Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, () =>
                   {
                       if (!Frame.Navigate(typeof(HubPage)))
                       {
                           throw new Exception("Failed to create initial page");
                       }
                   }).AsTask().Wait();
                }

                else if (estEnregistrerServeur == 0)
                {

                    Windows.UI.Popups.MessageDialog msg = new Windows.UI.Popups.MessageDialog("Veuillez créer un compte");

                    msg.ShowAsync();
                    this.Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, () =>
                    {

                        if (!Frame.Navigate(typeof(Inscription), nomUtilisateur))
                        {
                            throw new Exception("Failed to create initial page");
                        }
                    }).AsTask().Wait();

                }
                else if (estEnregistrerServeur == 2)
                {
                    MessageDialog msgbox = new MessageDialog("Erreur serveur veuillez reesayer plus tard");
                    msgbox.ShowAsync();
                }
                else {
                    MessageDialog msgbox = new MessageDialog("Veuillez activer votre connection internet");
                    msgbox.ShowAsync();
                }
            }

            

        }

        private void creerCompteClicked(object sender, RoutedEventArgs e) {
            if (nomUser.Text.Trim().Length != 0)
            {
                Frame.Navigate(typeof(Inscription), nomUser.Text);
            }
        }

        /// <summary>
        /// Subscribes for NDEF messages. This ensures that we get notified
        /// about the NFC events.
        /// </summary>
        private void SubscribeForMessage()
        {
            if (device != null)
            {
                recordList.Clear();
                subscriptionId = device.SubscribeForMessage("NDEF", MessageReceived);
            }
        }
        private void textBoxNom_Loaded(object sender, RoutedEventArgs e)
        {
            
            
        }
        #region Inscription de NavigationHelper

        /// <summary>
        /// Les méthodes fournies dans cette section sont utilisées simplement pour permettre
        /// NavigationHelper pour répondre aux méthodes de navigation de la page.
        /// <para>
        /// La logique spécifique à la page doit être placée dans les gestionnaires d'événements pour le
        /// <see cref="NavigationHelper.LoadState"/>
        /// et <see cref="NavigationHelper.SaveState"/>.
        /// Le paramètre de navigation est disponible dans la méthode LoadState
        /// en plus de l'état de page conservé durant une session antérieure.
        /// </para>
        /// </summary>
        /// <param name="e">Données d'événement décrivant la manière dont l'utilisateur a accédé à cette page.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            this.navigationHelper.OnNavigatedTo(e);
        }

        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            this.navigationHelper.OnNavigatedFrom(e);
        }

        #endregion

        
       
    }
}
