package adapters;

/**
 * Created by ravelosonkiadisoa on 30/06/2015.
 */
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.List;

import activities.MainActivity;
import fragments.fragmentForDrawer.detail.client.PanierFragment;
import fragments.fragmentForDrawer.detail.employe.TableCommandeFragment;
import kiadi.restaurant.R;
import listeners.BoutonAfficherCommandeTableListener;
import listeners.BoutonMoinsPanierListener;
import listeners.BoutonPlusPanierListener;
import listeners.BoutonRetirerItemListener;
import models.PlatCommande;
import models.Table;
import utilitaires.UtilitaireNombres;
import utilitaires.UtilitaireString;

/**
 * Adapteur d'un élément de la liste des tables sur lesquelles on a passé commande
 */
public class TableItemCardViewAdapter extends RecyclerView.Adapter<TableItemCardViewAdapter.DataObjectHolder>
{
    private static String LOG_TAG = "MyRecyclerViewAdapter";
    private List<Table> mDataset;
    private MainActivity activity;
    private TableCommandeFragment fragmentAppelant;
    private static MyClickListener myClickListener;

    /**
     * The type Data object holder.
     */
    public static class DataObjectHolder extends RecyclerView.ViewHolder implements View.OnClickListener
    {
        /**
         * The Table nom.
         */
        TextView tableNom;
        /**
         * The Table numero.
         */
        TextView tableNumero;
        /**
         * The Table addition.
         */
        TextView tableAddition;
        /**
         * The Card view.
         */
        CardView cardView;

        /**
         * Instantiates a new Data object holder.
         *
         * @param itemView the item view
         */
        public DataObjectHolder(View itemView)
        {
            super(itemView);
            tableNom = (TextView) itemView.findViewById(R.id.tableNom);
            tableNumero = (TextView) itemView.findViewById(R.id.tableNumero);
            tableAddition = (TextView) itemView.findViewById(R.id.tableAddition);
            cardView = (CardView) itemView.findViewById(R.id.card_view);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v)
        {
        }
    }

    /**
     * Sets on item click listener.
     *
     * @param myClickListener the my click listener
     */
    public void setOnItemClickListener(MyClickListener myClickListener) {
        this.myClickListener = myClickListener;
    }

    /**
     * Instantiates a new Table item card view adapter.
     *
     * @param myDataset the my dataset
     * @param activity  the activity
     * @param fragment  the fragment
     */
    public TableItemCardViewAdapter(List<Table> myDataset, MainActivity activity, Fragment fragment)
    {
        this.mDataset = myDataset;
        this.activity = activity;
        this.fragmentAppelant = (TableCommandeFragment)fragment;
    }

    @Override
    public DataObjectHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.table_item_cardview, parent, false);
        DataObjectHolder dataObjectHolder = new DataObjectHolder(view);
        return dataObjectHolder;
    }

    @Override
    public void onBindViewHolder(final DataObjectHolder holder, final int position)
    {

        Table table = mDataset.get(position);
        TextView tableNom = holder.tableNom;
        TextView tableNumero = holder.tableNumero;
        TextView tableAddition = holder.tableAddition;
        String numeroString = "(n°" + table.numero + ")";
        String additionString = UtilitaireNombres.addThousandSeparator(table.addition) + "Ar";
        tableNom.setText(table.nom);
        tableNumero.setText(numeroString);
        tableAddition.setText(additionString);
        holder.cardView.setOnClickListener(new BoutonAfficherCommandeTableListener(activity, table));
    }

    /**
     * Add item.
     *
     * @param dataObj the data obj
     * @param index   the index
     */
    public void addItem(Table dataObj, int index)
    {
        mDataset.add(index, dataObj);
        notifyItemInserted(index);
        notifyItemRangeChanged(index, getItemCount());

    }

    /**
     * Delete item.
     *
     * @param index the index
     */
    public void deleteItem(int index)
    {
        mDataset.remove(index);
        notifyItemRemoved(index);
        notifyItemRangeChanged(index, getItemCount());
        //for(int i = 0; i < mDataset.size(); i ++)
    }

    @Override
    public int getItemCount() {
        return mDataset.size();
    }

    /**
     * The interface My click listener.
     */
    public interface MyClickListener {
        /**
         * On item click.
         *
         * @param position the position
         * @param v        the v
         */
        public void onItemClick(int position, View v);
    }
}