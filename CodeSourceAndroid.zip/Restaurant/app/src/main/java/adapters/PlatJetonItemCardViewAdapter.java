package adapters;

/**
 * Created by ravelosonkiadisoa on 30/06/2015.
 */
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

import activities.MainActivity;
import fragments.fragmentForDrawer.detail.employe.PlatFragment;
import kiadi.restaurant.R;
import models.Plat;
import utilitaires.UtilitaireNombres;

/**
 * Adapteur d'un élément de la liste des plats échangeable contre les jetons
 */
public class PlatJetonItemCardViewAdapter extends RecyclerView.Adapter<PlatJetonItemCardViewAdapter.DataObjectHolder>
{
    private static String LOG_TAG = "MyRecyclerViewAdapter";
    private List<Plat> mDataset;
    /**
     * The Main activity.
     */
    MainActivity mainActivity;
    /**
     * The Fragment.
     */
    PlatFragment fragment;
    private static MyClickListener myClickListener;

    /**
     * The type Data object holder.
     */
    public static class DataObjectHolder extends RecyclerView.ViewHolder implements View.OnClickListener
    {
        /**
         * The Plat name.
         */
        TextView platName;
        /**
         * The Plat ingredient.
         */
        TextView platIngredient;
        /**
         * The Plat prix.
         */
        TextView platPrix;
        /**
         * The Plat temps cuisson.
         */
        TextView platTempsCuisson;
        /**
         * The Card view.
         */
        CardView cardView;
        /**
         * The Img plat.
         */
        ImageView imgPlat;

        /**
         * Instantiates a new Data object holder.
         *
         * @param itemView the item view
         */
        public DataObjectHolder(View itemView)
        {
            super(itemView);
            platName = (TextView) itemView.findViewById(R.id.platName);
            platIngredient = (TextView) itemView.findViewById(R.id.platIngredient);
            platPrix = (TextView) itemView.findViewById(R.id.platPrix);
            platTempsCuisson = (TextView) itemView.findViewById(R.id.platTempsCuisson);
            cardView = (CardView) itemView.findViewById(R.id.card_view);
            imgPlat = (ImageView) itemView.findViewById(R.id.imgPlat);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v){}
    }

    /**
     * Sets on item click listener.
     *
     * @param myClickListener the my click listener
     */
    public void setOnItemClickListener(MyClickListener myClickListener)
    {
        this.myClickListener = myClickListener;
    }

    /**
     * Instantiates a new Plat jeton item card view adapter.
     *
     * @param myDataset the my dataset
     * @param m         the m
     * @param fragment  the fragment
     */
    public PlatJetonItemCardViewAdapter(List<Plat> myDataset, MainActivity m, PlatFragment fragment)
    {
        this.mDataset = myDataset;
        this.mainActivity = m;
        this.fragment = fragment;
    }

    @Override
    public DataObjectHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.plat_item_cardview, parent, false);
        DataObjectHolder dataObjectHolder = new DataObjectHolder(view);
        return dataObjectHolder;
    }

    @Override
    public void onBindViewHolder(DataObjectHolder holder, int position)
    {
        final Plat plat = mDataset.get(position);
        holder.platName.setText(mDataset.get(position).getNom());
        holder.platIngredient.setText(mDataset.get(position).getIngredients());
        String prix = UtilitaireNombres.addThousandSeparator(mDataset.get(position).getPrix()) + " Ar";
        holder.platPrix.setText(prix);
        String tempsCuisson = mDataset.get(position).getTempCuissonMin() + " - " + mDataset.get(position).getTempCuissonMax();
        holder.platTempsCuisson.setText(tempsCuisson);

        Log.d("image", plat.getImage());
        Picasso.with(mainActivity)
                .load(plat.getImage())
                .placeholder(R.drawable.ic_plat_detail) // optional
                .error(R.drawable.ic_plat_detail)         // optional
                .into(holder.imgPlat);
        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                mainActivity.mainActivityManager.displayDetailPlatEchangeableJeton(fragment.valeurJeton, fragment.clientIdTagNfc,plat);
            }
        });
    }

    /**
     * Add item.
     *
     * @param dataObj the data obj
     * @param index   the index
     */
    public void addItem(Plat dataObj, int index) {
        mDataset.add(index, dataObj);
        notifyItemInserted(index);
    }

    /**
     * Delete item.
     *
     * @param index the index
     */
    public void deleteItem(int index) {
        mDataset.remove(index);
        notifyItemRemoved(index);
    }

    @Override
    public int getItemCount() {
        return mDataset.size();
    }

    /**
     * The interface My click listener.
     */
    public interface MyClickListener {
        /**
         * On item click.
         *
         * @param position the position
         * @param v        the v
         */
        public void onItemClick(int position, View v);
    }
}