package adapters;

/**
 * Created by ravelosonkiadisoa on 30/06/2015.
 */
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.List;

import activities.MainActivity;
import fragments.fragmentForDrawer.detail.client.PanierFragment;
import kiadi.restaurant.R;
import listeners.BoutonMoinsPanierListener;
import listeners.BoutonPlusPanierListener;
import listeners.BoutonRetirerItemListener;
import models.PlatCommande;
import utilitaires.UtilitaireNombres;

/**
 * Adapteur d'un élément du panier
 */
public class PanierItemCardviewAdapter extends RecyclerView.Adapter<PanierItemCardviewAdapter.DataObjectHolder>
{
    private static String LOG_TAG = "MyRecyclerViewAdapter";
    private List<PlatCommande> mDataset;
    private MainActivity activity;
    private PanierFragment fragmentAppelant;
    private static MyClickListener myClickListener;

    /**
     * The type Data object holder.
     */
    public static class DataObjectHolder extends RecyclerView.ViewHolder implements View.OnClickListener
    {
        /**
         * The Plat nom.
         */
        TextView platNom;
        /**
         * The Plat quantite.
         */
        EditText platQuantite;
        /**
         * The Plat prix.
         */
        EditText platPrix;
        /**
         * The Btn moins.
         */
        Button btnMoins;
        /**
         * The Btn plus.
         */
        Button btnPlus;
        /**
         * The Btn retirer.
         */
        Button btnRetirer;
        /**
         * The Card view.
         */
        CardView cardView;

        /**
         * Instantiates a new Data object holder.
         *
         * @param itemView the item view
         */
        public DataObjectHolder(View itemView)
        {
            super(itemView);
            platNom = (TextView) itemView.findViewById(R.id.platNom);
            platQuantite = (EditText) itemView.findViewById(R.id.platQuantite);
            platPrix = (EditText) itemView.findViewById(R.id.platPrix);
            btnMoins = (Button) itemView.findViewById(R.id.btnMoins);
            btnPlus = (Button) itemView.findViewById(R.id.btnPlus);
            btnRetirer = (Button) itemView.findViewById(R.id.btnRetirer);
            cardView = (CardView) itemView.findViewById(R.id.card_view);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v)
        {
        }
    }

    /**
     * Sets on item click listener.
     *
     * @param myClickListener the my click listener
     */
    public void setOnItemClickListener(MyClickListener myClickListener) {
        this.myClickListener = myClickListener;
    }

    /**
     * Instantiates a new Panier item cardview adapter.
     *
     * @param myDataset the my dataset
     * @param activity  the activity
     * @param fragment  the fragment
     */
    public PanierItemCardviewAdapter(List<PlatCommande> myDataset, MainActivity activity, Fragment fragment)
    {
        this.mDataset = myDataset;
        this.activity = activity;
        this.fragmentAppelant = (PanierFragment)fragment;
    }

    @Override
    public DataObjectHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.panier_item_cardview, parent, false);
        DataObjectHolder dataObjectHolder = new DataObjectHolder(view);
        return dataObjectHolder;
    }

    @Override
    public void onBindViewHolder(final DataObjectHolder holder, final int position)
    {

        final PlatCommande platC = mDataset.get(position);
        final EditText platQteFinal = holder.platQuantite;
        final EditText platPrixFinal = holder.platPrix;
        holder.platNom.setText(mDataset.get(position).getNom());
        platQteFinal.setText(String.valueOf(mDataset.get(position).getQuantite()));
        float prixInt = mDataset.get(position).getPrix() * mDataset.get(position).getQuantite();
        String prix = UtilitaireNombres.addThousandSeparator(prixInt) + "Ar";
        platPrixFinal.setText(prix);
        holder.btnMoins.setOnClickListener(new BoutonMoinsPanierListener(platQteFinal, platPrixFinal, platC, activity));

        holder.btnPlus.setOnClickListener(new BoutonPlusPanierListener(platQteFinal, platPrixFinal, platC, activity));
        holder.btnRetirer.setOnClickListener(new BoutonRetirerItemListener(activity, this, platC, position));
    }

    /**
     * Add item.
     *
     * @param dataObj the data obj
     * @param index   the index
     */
    public void addItem(PlatCommande dataObj, int index)
    {
        mDataset.add(index, dataObj);
        notifyItemInserted(index);
        notifyItemRangeChanged(index, getItemCount());

    }

    /**
     * Delete item.
     *
     * @param index the index
     */
    public void deleteItem(int index)
    {
        mDataset.remove(index);
        notifyItemRemoved(index);
        notifyItemRangeChanged(index, getItemCount());
        if(getItemCount() == 0)
        {
            fragmentAppelant.refresh();
        }
        //for(int i = 0; i < mDataset.size(); i ++)
    }

    @Override
    public int getItemCount() {
        return mDataset.size();
    }

    /**
     * The interface My click listener.
     */
    public interface MyClickListener {
        /**
         * On item click.
         *
         * @param position the position
         * @param v        the v
         */
        public void onItemClick(int position, View v);
    }
}