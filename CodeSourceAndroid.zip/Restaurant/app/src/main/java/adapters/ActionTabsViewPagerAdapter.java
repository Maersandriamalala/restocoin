package adapters;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import java.util.ArrayList;

import kiadi.restaurant.R;

/**
 * Adapter des onglets
 */
public class ActionTabsViewPagerAdapter extends FragmentPagerAdapter
{
    private ArrayList<Fragment> fragments;

    private static final int positionTabPlat = 0;
    private static final int positionTabEntree = 1;
    private static final int positionTabDessert = 2;
    private static final int positionTabBoisson = 3;
    private static final int positionTabDivers = 4;
    private static Context context;
    private String UI_TAB_PLAT;
    private String UI_TAB_ENTREE;
    private String UI_TAB_DESSERT;
    private String UI_TAB_BOISSON;
    private String UI_TAB_DIVERS;
    private int count = 0;

    /**
     * Instantiates a new Action tabs view pager adapter.
     *
     * @param fm        the fm
     * @param fragments the fragments
     * @param c         the c
     */
    public ActionTabsViewPagerAdapter(FragmentManager fm, ArrayList<Fragment> fragments, Context c)
    {
        super(fm);
        this.fragments = fragments;
        this.context = c;
        this.UI_TAB_PLAT = context.getResources().getString(R.string.tab_item_plats);
        this.UI_TAB_ENTREE = context.getResources().getString(R.string.tab_item_entrees);
        this.UI_TAB_DESSERT = context.getResources().getString(R.string.tab_item_desserts);
        this.UI_TAB_BOISSON = context.getResources().getString(R.string.tab_item_boissons);
        this.UI_TAB_DIVERS = context.getResources().getString(R.string.tab_item_divers);
    }

    public Fragment getItem(int pos)
    {
        return fragments.get(pos);
    }

    public int getCount()
    {
        return fragments.size();
    }

    public CharSequence getPageTitle(int position)
    {
        switch (position)
        {
            case positionTabPlat:
                return UI_TAB_PLAT;
            case positionTabEntree:
                return UI_TAB_ENTREE;
            case positionTabDessert:
                return UI_TAB_DESSERT;
            case positionTabBoisson:
                return UI_TAB_BOISSON;
            case positionTabDivers:
                return UI_TAB_DIVERS;
            default:
                break;
        }
        return null;
    }
}
