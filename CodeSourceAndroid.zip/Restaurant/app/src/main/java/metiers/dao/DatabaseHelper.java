package metiers.dao;

import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Classe permettant d'etablir la connexion à la base de données sqlite
 */
public class DatabaseHelper extends SQLiteOpenHelper
{
    //The Android's default system path of your application database.
    private static String DB_PATH = "data/data/kiadi.restaurant/databases/";
    private static String DB_NAME = "restocoin.db";
    /**
     * The constant TABLE_COMMANDE.
     */
    public static String TABLE_COMMANDE = "commande";
    /**
     * The constant TABLE_COMMANDENOURRITURE.
     */
    public static String TABLE_COMMANDENOURRITURE = "commandeNourriture";
    /**
     * The constant TABLE_INGREDIENT.
     */
    public static String TABLE_INGREDIENT = "ingredient";
    /**
     * The constant TABLE_NOURRITURE.
     */
    public static String TABLE_NOURRITURE = "nourriture";
    /**
     * The constant TABLE_NOURRITUREINGREDIENT.
     */
    public static String TABLE_NOURRITUREINGREDIENT = "nourritureIngredient";
    /**
     * The constant TABLE_TYPEINGREDIENT.
     */
    public static String TABLE_TYPEINGREDIENT = "typeIngredient";
    private final Context context;
    private SQLiteDatabase db;
    private static DatabaseHelper databaseHelper = null;
    // constructor
    private DatabaseHelper(Context context)
    {
        super( context , DB_NAME , null , 1);
        this.context = context;
    }

    /**
     * Gets instance.
     *
     * @param context the context
     * @return the instance
     */
    public static DatabaseHelper getInstance(Context context)
    {
        if(databaseHelper == null)
        {
            databaseHelper = new DatabaseHelper(context);
        }
        return databaseHelper;
    }

    /**
     * Create.
     *
     * @throws IOException the io exception
     */
// Creates a empty database on the system and rewrites it with your own database.
    public void create() throws IOException
    {
        boolean dbExist = checkDataBase();
        if(dbExist)
        {
            //Toast.makeText(context, "db exist", Toast.LENGTH_SHORT).show();
            //do nothing - database already exist
        }
        else
        {
            //Toast.makeText(context, "db doesn't exist", Toast.LENGTH_SHORT).show();
            //Toast.makeText(context, "db doesn't already exist", Toast.LENGTH_SHORT).show();
            //By calling this method and empty database will be created into the default system path
            //of your application so we are gonna be able to overwrite that database with our database.
            this.getReadableDatabase();

            try
            {
                copyDataBase();
            }
            catch (IOException e)
            {
                throw new Error("Error copying database");
            }
        }

    }

    // Check if the database exist to avoid re-copy the data
    private boolean checkDataBase()
    {
        SQLiteDatabase checkDB = null;
        try
        {
            String path = DB_PATH + DB_NAME;

            checkDB = SQLiteDatabase.openDatabase(path, null, SQLiteDatabase.OPEN_READONLY);
        }
        catch(SQLiteException e)
        {
            // database don't exist yet.
            //e.printStackTrace();
        }

        if(checkDB != null)
        {
            checkDB.close();
        }
        return checkDB != null ? true : false;
    }

    // copy your assets db to the new system DB
    private void copyDataBase() throws IOException
    {
        //Open your local db as the input stream
        InputStream myInput = context.getAssets().open(DB_NAME);
        // Path to the just created empty db
        String outFileName = DB_PATH + DB_NAME;
        //Open the empty db as the output stream
        OutputStream myOutput = new FileOutputStream(outFileName);
        //transfer bytes from the inputfile to the outputfile
        byte[] buffer = new byte[1024];
        int length;
        while ((length = myInput.read(buffer))>0){
            myOutput.write(buffer, 0, length);
        }
        //Close the streams
        myOutput.flush();
        myOutput.close();
        myInput.close();
    }

    /**
     * Open boolean.
     *
     * @return the boolean
     */
//Open the database
    public boolean open()
    {
        try
        {
            String myPath = DB_PATH + DB_NAME;
            db = SQLiteDatabase.openDatabase(myPath, null, SQLiteDatabase.OPEN_READWRITE);
            return true;
        }
        catch(SQLException sqle)
        {
            db = null;
            return false;
        }

    }

    @Override
    public synchronized void close()
    {
        if(db != null)
            db.close();

        super.close();

    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }


    //
    // PUBLIC METHODS TO ACCESS DB CONTENT
    //



}