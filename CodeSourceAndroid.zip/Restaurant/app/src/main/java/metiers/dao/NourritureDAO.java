package metiers.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import metiers.mapping.Nourriture;
import models.Plat;

/**
 * Created by ravelosonkiadisoa on 18/03/2016.
 */

/**
 * Classe permettant d'interragire avec la table nourriture dans la base sqlite
 */
public class NourritureDAO
{
    /**
     * The Plat id type.
     */
    public final long plat_idType = 1;
    public final long entree_idType = 2;
    public final long dessert_idType = 3;
    public final long boisson_idType = 4;
    public final long divers_idType = 5;
    private SQLiteDatabase database;
    private String table_name = DatabaseHelper.TABLE_NOURRITURE;
    private DatabaseHelper dbhelper;
    /**
     * The Context.
     */
    Context context;
    // Get locations

    /**
     * Instantiates a new Nourriture dao.
     *
     * @param context the context
     */
    public NourritureDAO(Context context)
    {
        this.context = context;
        dbhelper = DatabaseHelper.getInstance(context);
    }

    /**
     * Open.
     *
     * @throws SQLException the sql exception
     */
    public void open() throws SQLException
    {
        database = dbhelper.getWritableDatabase();
    }

    /**
     * Close.
     */
    public void close()
    {
        dbhelper.close();
    }

    /**
     * Gets list nourriture.
     *
     * @return the list nourriture
     */
    public List<Nourriture> getListNourriture()
    {
        List<Nourriture> listNourriture = null;
        try
        {
            open();
            String query  = "SELECT * FROM " + table_name;
            Cursor cursor  = database.rawQuery(query, null);
            // go over each row, build elements and add it to list
            listNourriture = new LinkedList<Nourriture>();
            if (cursor.moveToFirst())
            {
                do
                {
                    Nourriture nourriture = cursorToNourriture(cursor);
                    listNourriture.add(nourriture);
                }
                while (cursor.moveToNext());
            }
            return listNourriture;
        }
        catch(Exception e)
        {
            throw e;
        }
        finally
        {
            close();
        }
    }

    /**
     * Gets nourriture by id.
     *
     * @param id the id
     * @return the nourriture by id
     */
    public Nourriture getNourritureById(int id) {

        Nourriture ret = null;
        try
        {
            open();
            String query  = "SELECT * FROM " + table_name + " where id= " +id;
            Cursor cursor  = database.rawQuery(query, null);
            cursor.moveToFirst();
            ret = cursorToNourriture(cursor);
            return ret;
        }
        catch(Exception e)
        {
            throw e;
        }
        finally
        {
            close();
        }
    }

    /**
     * Gets nourriture by id type.
     *
     * @param idType the id type
     * @return the nourriture by id type
     */
    public List<Nourriture> getNourritureByIdType(long idType)
    {
        List<Nourriture> listNourriture = null;
        try
        {
            open();
            String query  = "SELECT * FROM " + table_name + " WHERE IDTYPE=" + idType;
            Cursor cursor  = database.rawQuery(query, null);
            // go over each row, build elements and add it to list
            listNourriture = new LinkedList<Nourriture>();
            if (cursor.moveToFirst())
            {
                do
                {
                    Nourriture nourriture = cursorToNourriture(cursor);
                    listNourriture.add(nourriture);
                }
                while (cursor.moveToNext());
            }
            return listNourriture;
        }
        catch(Exception e)
        {
            throw e;
        }
        finally
        {
            close();
        }
    }
    private Nourriture cursorToNourriture(Cursor cursor)
    {
        Nourriture nourriture = new Nourriture();
        nourriture.id = Integer.parseInt(cursor.getString(0));
        nourriture.idType = Integer.parseInt(cursor.getString(1));
        nourriture.nom = cursor.getString(2);
        nourriture.image = cursor.getString(3);
        nourriture.prix = Float.valueOf(cursor.getString(4));
        nourriture.tempsMinCuisson = Integer.parseInt(cursor.getString(5));
        nourriture.tempsMaxCuisson = Integer.parseInt(cursor.getString(6));
        nourriture.description = cursor.getString(9);
        return nourriture;
    }

    /**
     * Gets nourriture avec detail by id.
     *
     * @param id the id
     * @return the nourriture avec detail by id
     */
    public Plat getNourritureAvecDetailById(long id)
    {
        Plat ret = new Plat();
        try
        {
            open();
            String query  = "select n.*, group_concat(i.nom, ', ') as ingredients from nourriture as n inner join nourritureIngredient as ni on n.id=ni.idNourriture inner join ingredient as i on ni.idIngredient=i.id where n.id = " + id;

            Cursor cursor  = database.rawQuery(query, null);

            // go over each row, build elements and add it to list
            if (cursor.moveToFirst())
            {
                do
                {
                    ret.setId(id);
                    ret.setNom(cursor.getString(2));
                    ret.setIngredients(cursor.getString(8));
                    ret.setTempCuissonMin(cursor.getInt(5));
                    ret.setTempCuissonMax(cursor.getInt(6));
                    ret.setPrix(cursor.getFloat(4));
                    ret.setDescription(cursor.getString(7));
                }
                while (cursor.moveToNext());
            }
            return ret;
        }
        catch(Exception e)
        {
            throw e;
        }
        finally
        {
            close();
        }
    }

    /**
     * Gets list all with detail by id type and token value.
     *
     * @param idType      the id type
     * @param valeurJeton the valeur jeton
     * @return the list all with detail by id type and token value
     */
    public List<Plat> getListAllWithDetailByIDTypeAndTokenValue(long idType, float valeurJeton)
    {
        List<Plat> ret = new ArrayList<Plat>();
        try
        {
            open();
            String query = "select n.* from nourriture n where n.idType = " + idType +" and n.prix <= " + valeurJeton + " and n.prix <= 20000";
            Cursor cursor  = database.rawQuery(query, null);
            // go over each row, build elements and add it to list
            boolean firstIncrement = true;
            if (cursor.moveToFirst())
            {
                do
                {
                    ret.add(cursorToPlat2(cursor));
                }
                while (cursor.moveToNext());
            }
            return ret;
        }
        catch(Exception e)
        {
            throw e;
        }
        finally
        {
            close();
        }

    }

    /**
     * Gets list all with detail by id type.
     *
     * @param idType the id type
     * @return the list all with detail by id type
     */
    public List<Plat> getListAllWithDetailByIDType(long idType)
    {
        List<Plat> ret = new ArrayList<Plat>();
        try
        {
            open();
            //String query  = "select n.*, group_concat(i.nom, ', ') as listIngredient from nourriture as n inner join nourritureIngredient as ni on n.id=ni.idNourriture inner join ingredient as i on ni.idIngredient=i.id where n.idType=" + idType + " group by n.id";
            String query = "select n.* from nourriture n where n.idType=" + idType;
            Cursor cursor  = database.rawQuery(query, null);
            // go over each row, build elements and add it to list
            boolean firstIncrement = true;
            if (cursor.moveToFirst())
            {
                do
                {
                    ret.add(cursorToPlat2(cursor));
                }
                while (cursor.moveToNext());
            }
            return ret;
        }
        catch(Exception e)
        {
            throw e;
        }
        finally
        {
            close();
        }

    }

    /**
     * Remplire la base de données.
     *
     * @param listPlat the list plat
     */
    public void remplire(List<models.Plat> listPlat)
    {
        // open the database connection
        open();
        database.beginTransaction();
        long ret = -1;
        try
        {
            for(Plat plat : listPlat)
            {
                ContentValues values = new ContentValues();
                values.put("idType", plat.getIdType());
                values.put("nom", plat.getNom());
                values.put("image", plat.getImage());
                values.put("prix", plat.getPrix());
                values.put("tempsMinCuisson", plat.getTempCuissonMin());
                values.put("tempsMaxCuisson", plat.getTempCuissonMax());
                values.put("idInNode", plat.getIdInNode());
                values.put("ingredients", plat.getIngredients());
                values.put("description", plat.getDescription());
                ret = database.insert("nourriture", null, values);
            }

            database.setTransactionSuccessful();
        }
        catch(Exception e) {
        }
        finally
        {
            database.endTransaction();
            close();
        }
        // I will suggest to keep the connection to the database open when your app is
        // running, the recommended time to close the connection is when your app is
        //going to pause/stop.
    }

    /**
     * Data exist boolean.
     *
     * @return the boolean
     */
    public boolean dataExist()
    {
        boolean ret = false;
        try
        {
            open();
            String query  = "SELECT count(*) FROM " + table_name;
            Cursor cursor  = database.rawQuery(query, null);
            cursor.moveToFirst();
            String nbr = cursor.getString(0);
            if(nbr.compareTo("0") != 0)
                ret = true;
            return ret;
        }
        catch(Exception e)
        {
            throw e;
        }
        finally
        {
            close();
        }
    }

    private static Plat cursorToPlat(Cursor cursor)
    {
        Plat ret = new Plat();
        ret.setId(cursor.getLong(0));
        ret.setNom(cursor.getString(2));
        ret.setIngredients(cursor.getString(7));
        ret.setTempCuissonMin(cursor.getInt(5));
        ret.setTempCuissonMax(cursor.getInt(6));
        ret.setPrix(cursor.getFloat(4));
        return ret;
    }
    private static Plat cursorToPlat2(Cursor cursor)
    {
        Plat ret = new Plat();
        ret.setId(cursor.getLong(0));
        ret.setIdType(cursor.getLong(1));
        ret.setNom(cursor.getString(2));
        ret.setImage(cursor.getString(3));
        ret.setPrix(cursor.getFloat(4));
        ret.setTempCuissonMin(cursor.getInt(5));
        ret.setTempCuissonMax(cursor.getInt(6));
        ret.setIdInNode(cursor.getString(7));
        ret.setIngredients(cursor.getString(8));
        ret.setDescription(cursor.getString(9));
        return ret;
    }
}
