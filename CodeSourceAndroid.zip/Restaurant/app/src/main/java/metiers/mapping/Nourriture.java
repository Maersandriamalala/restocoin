package metiers.mapping;

/**
 * Created by ravelosonkiadisoa on 18/03/2016.
 */

/**
 * Classe de mappage de la table nourriture
 */
public class Nourriture
{
    /**
     * The Id.
     */
    public long id;
    /**
     * The Id type.
     */
    public long idType;
    /**
     * The Nom.
     */
    public String nom;
    /**
     * The Image.
     */
    public String image;
    /**
     * The Prix.
     */
    public float prix;
    /**
     * The Temps min cuisson.
     */
    public int tempsMinCuisson;
    /**
     * The Temps max cuisson.
     */
    public int tempsMaxCuisson;
    /**
     * The Description.
     */
    public String description;

    /**
     * Instantiates a new Nourriture.
     */
    public Nourriture() {
    }
}
