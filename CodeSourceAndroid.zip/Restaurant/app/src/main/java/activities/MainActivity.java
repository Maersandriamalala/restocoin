package activities;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.AssetManager;
import android.net.Uri;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.NfcA;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentManager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Arrays;
import fragments.fragmentDialog.DialogSortie;
import listeners.NavigationItemSelectListener;
import listeners.ProfilImageListener;
import services.CommandeService;
import services.TableService;
import services.UtilisateurService;
import utilitaires.UtilitaireLangue;
import utilitaires.UtilitaireNFC;
import kiadi.restaurant.R;
import utilitaires.UtilitaireUser;
import views.MainActivityManager;

/**
 * The type Main activity.
 */
/*
*MainActivity
*La principale activité dans laquelle tourne l'application
*/
public class MainActivity extends AppCompatActivity
{
    /**
     * The Action bar.
     */
    public View actionBar;
    /**
     * The Utilisateur service.
     */
    public UtilisateurService utilisateurService;
    /**
     * The Table service.
     */
    public TableService tableService;
    /**
     * The Commande service.
     */
    public CommandeService commandeService;
    /**
     * The Asset manager.
     */
    public AssetManager assetManager;
    /**
     * The Waiting dialog.
     */
    public ProgressDialog waitingDialog;
    /**
     * The Tag.
     */
    public String TAG = MainActivity.class.getSimpleName();

    /**
     * The Type client.
     */
    public final String typeClient = "client";
    /**
     * The Type employe.
     */
    public final String typeEmploye = "employe";

    /**
     * The Position fragment.
     */
    public int positionFragment = 0;

    /**
     * The M toolbar.
     */
    public Toolbar mToolbar;
    /**
     * The Bundle.
     */
    public Bundle bundle;
    /**
     * The Inflator.
     */
    public LayoutInflater inflator;
    /**
     * The Profil image listener.
     */
    public ProfilImageListener profilImageListener;
    /**
     * The Builder.
     */
    public AlertDialog.Builder builder;
    /**
     * The Dialog asking for tag.
     */
    public AlertDialog dialogAskingForTag;
    /**
     * The Navigation view.
     */
    public NavigationView navigationView;
    /**
     * The Drawer.
     */
    public DrawerLayout drawer;
    /**
     * The Call intent.
     */
    public Intent callIntent = new Intent(Intent.ACTION_CALL);
    /**
     * The Relative phone call icon layout.
     */
    public RelativeLayout relativePhoneCallIconLayout;
    /**
     * The Title action bar.
     */
    public TextView titleActionBar;
    /**
     * The Relative panier icon layout.
     */
    public RelativeLayout relativePanierIconLayout;
    /**
     * The Username.
     */
    public TextView username;
    /**
     * The Total layout.
     */
    public RelativeLayout totalLayout;
    /**
     * The Profil image.
     */
    public ImageView profilImage;
    /**
     * The Nb item in panier.
     */
    public TextView nbItemInPanier;
    /**
     * The Total in panier.
     */
    public TextView totalInPanier;
    /**
     * The Toggle.
     */
    public ActionBarDrawerToggle toggle;
    /**
     * The constant RESULT_LOAD_IMG.
     */
    public static int RESULT_LOAD_IMG = 1;
    /**
     * The Navigation item select listener.
     */
    public NavigationItemSelectListener navigationItemSelectListener;
    /**
     * The Main activity manager.
     */
    public MainActivityManager mainActivityManager;
    /**
     * The Support fragment manager.
     */
    public FragmentManager supportFragmentManager;
    /**
     * The Img decodable string.
     */
    String imgDecodableString;
    /**
     * The Nfc adapter.
     */
/*NFC*/
    // détection de tag
    public NfcAdapter nfcAdapter = null;
    /*NFC*/

    /**
     * Creation de l'activité et initialisation des variables
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        mainActivityManager = new MainActivityManager(this);
        mainActivityManager.setupLangue();
        setContentView(R.layout.activity_main);
        bundle = savedInstanceState;
        mainActivityManager.initActivity();
        //display the first navigation drawer view on app launch
        if(UtilitaireLangue.checkChange(this))
        {
            mainActivityManager.displayView(mainActivityManager.positionParametre);
        }
        else
            mainActivityManager.displayView(mainActivityManager.positionSplashScreen);
        /**
         * Adapter nfc pour les traitements des tag
         */
        nfcAdapter = NfcAdapter.getDefaultAdapter(getApplicationContext());

        callIntent.setData(Uri.parse("tel:+261330438882"));

    }

    /**
     * Fonction appelé lors d'une detection de tag ou autre provocant le demarrage de l'activité
     * @param intent
     */
    @Override
    public void onNewIntent(Intent intent)
    {
        //Détection d'un périphérique NFC (tag ou autre)
        String action = intent.getAction();
        if (NfcAdapter.ACTION_TAG_DISCOVERED.equals(action) || NfcAdapter.ACTION_NDEF_DISCOVERED.equals(action) || NfcAdapter.ACTION_TECH_DISCOVERED.equals(action))
        {
            resolveIntent(intent);
        }
    }

    /**
     * Fonction utilisée après changement de la photo de profil
     * @param requestCode
     * @param resultCode
     * @param data
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        profilImageListener.onActivityResult(requestCode, resultCode, data);
    }

    /**
     * Creation de l'action bar
     * @param menu
     * @return
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        mainActivityManager.showActionBar();
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int itemId = item.getItemId();
        switch (itemId)
        {
            case android.R.id.home:
                if(drawer.isDrawerOpen(navigationView))
                    drawer.closeDrawer(navigationView);
                else
                    drawer.openDrawer(navigationView);
                break;
            default:
                break;
        }
        return true;
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onRestart()
    {
        super.onRestart();
        mainActivityManager.updateUserProfilView();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mainActivityManager.updateUserProfilView();
        UtilitaireNFC.setupForegroundDispatch(this, nfcAdapter);
    }

    @Override
    protected void onPause() {
        /**
         * Call this before onPause, otherwise an IllegalArgumentException is thrown as well.
         */
        UtilitaireNFC.stopForegroundDispatch(this, nfcAdapter);

        super.onPause();
    }

    /**
     * gestion de la touche retour
     */
    @Override
    public void onBackPressed()
    {
        //on splash screen
        if(drawer.isDrawerOpen(navigationView))
            drawer.closeDrawer(navigationView);
        else if (positionFragment == -2) /*do anything*/ ;

        else if (positionFragment == mainActivityManager.positionCarte || positionFragment == mainActivityManager.positionChoixUser || (supportFragmentManager.getBackStackEntryCount() == 0 && positionFragment == mainActivityManager.positionConnexAuthentification))
        {

            DialogSortie ds = new DialogSortie();
            ds.showDialog(bundle, this);
        }
        else if (positionFragment == mainActivityManager.positionConnexionEmploye || positionFragment == mainActivityManager.positionConnexionClient || positionFragment == mainActivityManager.positionDemandeTag || positionFragment == mainActivityManager.positionPlatJeton) {
            if (supportFragmentManager.getBackStackEntryCount() != 0)
                supportFragmentManager.popBackStack();
        }
        else
        {
            if(UtilitaireUser.getTypeUser(this).compareTo(typeClient) == 0)
                mainActivityManager.displayView(mainActivityManager.positionCarte);
            else if(UtilitaireUser.getTypeUser(this).compareTo(typeEmploye) == 0)
                mainActivityManager.displayViewEmploye(mainActivityManager.positionCommandeEmploye);
        }
    }

    /**
     * Traitement d'un intent s'il contient un tag NFC
     *
     * @param intent the intent
     */
    public void resolveIntent(Intent intent)
    {
        Tag myTag = (Tag) intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
        if (dialogAskingForTag != null && dialogAskingForTag.isShowing())
        {
            dialogAskingForTag.cancel();
            waitingDialog.show();
            tableService.getTableByUID(UtilitaireNFC.bytesToHex(myTag.getId()));
        }
        else if (positionFragment == mainActivityManager.positionDemandeTag)
        {
            waitingDialog.show();
            if(UtilitaireUser.getAction(this).compareTo("connect") == 0)
            {
                utilisateurService.connexionClient(UtilitaireNFC.bytesToHex(myTag.getId()));
            }
            else
            {
                utilisateurService.creerCompteClient(UtilitaireUser.getUser(this).getNom(), UtilitaireNFC.bytesToHex(myTag.getId()));
            }
        }
        else if (positionFragment == mainActivityManager.positionDemandeTagJeton)
        {
            waitingDialog.show();
            utilisateurService.obtenirValeurJetonParIdTagNfc(UtilitaireNFC.bytesToHex(myTag.getId()));
        }
    }

    /**
     * un tag a été détecté, soit il faut écrire, soit il faut lire
     *
     * @param intent the intent
     */
    public void readTag(Intent intent)
    {
        //Lecture
        //Récupération des messages
        Parcelable[] rawMsgs = intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES);
        NdefMessage[] msgs;
        //Les enregistrements peuvent être imbriqués,
        //mais ce n'est pas notre utilisation
        String receivedMessages = "";
        if (rawMsgs != null)
        {
            try
            {
                msgs = new NdefMessage[rawMsgs.length];

                for (int i = 0; i < rawMsgs.length; i++)
                {
                    msgs[i] = (NdefMessage) rawMsgs[i];
                    NdefRecord record = msgs[i].getRecords()[i];
                    byte[] type = "".getBytes();
                    try
                    {
                        //idRec = record.getId();
                        //tnf = record.getTnf();
                        type = record.getType();
                    }
                    catch (Exception e)
                    {
                        // Les infos du tag sont incomplètes
                    }
                    //Message contenu sur le tag sous forme d'URI
                    if (Arrays.equals(type, NdefRecord.RTD_SMART_POSTER) || Arrays.equals(type, NdefRecord.RTD_URI) || Arrays.equals(type, NdefRecord.RTD_TEXT))
                    {
                        String str = new String(record.getPayload());
                        Toast.makeText(this, str, Toast.LENGTH_LONG).show();
                    }
                }
            }
            catch (Exception e)
            {
                // Le contenu du tag est mal formé
                Toast.makeText(this, "NDEF type not managed!..",
                        Toast.LENGTH_LONG).show();
            }
        }
        Toast.makeText(this, receivedMessages, Toast.LENGTH_LONG).show();
        // Affichage dans l'activité TagActivity
    }
    /*NFC*/
}