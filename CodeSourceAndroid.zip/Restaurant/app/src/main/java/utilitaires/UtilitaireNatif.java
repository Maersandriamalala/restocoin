package utilitaires;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

/**
 * Created by ravelosonkiadisoa on 04/04/2016.
 */
public class UtilitaireNatif
{
    /**
     * Make call.
     *
     * @param activity the activity
     */
    public static void makeCall(Activity activity)
    {
        Intent in=new Intent(Intent.ACTION_CALL, Uri.parse("+261330438882"));
        try
        {
            activity.startActivity(in);
        }

        catch (android.content.ActivityNotFoundException ex){
            Toast.makeText(activity, "yourActivity is not founded", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Hide soft keyboard.
     *
     * @param activity the activity
     */
    public static void hideSoftKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity
                .getSystemService(Context.INPUT_METHOD_SERVICE);

        if (imm.isAcceptingText()) {
            //imm.toggleoftInpSut(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);
        } else {
        }
    }
}
