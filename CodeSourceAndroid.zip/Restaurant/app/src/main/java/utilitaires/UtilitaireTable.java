package utilitaires;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;

import models.Table;

/**
 * Created by ravelosonkiadisoa on 13/04/2016.
 */
public class UtilitaireTable
{

    private static Gson gson = new Gson();

    /**
     * Gets table.
     *
     * @param activity the activity
     * @return the table
     */
    public static Table getTable(Activity activity)
    {
        Table ret = null;
        SharedPreferences sp = activity.getPreferences(Context.MODE_PRIVATE);
        if(sp.getString("table", null) != null)
        {
            ret = gson.fromJson(sp.getString("table", null), Table.class);
        }
        else
        {
            ret = new Table();
            SharedPreferences.Editor editor = sp.edit();
            editor.putString("table", gson.toJson(ret));
            editor.commit();
        }
        return ret;
    }

    /**
     * Sets table.
     *
     * @param activity the activity
     * @param table    the table
     */
    public static void setTable(Activity activity, Table table)
    {
        SharedPreferences sp = activity.getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.putString("table", gson.toJson(table));
        editor.commit();
    }

    /**
     * Gets table name.
     *
     * @param activity the activity
     * @return the table name
     */
    public static String getTableName(Activity activity)
    {
        String tableName = "";
        SharedPreferences sp = activity.getPreferences(Context.MODE_PRIVATE);
        if(sp.getString("table", null) != null)
        {
            tableName = (gson.fromJson(sp.getString("table", null), Table.class)).nom;
        }
        return tableName;
    }

    /**
     * Sets table name.
     *
     * @param activity  the activity
     * @param tableName the table name
     */
    public static void setTableName(Activity activity, String tableName)
    {
        Table table = getTable(activity);
        table.nom = tableName;
        setTable(activity, table);
    }

    /**
     * Gets table tag.
     *
     * @param activity the activity
     * @return the table tag
     */
    public static String getTableTag(Activity activity)
    {
        String idTagNfc = "";
        SharedPreferences sp = activity.getPreferences(Context.MODE_PRIVATE);
        if(sp.getString("table", null) != null)
        {
            idTagNfc = (gson.fromJson(sp.getString("table", null), Table.class)).idTagNfc;
        }
        return idTagNfc;
    }

    /**
     * Sets table tag.
     *
     * @param activity the activity
     * @param idTagNfc the id tag nfc
     */
    public static void setTableTag(Activity activity, String idTagNfc)
    {
        Table table = getTable(activity);
        table.idTagNfc = idTagNfc;
        setTable(activity, table);
    }

}
