package utilitaires;

import android.support.design.widget.TabLayout;
import android.support.v7.widget.RecyclerView;

import java.util.List;

import models.Table;

/**
 * Created by ravelosonkiadisoa on 14/04/2016.
 */
public class UtilitaireList
{
    /**
     * Add table unique.
     *
     * @param adapter the adapter
     * @param listT   the list t
     * @param table   the table
     */
    public static void addTableUnique(RecyclerView.Adapter adapter,List<Table> listT, Table table)
    {
        boolean add = true;
        for(Table temp : listT)
        {
            if(temp._id.compareTo(table._id) == 0)
            {
                add = false;
                temp.addition += table.addition;
                break;
            }
        }
        if(add)
        {
            listT.add(table);
            adapter.notifyDataSetChanged();
        }
    }
}
