package utilitaires;

import android.app.Activity;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;

import metiers.dao.NourritureDAO;
import models.Plat;

/**
 * Created by ravelosonkiadisoa on 11/04/2016.
 */
public class UtilitaireDB
{
    /**
     * Data exist boolean.
     *
     * @param activity the activity
     * @return the boolean
     */
    public static boolean dataExist(Activity activity)
    {
        boolean ret = false;
        NourritureDAO ndao = new NourritureDAO(activity);
        return  ndao.dataExist();
    }

    /**
     * Gets id type by categorie.
     *
     * @param categorie the categorie
     * @return the id type by categorie
     */
    public static long getIdTypeByCategorie(String categorie)
    {
        long ret = 0;
        switch (categorie)
        {
            case "Plats":
                ret = 1;
                break;
            case "Entrees":
                ret = 2;
                break;
            case "Desserts":
                ret = 3;
                break;
            case "Boissons":
                ret = 4;
                break;
            case "Divers":
                ret = 5;
                break;
            default:
                break;
        }
        return ret;
    }

    /**
     * Remplire.
     *
     * @param activity the activity
     * @param data     the data
     */
    public static void remplire(Activity activity, JSONArray data)
    {
        if (dataExist(activity)) return;

        NourritureDAO ndao = new NourritureDAO(activity);
        List<Plat> listPlat = new ArrayList<Plat>();

        for (int i = 0; i < data.length(); i++)
        {
            try
            {
                JSONObject object = data.getJSONObject(i);
                long idType = getIdTypeByCategorie(object.getString("categiorie"));
                String nom = URLDecoder.decode(object.getString("nom"), "UTF-8");
                Log.d("nom", nom);
                String description = URLDecoder.decode(object.getString("description"), "UTF-8");
                String image = object.getString("image");
                Log.d("image", image);
                float prix = Float.valueOf(object.getString("prix"));
                int tempsMinCuisson = object.getInt("tempsCuissonMin");
                int tempsMaxCuisson = object.getInt("tempsCuisson");
                String idInNode = object.getString("_id");
                JSONArray ingredientsArray = object.getJSONArray("ingredients");
                String ingredients = "";
                for (int j = 0; j < ingredientsArray.length(); j++)
                {
                    JSONObject ingredient = ingredientsArray.getJSONObject(j);
                    if (j != 0) ingredients += ", ";

                    ingredients += URLDecoder.decode(ingredient.getString("nom"), "UTF-8");
                }
                Plat p = new Plat(idType, idInNode, nom, image, ingredients, tempsMinCuisson, tempsMaxCuisson, prix, description);
                listPlat.add(p);
            }
            catch (Exception a)
            {
                a.printStackTrace();
            }
        }
        ndao.remplire(listPlat);
    }
}
