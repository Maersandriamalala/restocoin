package utilitaires;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import java.util.Locale;

/**
 * Created by ravelosonkiadisoa on 07/04/2016.
 */
public class UtilitaireLangue
{
    /**
     * Gets langue en cours.
     *
     * @param activity the activity
     * @return the langue en cours
     */
    public static String getLangueEnCours(Activity activity)
    {
        String ret = Locale.getDefault().getLanguage();
        SharedPreferences sp = activity.getPreferences(Context.MODE_PRIVATE);
        String lang = sp.getString("langue", null);
        if(lang != null && lang.length() != 0)
            ret = lang;
        return ret;
    }

    /**
     * Sets langue en cours.
     *
     * @param activity the activity
     * @param langue   the langue
     */
    public static void setLangueEnCours(Activity activity, String langue)
    {
        SharedPreferences sp = activity.getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.putString("langue", langue);
        editor.putString("languechange", "yes");
        editor.commit();
    }

    /**
     * Check change boolean.
     *
     * @param activity the activity
     * @return the boolean
     */
    public static boolean checkChange(Activity activity)
    {
        boolean ret = false;
        SharedPreferences sp = activity.getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        String lang = sp.getString("languechange", null);
        if(lang != null && lang.length() != 0)
        {
            ret = true;
            editor.remove("languechange");
            editor.commit();
        }
        return ret;
    }
}
