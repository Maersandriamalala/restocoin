package utilitaires;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * Created by ravelosonkiadisoa on 20/03/2016.
 */
public class UtilitaireDate
{
    /**
     * Gets current date.
     *
     * @return the current date
     */
    public static String getCurrentDate()
    {
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Calendar cal = Calendar.getInstance();
        return dateFormat.format(cal.getTime());
    }

}
