package utilitaires;

import android.app.Activity;
import android.content.Context;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;

/**
 * Created by ravelosonkiadisoa on 17/03/2016.
 */
public class UtilitaireView
{
    /**
     * Convert color drawable drawable.
     *
     * @param resource the resource
     * @param color    the color
     * @param context  the context
     * @return the drawable
     */
    public static Drawable convertColorDrawable(int resource, int color, Context context)
    {
        final Drawable drawable = context.getResources().getDrawable(resource);

        drawable.setColorFilter(color, PorterDuff.Mode.SRC_IN);

        return drawable.mutate();
    }

    /**
     * Gets orientation screen.
     *
     * @param activity the activity
     * @return the orientation screen
     */
    public static int getOrientationScreen(Activity activity)
    {
        return activity.getResources().getConfiguration().orientation;
    }
}
