package utilitaires;

/**
 * Created by ravelosonkiadisoa on 12/04/2016.
 */
public class VariableStatic
{
    /**
     * The constant baseUrl.
     */
    public static final String baseUrl = "http://restonode-maersdev.rhcloud.com/";
    //public static final String baseUrl = "http://192.168.8.103:8082/";
    //public static final String baseUrl = "http://192.168.137.144:8082/";
}
