package utilitaires;

import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;

import activities.MainActivity;

/**
 * Created by ravelosonkiadisoa on 10/04/2016.
 */
public class UtilitaireImage
{
    /**
     * Gets degree rotation to portrait.
     *
     * @param activity the activity
     * @param photoUri the photo uri
     * @return the degree rotation to portrait
     */
    public static int getDegreeRotationToPortrait(MainActivity activity, Uri photoUri)
    {
        Cursor cursor = activity.getContentResolver().query(photoUri,
                new String[] { MediaStore.Images.ImageColumns.ORIENTATION },
                null, null, null);
        try
        {
            if (cursor.moveToFirst())
            {
                return cursor.getInt(0);
            }
            else
            {
                return -1;
            }
        }
        catch (Exception e)
        {

            e.printStackTrace();
            return -1;
        }
        finally
        {
            if(cursor != null && !cursor.isClosed())
            cursor.close();
        }
    }

    /**
     * Rotate bitmap bitmap.
     *
     * @param source the source
     * @param angle  the angle
     * @return the bitmap
     */
    public static Bitmap RotateBitmap(Bitmap source, float angle)
    {
        Matrix matrix = new Matrix();
        matrix.postRotate(angle);
        Bitmap ret = Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(), matrix, true);

        return ret;

    }

    /**
     * Create image file file.
     *
     * @return the file
     */
    public static File createImageFile()
    {
        File imageStorageDir = new File(
                Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_PICTURES)
                , "MyAppPictures");

        if (!imageStorageDir.exists()) {
            imageStorageDir.mkdirs();
        }

        return new File(
                imageStorageDir + File.separator + "IMG_"
                        + String.valueOf(System.currentTimeMillis())
                        + ".jpg");
    }
}
