package utilitaires;

import java.text.DecimalFormat;

/**
 * Created by ravelosonkiadisoa on 16/03/2016.
 */
public class UtilitaireNombres
{
    /**
     * Add thousand separator string.
     *
     * @param number the number
     * @return the string
     */
    public static String addThousandSeparator(float number)
    {
        DecimalFormat myFormatter = new DecimalFormat("###,###.###");
        return myFormatter.format(number);
    }
}