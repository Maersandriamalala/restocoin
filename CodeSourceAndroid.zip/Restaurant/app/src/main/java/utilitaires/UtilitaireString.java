package utilitaires;

import android.text.Html;
import android.util.Log;

import java.io.UnsupportedEncodingException;

/**
 * Created by ravelosonkiadisoa on 11/04/2016.
 */
public class UtilitaireString
{
    /**
     * Fix encoding unicode string.
     *
     * @param response the response
     * @return the string
     */
    public static String fixEncodingUnicode(String response)
    {
        String str = "";
        try {
            str = new String(response.getBytes("ISO-8859-1"), "UTF-8");
        } catch (UnsupportedEncodingException e) {

            e.printStackTrace();
        }

        String decodedStr = Html.fromHtml(str).toString();
        Log.d("ResponseJSON", decodedStr);
        return  decodedStr;
    }

}
