package utilitaires;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import com.google.gson.Gson;
import activities.MainActivity;
import models.Utilisateur;

/**
 * Created by ravelosonkiadisoa on 06/04/2016.
 */
public class UtilitaireUser
{
    private static Gson gson = new Gson();

    /**
     * Gets user name.
     *
     * @param activity the activity
     * @return the user name
     */
    public static String getUserName(Activity activity)
    {
        String ret = "";
        ret = getUser(activity).getNom();
        return ret;
    }

    /**
     * Gets user.
     *
     * @param activity the activity
     * @return the user
     */
    public static Utilisateur getUser(Activity activity)
    {
        Utilisateur ret = null;
        SharedPreferences sp = activity.getPreferences(Context.MODE_PRIVATE);
        if(sp.getString("user", null) != null)
        {
            ret = gson.fromJson(sp.getString("user", null), Utilisateur.class);
        }
        else
        {
            ret = new Utilisateur();
            SharedPreferences.Editor editor = sp.edit();
            editor.putString("user", gson.toJson(ret));
            editor.commit();
        }
        return ret;
    }

    /**
     * Sets user.
     *
     * @param activity the activity
     * @param user     the user
     */
    public static void setUser(Activity activity, Utilisateur user)
    {
        SharedPreferences sp = activity.getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.putString("user", gson.toJson(user));
        editor.commit();
    }

    /**
     * Sets user name.
     *
     * @param activity the activity
     * @param username the username
     */
    public static void setUserName(Activity activity, String username)
    {
        Utilisateur user = getUser(activity);
        user.setNom(username);
        setUser(activity, user);
        ((MainActivity) activity).mainActivityManager.updateUserNameInDrawer(username);
    }

    /**
     * Gets user id.
     *
     * @param activity the activity
     * @return the user id
     */
    public static String getUser_id(Activity activity)
    {
        return getUser(activity).get_id();
    }

    /**
     * Sets user id.
     *
     * @param activity the activity
     * @param _id      the id
     */
    public static void setUser_id(Activity activity, String _id)
    {
        Utilisateur user = getUser(activity);
        user.set_id(_id);
        setUser(activity, user);
    }

    /**
     * Check tag boolean.
     *
     * @param activity the activity
     * @return the boolean
     */
    public static boolean checkTag(Activity activity)
    {
        boolean ret = false;
        SharedPreferences sp = activity.getPreferences(Context.MODE_PRIVATE);
        if (getUser(activity).get_id() != null && getUser(activity).get_id().compareTo("") != 0)
            ret = true;
        return ret;
    }

    /**
     * Vider session.
     *
     * @param activity the activity
     */
    public static void viderSession(Activity activity) {
        SharedPreferences sp = activity.getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.clear();
        editor.commit();
    }

    /**
     * Sets type user.
     *
     * @param activity the activity
     * @param typeUser the type user
     */
    public static void setTypeUser(Activity activity, String typeUser) {
        SharedPreferences sp = activity.getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        try
        {
            editor.putString("typeUser", typeUser);
            editor.commit();
        }
        catch (Exception npe)
        {
            throw npe;
        }
    }

    /**
     * Gets type user.
     *
     * @param activity the activity
     * @return the type user
     */
    public static String getTypeUser(Activity activity)
    {
        String ret = "";
        SharedPreferences sp = activity.getPreferences(Context.MODE_PRIVATE);
        if (sp.getString("typeUser", null) != null)
            ret = sp.getString("typeUser", null);
        return ret;
    }

    /**
     * Sets image uri.
     *
     * @param activity the activity
     * @param uri      the uri
     */
    public static void setImageURI(Activity activity, Uri uri)
    {
        SharedPreferences sp = activity.getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
       try
        {
            editor.putString("profilImageURI", uri.toString());
            editor.commit();
        }
        catch (Exception npe)
        {
            throw npe;
        }
    }

    /**
     * Gets image uri.
     *
     * @param activity the activity
     * @return the image uri
     */
    public static Uri getImageURI(Activity activity)
    {
        Uri ret = null;
        SharedPreferences sp = activity.getPreferences(Context.MODE_PRIVATE);
        if (sp.getString("profilImageURI", null) != null)
        {
            ret = Uri.parse(sp.getString("profilImageURI", null));
        }
        return ret;
    }

    /**
     * Check first run boolean.
     *
     * @param activity the activity
     * @return the boolean
     */
    public static boolean checkFirstRun(Activity activity)
    {
        boolean ret = true;
        SharedPreferences sp = activity.getPreferences(Context.MODE_PRIVATE);
        if (sp.getString("firstRun", null) == null)
        {
            SharedPreferences.Editor editor = sp.edit();
            editor.putString("firstRun", String.valueOf(ret));
            editor.commit();
        }
        else ret = false;
        return ret;
    }

    /**
     * Sets action.
     *
     * @param activity the activity
     * @param action   the action
     */
    public static void setAction(Activity activity, String action)
    {
        SharedPreferences sp = activity.getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.putString("action", action);
        editor.commit();

    }

    /**
     * Gets action.
     *
     * @param activity the activity
     * @return the action
     */
    public static String getAction(Activity activity)
    {
        String ret = "";
        SharedPreferences sp = activity.getPreferences(Context.MODE_PRIVATE);
        ret = sp.getString("action", null);
        return ret;
    }

    /**
     * Sets id tag nfc.
     *
     * @param activity the activity
     * @param idTagNFC the id tag nfc
     */
    public static void setIdTagNFC(Activity activity, String idTagNFC)
    {
        Utilisateur user = getUser(activity);
        user.setIdTagNFC(idTagNFC);
        setUser(activity, user);
    }
}
