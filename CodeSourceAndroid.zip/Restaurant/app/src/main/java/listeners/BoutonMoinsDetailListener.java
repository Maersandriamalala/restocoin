package listeners;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;

/**
 * Created by ravelosonkiadisoa on 08/04/2016.
 */

/**
 * Classe ecouteur du click du bouton moins
 */
public class BoutonMoinsDetailListener implements OnClickListener
{
    private EditText quantite;

    /**
     * Instantiates a new Bouton moins detail listener.
     *
     * @param quantite the quantite
     */
    public BoutonMoinsDetailListener(EditText quantite)
    {
        this.quantite = quantite;

    }
    @Override
    public void onClick(View view)
    {
        if(quantite.getText().toString().compareTo("1") != 0)
        {
            int newQuantite = Integer.valueOf(quantite.getText().toString()) - 1;
            quantite.setText(String.valueOf(newQuantite));
        }
    }
}
