package listeners;

import android.view.View;

import activities.MainActivity;
import adapters.PanierItemCardviewAdapter;
import models.Panier;
import models.PlatCommande;
import utilitaires.UtilitaireNombres;

/**
 * Created by ravelosonkiadisoa on 10/04/2016.
 */
public class BoutonRetirerItemListener implements View.OnClickListener
{
    private PanierItemCardviewAdapter adapter;
    private MainActivity activity;
    private PlatCommande platC;
    private int position;

    /**
     * Instantiates a new Bouton retirer item listener.
     *
     * @param activity the activity
     * @param adapter  the adapter
     * @param platC    the plat c
     * @param position the position
     */
    public BoutonRetirerItemListener(MainActivity activity, PanierItemCardviewAdapter adapter, PlatCommande platC, int position)
    {
        this.adapter = adapter;
        this.activity = activity;
        this.platC = platC;
        this.position = position;
    }
    @Override
    public void onClick(View view)
    {
        adapter.deleteItem(position);
        Panier.deletePlatCommandeFromPanier(activity, platC);
        activity.totalInPanier.setText("Total = " + UtilitaireNombres.addThousandSeparator(Panier.getCommande(activity).getTotal()) + "Ar");
        activity.nbItemInPanier.setText(String.valueOf(Panier.getNbrItemInPanier(activity)));
    }
}
