package listeners;

import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import activities.MainActivity;
import fragments.fragmentForDrawer.detail.ParametreFragment;
import fragments.fragmentForDrawer.detail.client.AproposFragment;
import fragments.fragmentForDrawer.detail.client.CarteFragment;
import fragments.fragmentForDrawer.detail.client.MapFragment;
import fragments.fragmentSplashscreen.SplashScreenFragment;
import kiadi.restaurant.R;

/**
 * Created by ravelosonkiadisoa on 13/04/2016.
 */

/**
 * Classe ecouteur de selection d'un élément du navigationDrawer
 */
public class NavigationItemSelectListener  implements NavigationView.OnNavigationItemSelectedListener
{
    private final int positionCarte = 0;
    private final int positionCommande = 2;
    private final int positionPanier = -1;
    private final int positionMap = 4;
    private final int positionParametre = 5;
    private final int positionApropos = 6;
    private MainActivity activity;

    /**
     * Instantiates a new Navigation item select listener.
     *
     * @param activity the activity
     */
    public NavigationItemSelectListener(MainActivity activity)
    {
        this.activity = activity;
    }
    @Override
    public boolean onNavigationItemSelected(MenuItem item)
    {
        Fragment fragment = null;
        String title = activity.getString(R.string.app_name);
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        switch(id)
        {
            case R.id.nav_liste_commande:
                activity.mainActivityManager.displayViewEmploye(activity.mainActivityManager.positionCommandeEmploye);
                break;
            case R.id.nav_echange_jeton:
                activity.mainActivityManager.displayViewEmploye(activity.mainActivityManager.positionDemandeTagJeton);
                break;
            case R.id.nav_carte:
                activity.positionFragment = positionCarte;
                fragment = new CarteFragment();
                title = activity.getString(R.string.title_carte);
                break;
            case R.id.nav_panier:
                activity.positionFragment = positionPanier;
                activity.mainActivityManager.afficherPanier();
                break;
            case R.id.nav_commande:
                activity.positionFragment = positionCommande;
                activity.mainActivityManager.afficherHitoriqueCommande();
                break;
            case R.id.nav_map_and_contact:
                activity.positionFragment = positionMap;
                fragment = new MapFragment();
                title = activity.getString(R.string.title_contact);
                break;
            case R.id.nav_setting:
                activity.positionFragment = positionParametre;
                fragment = new ParametreFragment();
                title = activity.getString(R.string.title_parametre);
                break;
            case R.id.nav_about:
                activity.positionFragment = positionApropos;
                fragment = new AproposFragment();
                title = activity.getString(R.string.title_apropos);
                break;

            case R.id.nav_logout:
                activity.mainActivityManager.logout();
                break;
            default:
                break;
        }
        DrawerLayout drawer = (DrawerLayout) activity.findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        activity.mainActivityManager.changeFragment(fragment, title);
        item.setChecked(true);
        return true;
    }

}
