package listeners;

import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import activities.MainActivity;
import kiadi.restaurant.R;
import models.Panier;
import models.Plat;
import models.PlatCommande;

/**
 * Created by ravelosonkiadisoa on 08/04/2016.
 */

/**
 * Classe ecouteur du click du bouton pour ajouter quelque chose dans le panier
 */
public class BoutonAjoutPanierListener implements View.OnClickListener
{
    private EditText quantite;
    private MainActivity activity;
    private Plat plat;

    /**
     * Instantiates a new Bouton ajout panier listener.
     *
     * @param quantite the quantite
     * @param activity the activity
     * @param plat     the plat
     */
    public BoutonAjoutPanierListener(EditText quantite, MainActivity activity, Plat plat)
    {
        this.quantite = quantite;
        this.activity = activity;
        this.plat = plat;
    }
    @Override
    public void onClick(View view)
    {
        if (quantite.getText().toString().compareTo("0") != 0)
        {
            Panier.ajouterAuPanier(activity, new PlatCommande(plat.getId(),plat.getNom(), Integer.valueOf(quantite.getText().toString()),plat.getImage(), plat.getDescription(), plat.getPrix(), plat.getPrix()*Integer.valueOf(quantite.getText().toString()), plat.getTempCuissonMax(), plat.getIngredients()));
            activity.nbItemInPanier.setText(String.valueOf(Panier.getNbrItemInPanier(activity)));
            activity.mainActivityManager.displayView(0);
            Toast.makeText(activity, activity.getResources().getString(R.string.ajouter_panier_succes), Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(activity, "Le nombre du produit doit être supérieur à 0", Toast.LENGTH_LONG).show();
        }
    }
}
