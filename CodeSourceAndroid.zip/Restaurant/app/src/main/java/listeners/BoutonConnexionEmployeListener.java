package listeners;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;

import activities.MainActivity;
import kiadi.restaurant.R;
import services.UtilisateurService;
import utilitaires.UtilitaireUser;

/**
 * Created by ravelosonkiadisoa on 10/04/2016.
 */

/**
 * Classe ecouteur du click du bouton de connexion d'un employe
 */
public class BoutonConnexionEmployeListener implements OnClickListener
{
    private EditText username;
    private EditText password;
    private MainActivity activity;

    /**
     * Instantiates a new Bouton connexion employe listener.
     *
     * @param activity the activity
     * @param username the username
     * @param password the password
     */
    public BoutonConnexionEmployeListener(MainActivity activity, EditText username, EditText password)
    {
        this.activity = activity;
        this.username = username;
        this.password = password;
    }
    @Override
    public void onClick(View view) {
        if(username.getText().length() != 0 && password.getText().length() != 0)
        {
            UtilitaireUser.setUserName(activity, username.getText().toString().trim());
            activity.waitingDialog.show();
            activity.utilisateurService.connexionEmploye(username.getText().toString(), password.getText().toString());
            //activity.displayView(0);

        }
        else
        {
            if(username.getText().length() == 0)
                username.setError(activity.getResources().getString(R.string.champ_error));
            if(password.getText().length() == 0)
                password.setError(activity.getResources().getString(R.string.champ_error));
        }
    }
}
