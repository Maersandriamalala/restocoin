package listeners;

import android.view.View;
import android.widget.EditText;

import activities.MainActivity;
import kiadi.restaurant.R;
import utilitaires.UtilitaireNatif;
import utilitaires.UtilitaireUser;

/**
 * Created by ravelosonkiadisoa on 10/04/2016.
 */

/**
 * Classe ecouteur du click du bouton creation de compte client
 */
public class BoutonCreerCompteListener implements View.OnClickListener
{
    private MainActivity activity;
    private EditText nom;
    private boolean keyboardShown = false;

    /**
     * Instantiates a new Bouton creer compte listener.
     *
     * @param activity the activity
     * @param nom      the nom
     */
    public BoutonCreerCompteListener(MainActivity activity, EditText nom)
    {
        this.activity = activity;
        this.nom = nom;
    }
    @Override
    public void onClick(View view)
    {
        UtilitaireNatif.hideSoftKeyboard(activity);
        if(nom.getText().length() == 0)
        {
            nom.setError(activity.getResources().getString(R.string.nom_error));
            return;
        }
        UtilitaireUser.setUserName(activity, nom.getText().toString());
        UtilitaireUser.setAction(activity, "create");
        activity.mainActivityManager.afficherAuthentification(13);
        activity.mainActivityManager.positionConnexAuthentification = 13;
    }
}
