package listeners;

import android.content.DialogInterface;
import android.view.View;
import android.widget.RadioGroup;

import activities.MainActivity;
import services.CommandeService;

/**
 * Created by ravelosonkiadisoa on 10/04/2016.
 */

/**
 * Classe ecouteur du click du bouton positif dans le dialog de choix de préférence de service
 */
public class BoutonPositifDialogPreferenceListener implements DialogInterface.OnClickListener
{
    private MainActivity activity;
    private RadioGroup radioGroup;
    private View rootView;

    /**
     * Instantiates a new Bouton positif dialog preference listener.
     *
     * @param activity   the activity
     * @param radioGroup the radio group
     * @param rootView   the root view
     */
    public BoutonPositifDialogPreferenceListener(MainActivity activity, RadioGroup radioGroup, View rootView)
    {
        this.activity = activity;
        this.radioGroup = radioGroup;
        this.rootView = rootView;
    }
    @Override
    public void onClick(DialogInterface dialogInterface, int i)
    {
        int index = radioGroup.indexOfChild(rootView.findViewById(radioGroup.getCheckedRadioButtonId()));

        CommandeService commandeService = new CommandeService(activity);
        commandeService.ajouterCommande();
    }
}
