package listeners;

import android.view.View;

import activities.MainActivity;
import utilitaires.UtilitaireNatif;
import utilitaires.UtilitaireUser;

/**
 * Created by ravelosonkiadisoa on 10/04/2016.
 */

/**
 * Classe ecouteur du click du texte demandant la connexion
 */
public class TextJePossedeDejaListener implements View.OnClickListener
{
    private MainActivity activity;

    /**
     * Instantiates a new Text je possede deja listener.
     *
     * @param activity the activity
     */
    public TextJePossedeDejaListener(MainActivity activity)
    {
        this.activity = activity;
    }
    @Override
    public void onClick(View view)
    {
        UtilitaireNatif.hideSoftKeyboard(activity);
        UtilitaireUser.setAction(activity, "connect");
        activity.mainActivityManager.positionConnexAuthentification = 13;
        activity.mainActivityManager.afficherAuthentification(13);
    }
}
