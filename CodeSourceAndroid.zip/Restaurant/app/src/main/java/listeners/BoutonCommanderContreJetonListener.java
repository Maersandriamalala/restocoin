package listeners;

import android.view.View;
import android.widget.Toast;

import activities.MainActivity;
import fragments.fragmentForDrawer.detail.employe.DetailPlatEchangeFragment;

/**
 * Created by ravelosonkiadisoa on 16/04/2016.
 */

/**
 * Classe ecouteur du click du bouton pour commander contre un jeton
 */
public class BoutonCommanderContreJetonListener implements View.OnClickListener
{
    private DetailPlatEchangeFragment fragment;
    private MainActivity activity;

    /**
     * Instantiates a new Bouton commander contre jeton listener.
     *
     * @param fragment the fragment
     * @param activity the activity
     */
    public BoutonCommanderContreJetonListener(DetailPlatEchangeFragment fragment, MainActivity activity)
    {
        this.fragment = fragment;
        this.activity = activity;
    }
    @Override
    public void onClick(View view)
    {
        activity.commandeService.echangerJetonPlat(fragment);
    }
}
