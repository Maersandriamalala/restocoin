package listeners;

import android.view.View;

import activities.MainActivity;

/**
 * Created by ravelosonkiadisoa on 10/04/2016.
 */

/**
 * Classe ecouteur du click du bouton afficher panier du client
 */
public class BoutonAfficherPanierListener implements View.OnClickListener
{
    private MainActivity activity;

    /**
     * Instantiates a new Bouton afficher panier listener.
     *
     * @param activity the activity
     */
    public BoutonAfficherPanierListener(MainActivity activity)
    {
        this.activity = activity;
    }
    @Override
    public void onClick(View view)
    {
        activity.mainActivityManager.afficherPanier();
    }
}
