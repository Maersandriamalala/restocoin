package listeners;

import android.view.View;

import activities.MainActivity;
import models.Table;

/**
 * Created by ravelosonkiadisoa on 14/04/2016.
 */

/**
 * Classe ecouteur du click du bouton afficher commande par table
 */
public class BoutonAfficherCommandeTableListener implements View.OnClickListener
{
    private MainActivity activity;
    private Table table;

    /**
     * Instantiates a new Bouton afficher commande table listener.
     *
     * @param activity the activity
     * @param table    the table
     */
    public BoutonAfficherCommandeTableListener(MainActivity activity, Table table)
    {
        this.activity = activity;
        this.table = table;
    }
    @Override
    public void onClick(View view)
    {
        activity.mainActivityManager.afficherCommandeParTable(table);
    }
}
