package listeners;

import android.view.View;

import activities.MainActivity;
import utilitaires.UtilitaireUser;

/**
 * Created by ravelosonkiadisoa on 08/04/2016.
 */

/**
 * Classe ecouteur du click du bouton dans le choix du type d'utilisateur
 */
public class BoutonChoixTypeUserListener implements View.OnClickListener
{
    private String typeUser;
    private int positionFragment;
    private MainActivity activity;

    /**
     * Instantiates a new Bouton choix type user listener.
     *
     * @param typeUser         the type user
     * @param positionFragment the position fragment
     * @param activity         the activity
     */
    public BoutonChoixTypeUserListener(String typeUser, int positionFragment, MainActivity activity)
    {
        this.typeUser = typeUser;
        this.positionFragment = positionFragment;
        this.activity = activity;
    }
    @Override
    public void onClick(View view)
    {
        UtilitaireUser.setTypeUser(activity, typeUser);
        activity.mainActivityManager.positionConnexAuthentification = positionFragment;
        activity.mainActivityManager.afficherAuthentification(positionFragment);
        activity.mainActivityManager.refreshDrawer();
    }
}
