package listeners;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.view.View;

import activities.MainActivity;
import utilitaires.UtilitaireImage;
import utilitaires.UtilitaireUser;

/**
 * Created by ravelosonkiadisoa on 10/04/2016.
 */

/**
 * Classe ecouteur du click de l'image de profil
 */
public class ProfilImageListener implements View.OnClickListener
{

    /**
     * The constant RESULT_LOAD_IMG.
     */
    public static int RESULT_LOAD_IMG = 1;
    /**
     * The Img decodable string.
     */
    String imgDecodableString;
    private Uri capturedImageURI;
    private MainActivity activity;

    /**
     * Instantiates a new Profil image listener.
     *
     * @param activity the activity
     */
    public ProfilImageListener(MainActivity activity)
    {
        this.activity = activity;
    }

    @Override
    public void onClick(View view)
    {
        // Create intent to Open Image applications like Gallery, Google Photos
        capturedImageURI = Uri.fromFile(UtilitaireImage.createImageFile());
        final Intent captureIntent = new Intent(
                android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        captureIntent.putExtra(MediaStore.EXTRA_OUTPUT, capturedImageURI);
        Intent chooserIntent = Intent.createChooser(new Intent(Intent.ACTION_PICK).setType("image/*"), "Select Picture");
        chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Parcelable[]{captureIntent});
        activity.startActivityForResult(chooserIntent, 42);
    }

    /**
     * On activity result.
     *
     * @param requestCode the request code
     * @param resultCode  the result code
     * @param data        the data
     */
    public void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        if (resultCode == Activity.RESULT_OK)
        {
            if (data != null)
            {
                capturedImageURI = data.getData();
                UtilitaireUser.setImageURI(activity, capturedImageURI);
            }
            activity.profilImage.setImageURI(capturedImageURI);

            //Bitmap bm = ((BitmapDrawable) activity.profilImage.getDrawable()).getBitmap();

            //activity.profilImage.setImageBitmap(UtilitaireImage.RotateBitmap(bm, UtilitaireImage.getDegreeRotationToPortrait(activity, capturedImageURI)));
        }
    }

}
