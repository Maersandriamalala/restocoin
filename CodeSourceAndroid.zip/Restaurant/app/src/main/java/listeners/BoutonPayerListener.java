package listeners;

import android.view.View;

import activities.MainActivity;
import fragments.fragmentForDrawer.detail.employe.CommandeFragment;
import models.Table;

/**
 * Created by ravelosonkiadisoa on 14/04/2016.
 */

/**
 * Classe ecouteur du click du bouton pour valider le paiement d'un client
 */
public class BoutonPayerListener implements View.OnClickListener
{
    private CommandeFragment fragment;
    private MainActivity activity;

    /**
     * Instantiates a new Bouton payer listener.
     *
     * @param activity the activity
     * @param fragment the fragment
     */
    public BoutonPayerListener(MainActivity activity, CommandeFragment fragment)
    {
        this.activity = activity;
        this.fragment = fragment;
    }
    @Override
    public void onClick(View view)
    {
        activity.commandeService.payerCommandeTable(fragment);
    }
}
