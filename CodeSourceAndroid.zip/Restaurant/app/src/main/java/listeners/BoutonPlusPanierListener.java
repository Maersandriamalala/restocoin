package listeners;

import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import activities.MainActivity;
import kiadi.restaurant.R;
import models.Panier;
import models.PlatCommande;
import utilitaires.UtilitaireNombres;

/**
 * Created by ravelosonkiadisoa on 08/04/2016.
 */

/**
 * Classe ecouteur du click du bouton plus dans le panier
 */
public class BoutonPlusPanierListener implements View.OnClickListener
{
    private EditText platQteFinal;
    private EditText platPrixFinal;
    private PlatCommande platC;
    private MainActivity activity;

    /**
     * Instantiates a new Bouton plus panier listener.
     *
     * @param platQteFinal  the plat qte final
     * @param platPrixFinal the plat prix final
     * @param platC         the plat c
     * @param activity      the activity
     */
    public BoutonPlusPanierListener(EditText platQteFinal, EditText platPrixFinal, PlatCommande platC, MainActivity activity)
    {
        this.platQteFinal = platQteFinal;
        this.platPrixFinal = platPrixFinal;
        this.platC = platC;
        this.activity = activity;
    }
    @Override
    public void onClick(View view)
    {
        if (platQteFinal.getText().toString().compareTo("10") != 0)
        {
            int newQuantite = Integer.valueOf(platQteFinal.getText().toString()) + 1;
            platC.setQuantite(newQuantite);
            Panier.setQuantitePlatCommande(activity, platC);
            ((TextView)activity.actionBar.findViewById(R.id.totalText)).setText("Total = " + UtilitaireNombres.addThousandSeparator(Panier.getCommande(activity).getTotal()) + "Ar");
            ((TextView)((MainActivity) activity).actionBar.findViewById(R.id.nbrItemPanier)).setText(String.valueOf(Panier.getNbrItemInPanier(activity)));
            platQteFinal.setText(String.valueOf(newQuantite));
            float newPrix = newQuantite * platC.getPrix();
            String prix = UtilitaireNombres.addThousandSeparator(newPrix)+"Ar";
            platPrixFinal.setText(prix);
        }
    }
}
