package listeners;

import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import activities.MainActivity;
import fragments.fragmentDialog.AskingPreferenceFragment;
import models.Table;
import services.CommandeService;
import utilitaires.UtilitaireTable;

/**
 * Created by ravelosonkiadisoa on 08/04/2016.
 */

/**
 * Classe ecouteur du click du bouton pour passer commande
 */
public class BoutonPasserCommandeListener implements View.OnClickListener
{
    private RecyclerView.Adapter mAdapter;
    private MainActivity activity;
    private Bundle bundle;

    /**
     * Instantiates a new Bouton passer commande listener.
     *
     * @param mAdapter the m adapter
     * @param activity the activity
     * @param bundle   the bundle
     */
    public BoutonPasserCommandeListener(RecyclerView.Adapter mAdapter, MainActivity activity, Bundle bundle)
    {
        this.mAdapter = mAdapter;
        this.activity = activity;
        this.bundle = bundle;
    }
    @Override
    public void onClick(View view)
    {
        Table t = UtilitaireTable.getTable(activity);
        if(t.nom != null && t.nom.compareTo("")!=0)
        {
            if(mAdapter.getItemCount() == 1)
            {
                CommandeService commandeService = new CommandeService(activity);
                commandeService.ajouterCommande();
            }
            else
            {
                AskingPreferenceFragment apf = new AskingPreferenceFragment();

                apf.showDialog(bundle, activity);
            }
        }
        else
        {
            activity.mainActivityManager.showDialogAskingForTableTag();
        }

    }
}
