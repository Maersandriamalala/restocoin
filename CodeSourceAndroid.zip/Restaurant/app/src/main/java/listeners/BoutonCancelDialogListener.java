package listeners;

import android.content.DialogInterface;

import activities.MainActivity;

/**
 * Created by ravelosonkiadisoa on 10/04/2016.
 */

/**
 * Classe ecouteur du click du bouton annuler d'un fragmentdialog
 */
public class BoutonCancelDialogListener implements DialogInterface.OnClickListener
{
    private MainActivity activity;

    /**
     * Instantiates a new Bouton cancel dialog listener.
     *
     * @param activity the activity
     */
    public BoutonCancelDialogListener(MainActivity activity)
    {
        this.activity = activity;
    }
    @Override
    public void onClick(DialogInterface dialogInterface, int i)
    {
        if(activity.waitingDialog.isShowing()) activity.waitingDialog.dismiss();
        dialogInterface.cancel();
    }
}
