package listeners;

import android.content.Intent;
import android.view.View;

import activities.MainActivity;

/**
 * Created by ravelosonkiadisoa on 10/04/2016.
 */

/**
 * Classe ecouteur du click du bouton pour appeler
 */
public class BoutonPhoneCallListener implements View.OnClickListener
{
    private MainActivity activity;
    private Intent callIntent;

    /**
     * Instantiates a new Bouton phone call listener.
     *
     * @param activity   the activity
     * @param callIntent the call intent
     */
    public BoutonPhoneCallListener(MainActivity activity, Intent callIntent)
    {
        this.activity = activity;
        this.callIntent = callIntent;
    }
    @Override
    public void onClick(View view)
    {
        activity.startActivity(callIntent);
    }
}
