package listeners;

import android.content.DialogInterface;

import activities.MainActivity;

/**
 * Created by ravelosonkiadisoa on 10/04/2016.
 */

/**
 * Classe ecouteur du click du bouton pour fermer une activité
 */
public class BoutonFinishActivityListener implements DialogInterface.OnClickListener
{

    private MainActivity activity;

    /**
     * Instantiates a new Bouton finish activity listener.
     *
     * @param activity the activity
     */
    public BoutonFinishActivityListener(MainActivity activity)
    {
        this.activity = activity;
    }
    @Override
    public void onClick(DialogInterface dialogInterface, int i)
    {
        activity.finish();
    }
}
