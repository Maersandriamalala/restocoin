package views;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.Locale;

import activities.MainActivity;
import fragments.fragmentAuthentification.ChoixTypeUserFragment;
import fragments.fragmentAuthentification.ConnexionClientFragment;
import fragments.fragmentAuthentification.ConnexionEmployeFragment;
import fragments.fragmentAuthentification.DemandeTagFragment;
import fragments.fragmentForDrawer.detail.ParametreFragment;
import fragments.fragmentForDrawer.detail.client.CarteFragment;
import fragments.fragmentForDrawer.detail.client.CommandeFragment;
import fragments.fragmentForDrawer.detail.client.ContactFragment;
import fragments.fragmentForDrawer.detail.client.DetailPlatFragment;
import fragments.fragmentForDrawer.detail.client.PanierFragment;
import fragments.fragmentForDrawer.detail.employe.TableCommandeFragment;
import fragments.fragmentSplashscreen.SplashScreenFragment;
import kiadi.restaurant.R;
import listeners.BoutonAfficherPanierListener;
import listeners.BoutonCancelDialogListener;
import listeners.BoutonPhoneCallListener;
import listeners.NavigationItemSelectListener;
import listeners.ProfilImageListener;
import models.Panier;
import models.Plat;
import models.Table;
import services.CommandeService;
import services.TableService;
import services.UtilisateurService;
import utilitaires.UtilitaireLangue;
import utilitaires.UtilitaireNombres;
import utilitaires.UtilitaireTable;
import utilitaires.UtilitaireUser;

/**
 * Created by ravelosonkiadisoa on 13/04/2016.
 */
public class MainActivityManager
{
    /**
     * The Position choix user.
     */
    public final int positionChoixUser = 10;
    /**
     * The Position connexion client.
     */
    public final int positionConnexionClient = 11;
    /**
     * The Position connexion employe.
     */
    public final int positionConnexionEmploye = 12;
    /**
     * The Position demande tag.
     */
    public final int positionDemandeTag = 13;

    /**
     * The Position carte.
     */
    public final int positionCarte = 0;
    /**
     * The Position commande.
     */
    public final int positionCommande = 2;
    /**
     * The Position splash screen.
     */
    public final int positionSplashScreen = -2;
    /**
     * The Position panier.
     */
    public final int positionPanier = -1;
    /**
     * The Position detail.
     */
    public final int positionDetail = -3;
    /**
     * The Position map.
     */
    public final int positionMap = 4;
    /**
     * The Position contact.
     */
    public final int positionContact = 41;
    /**
     * The Position parametre.
     */
    public final int positionParametre = 5;
    /**
     * The Position connex authentification.
     */
    public int positionConnexAuthentification = 0;
    /**
     * The Position apropos.
     */
    public final int positionApropos = 6;
    /**
     * The Position logout client.
     */
    public final int positionLogoutClient = 7;

    /**
     * The Position commande employe.
     */
    public final int positionCommandeEmploye = 0;
    /**
     * The Position demande tag jeton.
     */
    public final int positionDemandeTagJeton = 1;
    /**
     * The Position plat jeton.
     */
    public final int positionPlatJeton = 15;
    /**
     * The Activity.
     */
    public MainActivity activity;

    /**
     * Instantiates a new Main activity manager.
     *
     * @param activity the activity
     */
    public MainActivityManager(MainActivity activity)
    {
        this.activity = activity;
    }

    /**
     * Init activity.
     */
    public void initActivity()
    {
        activity.mToolbar = (Toolbar) activity.findViewById(R.id.toolbar);
        activity.setSupportActionBar(activity.mToolbar);
        activity.inflator = (LayoutInflater) activity.getSystemService(activity.LAYOUT_INFLATER_SERVICE);
        activity.actionBar = activity.inflator.inflate(R.layout.actionbar_main, null);

        activity.drawer = (DrawerLayout) activity.findViewById(R.id.drawer_layout);
        activity.toggle = new ActionBarDrawerToggle(activity, activity.drawer, activity.mToolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        activity.drawer.setDrawerListener(activity.toggle);
        activity.toggle.syncState();
        activity.navigationView = (NavigationView) activity.findViewById(R.id.fragment_navigation_drawer);
        refreshDrawer();
        activity.navigationItemSelectListener = new NavigationItemSelectListener(activity);
        activity.navigationView.setNavigationItemSelectedListener(activity.navigationItemSelectListener);

        activity.username = (TextView)activity.navigationView.findViewById(R.id.username);
        activity.profilImage = (ImageView) activity.navigationView.findViewById(R.id.profileimageuser);
        activity.profilImageListener = new ProfilImageListener(activity);
        activity.profilImage.setOnClickListener(activity.profilImageListener);

        updateUserProfilView();
        activity.utilisateurService = new UtilisateurService(activity);
        activity.tableService = new TableService(activity);
        activity.commandeService = new CommandeService(activity);
        activity.assetManager = activity.getAssets();
        activity.waitingDialog = new ProgressDialog(activity);
        activity.waitingDialog.setCancelable(false);
        activity.waitingDialog.setCanceledOnTouchOutside(false);

        activity.waitingDialog.setMessage(activity.getResources().getString(R.string.chargement));
        activity.supportFragmentManager = activity.getSupportFragmentManager();
    }

    /**
     * Update user profil view.
     */
    public void updateUserProfilView()
    {
        activity.username.setText(UtilitaireUser.getUserName(activity));

    }

    /**
     * Update user name in drawer.
     *
     * @param userName the user name
     */
    public void updateUserNameInDrawer(String userName)
    {
        activity.username.setText(userName);
    }
    /*NFC*/
    //Fonction appelée quand l'activité est appelé dans une nouvelle intent

    /**
     * Refresh drawer.
     */
    public void refreshDrawer()
    {
        activity.navigationView.getMenu().clear(); //clear old inflated items.
        if(UtilitaireUser.getTypeUser(activity).compareTo("client") == 0)
        {
            activity.navigationView.inflateMenu(R.menu.navigation_drawer_client);
            //actualiser le menu en l'utilisant un peu
            activity.navigationView.getMenu().getItem(0).setChecked(true);
        }
        else if(UtilitaireUser.getTypeUser(activity).compareTo("employe") == 0)
        {
            activity.navigationView.inflateMenu(R.menu.navigation_drawer_employe);
            //actualiser le menu en l'utilisant un peu
            activity.navigationView.getMenu().getItem(0).setChecked(true);
        }

    }

    /**
     * Sets langue.
     */
    public void setupLangue()
    {
        String langue = UtilitaireLangue.getLangueEnCours(activity);
        Locale locale = new Locale(langue);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.locale = locale;
        activity.getBaseContext().getResources().updateConfiguration(config, activity.getBaseContext().getResources().getDisplayMetrics());
    }

    /**
     * Show action bar.
     */
    public void showActionBar()
    {
        ActionBar defaultActionBar = activity.getSupportActionBar();
        defaultActionBar.setHomeButtonEnabled(true);
        defaultActionBar.setDisplayShowCustomEnabled(true);
        defaultActionBar.setDisplayShowTitleEnabled(false);
        defaultActionBar.setCustomView(activity.actionBar);
        activity.nbItemInPanier = (TextView) activity.actionBar.findViewById(R.id.nbrItemPanier);
        activity.totalInPanier = (TextView) activity.actionBar.findViewById(R.id.totalText);
        activity.relativePhoneCallIconLayout = (RelativeLayout) activity.actionBar.findViewById(R.id.relativePhoneCallIconLayout);
        activity.titleActionBar = (TextView) activity.actionBar.findViewById(R.id.actionBarTitle);
        activity.totalLayout = (RelativeLayout) activity.actionBar.findViewById(R.id.totalLayout);
        activity.relativePanierIconLayout = (RelativeLayout) activity.actionBar.findViewById(R.id.relativePanierIconLayout);
        activity.relativePanierIconLayout.setOnClickListener(new BoutonAfficherPanierListener(activity));
        //Mise à jour du nombre d'élément dans le panier à afficher
        activity.nbItemInPanier.setText(String.valueOf(Panier.getNbrItemInPanier(activity)));
        activity.relativePhoneCallIconLayout.setOnClickListener(new BoutonPhoneCallListener(activity, activity.callIntent));
    }

    /**
     * Display view.
     *
     * @param position the position
     */
    public void displayView(int position)
    {
        activity.positionFragment = position;
        Fragment fragment = null;
        String title = activity.getString(R.string.app_name);
        switch (position)
        {
            case positionCarte:
                activity.positionFragment = positionCarte;
                fragment = new CarteFragment();
                title = activity.getString(R.string.title_carte);
                break;
            case positionSplashScreen:
                activity.navigationView.setVisibility(View.GONE);
                fragment = new SplashScreenFragment();
                break;
            case positionParametre:
                activity.actionBar.findViewById(R.id.relativePanierIconLayout).setVisibility(View.GONE);
                break;
            default:
                break;
        }
        changeFragment(fragment, title);
    }

    /**
     * Display plat echangeable jeton.
     *
     * @param valeurJeton the valeur jeton
     * @param idTagNfc    the id tag nfc
     */
    public void displayPlatEchangeableJeton(float valeurJeton, String idTagNfc)
    {
        activity.positionFragment = positionPlatJeton;
        Fragment fragment = new fragments.fragmentForDrawer.detail.employe.PlatFragment();
        Bundle b = new Bundle();
        b.putString("clientIdTagNfc", idTagNfc);
        b.putFloat("valeur", valeurJeton);
        fragment.setArguments(b);
        String title = activity.getResources().getString(R.string.nav_item_echange_jeton);
        changeFragment(fragment, title);
    }

    /**
     * Display detail plat echangeable jeton.
     *
     * @param valeurJeton the valeur jeton
     * @param idTagNfc    the id tag nfc
     * @param plat        the plat
     */
    public void displayDetailPlatEchangeableJeton(float valeurJeton, String idTagNfc, Plat plat)
    {
        activity.positionFragment = positionPlatJeton;
        Fragment fragment = new fragments.fragmentForDrawer.detail.employe.DetailPlatEchangeFragment();
        Bundle b = new Bundle();
        b.putSerializable("plat", plat);
        b.putString("clientIdTagNfc", idTagNfc);
        b.putFloat("valeur", valeurJeton);
        fragment.setArguments(b);
        String title = activity.getResources().getString(R.string.nav_item_echange_jeton);
        changeFragment(fragment, title);
    }

    /**
     * Display view employe.
     *
     * @param position the position
     */
    public void displayViewEmploye(int position)
    {
        activity.positionFragment = position;
        Fragment fragment = null;
        String title = activity.getString(R.string.app_name);

        switch (position)
        {
            case 0:
                fragment = new TableCommandeFragment();
                activity.positionFragment = position;
                title = activity.getResources().getString(R.string.title_commande);
                break;
            case 1:
                fragment = new fragments.fragmentForDrawer.detail.employe.DemandeTagFragment();
                activity.positionFragment = position;
                title = activity.getResources().getString(R.string.nav_item_echange_jeton);
                break;
            case positionPlatJeton:
                fragment = new fragments.fragmentForDrawer.detail.employe.PlatFragment();
                activity.positionFragment = position;
                title = activity.getResources().getString(R.string.nav_item_echange_jeton);
                break;
            case 2:
                //fragment = new ParametreFragment();
                fragment = new ParametreFragment();
                activity.positionFragment = positionParametre;
                title = activity.getString(R.string.title_parametre);
                break;
            case 3:
                logout();
                break;
            default:
                break;
        }
        changeFragment(fragment, title);
    }

    /**
     * Afficher commande par table.
     *
     * @param table the table
     */
    public void afficherCommandeParTable(Table table)
    {
        Bundle b = new Bundle();
        b.putSerializable("table", table);
        String title = activity.getString(R.string.app_name);
        Fragment fragment = new fragments.fragmentForDrawer.detail.employe.CommandeFragment();
        fragment.setArguments(b);
        activity.positionFragment = positionCommande;
        title = "Commandes";
        changeFragment(fragment, title);
    }

    /**
     * Change fragment.
     *
     * @param fragment the fragment
     * @param title    the title
     */
    public void changeFragment(Fragment fragment, String title)
    {
        if (fragment != null)
        {
            FragmentTransaction fragmentTransaction = activity.supportFragmentManager.beginTransaction();

            fragmentTransaction.setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out, android.R.anim.fade_in, android.R.anim.fade_out);

            fragmentTransaction.replace(R.id.container_body, fragment);
            try
            {
                activity.titleActionBar.setText(title);
            }
            catch (RuntimeException e)
            {
                e.printStackTrace();
            }
            fragmentTransaction.commit();
            setViewsVisibility();
        }
    }

    /**
     * Logout.
     */
    public void logout()
    {
        UtilitaireUser.viderSession(activity);
        Picasso.with(activity)
                .load(R.drawable.ic_profile)       // optional
                .into(activity.profilImage);
        activity.navigationView.getMenu().clear();
        activity.username.setText("");
        afficherAuthentification(positionChoixUser);
    }

    /**
     * Display view from splash screen.
     */
    public void displayViewFromSplashScreen()
    {
        activity.navigationView.setVisibility(View.VISIBLE);

        if (UtilitaireUser.getUserName(activity) != null && UtilitaireUser.getUserName(activity).compareTo("")!=0)
        {
            String type = UtilitaireUser.getTypeUser(activity);
            if(type.compareTo(activity.typeClient) == 0)
            {
                displayView(positionCarte);
            }
            else if(type.compareTo(activity.typeEmploye) == 0)
            {
                displayViewEmploye(positionCommandeEmploye);
            }
            Table t = UtilitaireTable.getTable(activity);
        }
        else
            afficherAuthentification(positionChoixUser);
    }

    /**
     * Show dialog asking for table tag.
     */
    public void showDialogAskingForTableTag()
    {
        activity.builder = new AlertDialog.Builder(activity);
        activity.builder.setMessage(activity.getResources().getString(R.string.ask_tag_table));
        //builder.setPositiveButton(getResources().getString(R.string.juste_consulter), new BoutonCancelDialogListener());
        activity.builder.setPositiveButton(activity.getResources().getString(R.string.annuler), new BoutonCancelDialogListener(activity));
        activity.dialogAskingForTag = activity.builder.create();
        activity.dialogAskingForTag.setCanceledOnTouchOutside(false);
        activity.dialogAskingForTag.show();
    }

    /**
     * Afficher detail.
     *
     * @param p the p
     */
    public void afficherDetail(Plat p)
    {
        activity.positionFragment = positionDetail;
        Bundle b = new Bundle();
        b.putSerializable("plat", p);
        Fragment fragment = new DetailPlatFragment();
        fragment.setArguments(b);
        FragmentManager fragmentManager = activity.supportFragmentManager;
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out, android.R.anim.fade_in, android.R.anim.fade_out);
        fragmentTransaction.replace(R.id.container_body, fragment);
        try
        {
            String title = p.getNom();
            if (title.length() > 18)
            {
                title = title.substring(0, 17) + "...";
            }
            ((TextView) activity.actionBar.findViewById(R.id.actionBarTitle)).setText(title);
        }
        catch (RuntimeException e) {
        }
        fragmentTransaction.commit();
        setViewsVisibility();
    }

    /**
     * Afficher hitorique commande.
     */
    public void afficherHitoriqueCommande()
    {
        activity.positionFragment = positionCommande;
        Fragment fragment = new CommandeFragment();
        FragmentManager fragmentManager = activity.supportFragmentManager;
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out, android.R.anim.fade_in, android.R.anim.fade_out);
        fragmentTransaction.replace(R.id.container_body, fragment);
        try
        {
            activity.titleActionBar.setText(activity.getString(R.string.title_commande));
        }
        catch (RuntimeException e)
        {
            e.printStackTrace();
        }
        fragmentTransaction.commit();
        setViewsVisibility();
    }

    /**
     * Sets views visibility.
     */
    public void setViewsVisibility()
    {
        if (activity.positionFragment == positionSplashScreen)
        {
            activity.mToolbar.setVisibility(View.GONE);
        }
        else {
            activity.mToolbar.setVisibility(View.VISIBLE);
            if (UtilitaireUser.getTypeUser(activity).equals(activity.typeClient))
            {
                switch (activity.positionFragment) {
                    case positionPanier:
                        activity.totalLayout.setVisibility(View.VISIBLE);
                        activity.relativePanierIconLayout.setVisibility(View.GONE);
                        activity.relativePhoneCallIconLayout.setVisibility(View.GONE);
                        activity.totalInPanier.setText("Total = " + UtilitaireNombres.addThousandSeparator(Panier.getCommande(activity).getTotal()) + "Ar");
                        activity.totalInPanier.setVisibility(View.VISIBLE);
                        break;
                    case positionMap:
                        activity.totalLayout.setVisibility(View.GONE);
                        activity.relativePanierIconLayout.setVisibility(View.GONE);
                        activity.relativePhoneCallIconLayout.setVisibility(View.VISIBLE);
                        break;
                    case positionCarte:
                        activity.totalLayout.setVisibility(View.GONE);
                        activity.relativePanierIconLayout.setVisibility(View.VISIBLE);
                        activity.relativePhoneCallIconLayout.setVisibility(View.GONE);
                        activity.totalInPanier.setVisibility(View.GONE);
                        break;
                    case positionParametre:
                        activity.totalLayout.setVisibility(View.GONE);
                        activity.relativePanierIconLayout.setVisibility(View.GONE);
                        activity.relativePhoneCallIconLayout.setVisibility(View.GONE);
                        break;
                    case positionContact:
                        activity.totalLayout.setVisibility(View.GONE);
                        activity.relativePhoneCallIconLayout.setVisibility(View.GONE);
                        activity.relativePanierIconLayout.setVisibility(View.GONE);
                        activity.totalInPanier.setVisibility(View.GONE);
                        break;
                    case positionCommande:
                        activity.totalLayout.setVisibility(View.VISIBLE);
                        activity.relativePanierIconLayout.setVisibility(View.GONE);
                        activity.relativePhoneCallIconLayout.setVisibility(View.GONE);
                        activity.totalInPanier.setVisibility(View.VISIBLE);
                        break;
                    case positionDetail:
                        activity.totalLayout.setVisibility(View.GONE);
                        activity.relativePanierIconLayout.setVisibility(View.VISIBLE);
                        activity.relativePhoneCallIconLayout.setVisibility(View.GONE);
                        activity.totalInPanier.setVisibility(View.GONE);
                        break;
                    case positionApropos:
                        activity.totalLayout.setVisibility(View.GONE);
                        activity.relativePanierIconLayout.setVisibility(View.GONE);
                        activity.relativePhoneCallIconLayout.setVisibility(View.VISIBLE);
                        activity.totalInPanier.setVisibility(View.GONE);
                        break;
                    default:
                        activity.totalLayout.setVisibility(View.VISIBLE);
                        activity.totalInPanier.setVisibility(View.VISIBLE);
                        activity.nbItemInPanier.setText(String.valueOf(Panier.getNbrItemInPanier(activity)));
                        break;
                }
            }
            else
            {
                switch (activity.positionFragment) {
                    case positionCommandeEmploye:
                        activity.totalLayout.setVisibility(View.GONE);
                        activity.relativePanierIconLayout.setVisibility(View.GONE);
                        activity.relativePhoneCallIconLayout.setVisibility(View.GONE);
                        activity.totalInPanier.setVisibility(View.GONE);
                        break;
                    default:
                        break;
                }
            }
        }

    }

    /**
     * Afficher panier.
     */
    public void afficherPanier()
    {
        activity.mToolbar.setVisibility(View.VISIBLE);
        activity.positionFragment = positionPanier;
        Fragment fragment = new PanierFragment();
        FragmentTransaction fragmentTransaction = activity.supportFragmentManager.beginTransaction();
        fragmentTransaction.setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out, android.R.anim.fade_in, android.R.anim.fade_out);
        fragmentTransaction.replace(R.id.container_body, fragment);
        try
        {
            activity.titleActionBar.setText(activity.getResources().getString(R.string.panier));
        }
        catch (RuntimeException e)
        {
            e.printStackTrace();
        }
        fragmentTransaction.commit();

        setViewsVisibility();
    }

    /**
     * Afficher contact.
     */
    public void afficherContact()
    {
        activity.mToolbar.setVisibility(View.VISIBLE);
        activity.positionFragment = positionContact;
        Fragment fragment = new ContactFragment();
        FragmentTransaction fragmentTransaction = activity.supportFragmentManager.beginTransaction();
        fragmentTransaction.setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out, android.R.anim.fade_in, android.R.anim.fade_out);
        fragmentTransaction.replace(R.id.container_body, fragment);
        try
        {
            activity.titleActionBar.setText("Contact");
        } catch (RuntimeException e) {
            e.printStackTrace();
        }
        fragmentTransaction.commit();
        setViewsVisibility();
    }

    /**
     * Afficher authentification.
     *
     * @param position the position
     */
    public void afficherAuthentification(int position)
    {
        activity.navigationView.setVisibility(View.GONE);
        activity.mToolbar.setVisibility(View.GONE);
        activity.positionFragment = position;
        Fragment fragment = null;
        switch (position)
        {
            case positionChoixUser:
                fragment = new ChoixTypeUserFragment();
                break;
            case positionConnexionClient:
                fragment = new ConnexionClientFragment();
                break;
            case positionConnexionEmploye:
                fragment = new ConnexionEmployeFragment();
                break;
            case positionDemandeTag:
                fragment = new DemandeTagFragment();
                break;
            default:
                break;
        }
        //fragment.setArguments(b);

        FragmentTransaction fragmentTransaction = activity.supportFragmentManager.beginTransaction();
        fragmentTransaction.setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out, android.R.anim.fade_in, android.R.anim.fade_out);
        fragmentTransaction.replace(R.id.container_body, fragment);
        try
        {
            activity.titleActionBar.setText("Contact");
        }
        catch (RuntimeException e)
        {
            e.printStackTrace();
        }
        if (position != positionChoixUser)
            fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
        activity.relativePanierIconLayout.setVisibility(View.INVISIBLE);
        activity.totalInPanier.setVisibility(View.INVISIBLE);
    }
}
