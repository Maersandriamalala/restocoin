package services;

import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;

import org.json.JSONArray;
import org.json.JSONException;

import activities.MainActivity;
import app.AppController;
import utilitaires.UtilitaireDB;
import utilitaires.UtilitaireString;
import utilitaires.VariableStatic;
import kiadi.restaurant.R;

/**
 * Created by ravelosonkiadisoa on 12/04/2016.
 */
public class NouritureService
{
    private MainActivity activity;

    /**
     * Instantiates a new Nouriture service.
     *
     * @param activity the activity
     */
    public NouritureService(MainActivity activity)
    {
        this.activity = activity;
    }

    /**
     * Remplire base.
     */
    public void remplireBase()
    {
        String url = VariableStatic.baseUrl + "plats";
        JsonArrayRequest platsReq = new JsonArrayRequest(url,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        try
                        {
                            response = new JSONArray(UtilitaireString.fixEncodingUnicode(response.toString()));
                        }
                        catch (JSONException e)
                        {
                            e.printStackTrace();
                        }
                        if(activity.waitingDialog.isShowing()) activity.waitingDialog.dismiss();
                        UtilitaireDB.remplire(activity, response);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                if(activity.waitingDialog.isShowing()) activity.waitingDialog.dismiss();
                Toast.makeText(activity, activity.getResources().getString(R.string.connexionError), Toast.LENGTH_LONG).show();
            }
        });
        // Adding request to request queue

        AppController.getInstance().addToRequestQueue(platsReq);
    }
}
