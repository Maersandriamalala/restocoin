package services;

import android.util.Log;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import activities.MainActivity;
import app.AppController;
import kiadi.restaurant.R;
import utilitaires.UtilitaireDB;
import utilitaires.UtilitaireString;
import utilitaires.UtilitaireUser;
import utilitaires.VariableStatic;

/**
 * Created by ravelosonkiadisoa on 12/04/2016.
 */
public class UtilisateurService
{
    private MainActivity activity;

    /**
     * Instantiates a new Utilisateur service.
     *
     * @param activity the activity
     */
    public UtilisateurService(MainActivity activity)
    {
        this.activity = activity;
    }

    /**
     * Creer compte client.
     *
     * @param nom    the nom
     * @param tagUID the tag uid
     */
    public void creerCompteClient(final String nom,final String idTagNfc)
    {
        Log.d("creerCompteClient", idTagNfc);
        String url = VariableStatic.baseUrl + "ajoutClient";
        StringRequest stringRequest = new StringRequest(Request.Method.POST,url,
                new Response.Listener<String>()
                {
                    @Override
                    public void onResponse(String response)
                    {
                        try
                        {
                            Log.i("Activity", "response = " + response);
                            JSONObject resp = new JSONObject(response);
                            UtilitaireUser.setUser_id(activity, resp.getString("_id"));
                            UtilitaireUser.setUserName(activity, resp.getString("nom"));
                            UtilitaireUser.setIdTagNFC(activity, idTagNfc);
                            activity.mainActivityManager.displayView(0);

                        }
                        catch(JSONException j)
                        {
                            try
                            {
                                JSONObject resp = new JSONObject(response);
                                Toast.makeText(activity, UtilitaireString.fixEncodingUnicode(resp.getString("message")), Toast.LENGTH_LONG).show();
                                activity.mainActivityManager.afficherAuthentification(activity.mainActivityManager.positionConnexAuthentification);
                            }
                            catch (JSONException e)
                            {
                                Toast.makeText(activity, UtilitaireString.fixEncodingUnicode(response), Toast.LENGTH_LONG).show();
                                e.printStackTrace();
                            }
                            j.printStackTrace();
                        }
                        if(activity.waitingDialog.isShowing()) activity.waitingDialog.dismiss();
                    }

                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error)
                    {
                        Toast.makeText(activity, activity.getResources().getString(R.string.connexionError), Toast.LENGTH_LONG).show();
                        if(activity.waitingDialog.isShowing()) activity.waitingDialog.dismiss();
                    }
                }){
            @Override
            protected Map<String, String> getParams() throws com.android.volley.AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("nom", nom);
                params.put("idTagNfc", idTagNfc);
                return params;
            }
        };
        // Adding request to request queue

        AppController.getInstance().addToRequestQueue(stringRequest);
    }

    /**
     * Connexion employe.
     *
     * @param nom        the nom
     * @param motdepasse the motdepasse
     */
    public void connexionEmploye(final String nom, final String motdepasse)
    {
        String url = VariableStatic.baseUrl + "connexionEmploye";
        StringRequest stringRequest = new StringRequest(Request.Method.POST,url,
                new Response.Listener<String>()
                {
                    @Override
                    public void onResponse(String response)
                    {
                        try
                        {
                            Log.i("Activity", "response = " + response);
                            JSONObject resp = new JSONObject(response);
                            try
                            {
                                UtilitaireUser.setUser_id(activity, resp.getString("_id"));
                                UtilitaireUser.setUserName(activity, resp.getString("nom"));
                                activity.mainActivityManager.displayViewFromSplashScreen();
                            }
                            catch(JSONException e)
                            {
                                Toast.makeText(activity, resp.getString("message"), Toast.LENGTH_LONG).show();
                                e.printStackTrace();
                            }
                        }
                        catch(JSONException j)
                        {
                            Toast.makeText(activity, response, Toast.LENGTH_LONG).show();
                            j.printStackTrace();
                        }
                        if(activity.waitingDialog.isShowing()) activity.waitingDialog.dismiss();
                    }

                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error)
                    {
                        if(activity.waitingDialog.isShowing()) activity.waitingDialog.dismiss();
                        Toast.makeText(activity, activity.getResources().getString(R.string.connexionError), Toast.LENGTH_LONG).show();
                    }
                }){
            @Override
            protected Map<String, String> getParams() throws com.android.volley.AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("nom", nom);
                params.put("motdepasse", motdepasse);
                return params;
            }
        };

        // Adding request to request queue

        AppController.getInstance().addToRequestQueue(stringRequest);
    }

    /**
     * Connexion client.
     *
     * @param idTagNfc the id tag nfc
     */
    public void connexionClient(final String idTagNfc)
    {
        String url = VariableStatic.baseUrl + "connexionClient";
        StringRequest stringRequest = new StringRequest(Request.Method.POST,url,
                new Response.Listener<String>()
                {
                    @Override
                    public void onResponse(String response)
                    {
                        try
                        {
                            Log.i("Activity", "response = " + response);
                            JSONObject resp = new JSONObject(response);
                            try
                            {
                                UtilitaireUser.setUser_id(activity, resp.getString("_id"));
                                UtilitaireUser.setUserName(activity, resp.getString("nom"));
                                UtilitaireUser.setIdTagNFC(activity, idTagNfc);
                                activity.mainActivityManager.displayView(0);
                            }
                            catch(JSONException e)
                            {
                                Toast.makeText(activity, UtilitaireString.fixEncodingUnicode(resp.getString("message")), Toast.LENGTH_LONG).show();
                                //activity.mainActivityManager.afficherAuthentification(activity.mainActivityManager.positionConnexAuthentification);
                                activity.getSupportFragmentManager().popBackStack();
                                e.printStackTrace();
                            }
                        }
                        catch(JSONException j)
                        {
                            Toast.makeText(activity, response, Toast.LENGTH_LONG).show();
                            j.printStackTrace();
                        }
                        if(activity.waitingDialog.isShowing()) activity.waitingDialog.dismiss();
                    }

                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error)
                    {
                        Toast.makeText(activity, activity.getResources().getString(R.string.connexionError), Toast.LENGTH_LONG).show();
                        if(activity.waitingDialog.isShowing()) activity.waitingDialog.dismiss();
                    }
                }){
            @Override
            protected Map<String, String> getParams() throws com.android.volley.AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("idTagNfc", idTagNfc);
                return params;
            }
        };

        // Adding request to request queue

        AppController.getInstance().addToRequestQueue(stringRequest);
    }

    /**
     * Obtenir valeur jeton par id tag nfc.
     *
     * @param idTagNfc the id tag nfc
     */
    public void obtenirValeurJetonParIdTagNfc(final String idTagNfc)
    {
        Log.d("ResponseJetonidTagNfc", idTagNfc);
        String url = VariableStatic.baseUrl + "valeurJetonClient/" + idTagNfc;
        StringRequest stringRequest = new StringRequest(Request.Method.GET,url,
                new Response.Listener<String>()
                {
                    @Override
                    public void onResponse(String response)
                    {
                        Log.d("ResponseJeton", response);
                        try
                        {
                            JSONObject resp = new JSONObject(response);
                            try
                            {
                                float valeur = Float.valueOf(resp.getString("valeur"));
                                activity.mainActivityManager.displayPlatEchangeableJeton(valeur, idTagNfc);
                                //activity.mainActivityManager.displayViewEmploye(activity.mainActivityManager.positionPlatJeton);
                            }
                            catch(JSONException e)
                            {
                                Toast.makeText(activity, UtilitaireString.fixEncodingUnicode(resp.getString("message")), Toast.LENGTH_LONG).show();
                                //activity.mainActivityManager.afficherAuthentification(activity.mainActivityManager.positionConnexAuthentification);

                                e.printStackTrace();
                            }
                        }
                        catch(JSONException j)
                        {
                            Toast.makeText(activity, response, Toast.LENGTH_LONG).show();
                            j.printStackTrace();
                        }
                        if(activity.waitingDialog.isShowing()) activity.waitingDialog.dismiss();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error)
                    {
                        Toast.makeText(activity, activity.getResources().getString(R.string.connexionError), Toast.LENGTH_LONG).show();
                        if(activity.waitingDialog.isShowing()) activity.waitingDialog.dismiss();
                    }
        });
        AppController.getInstance().addToRequestQueue(stringRequest);
    }
}
