package services;

import android.util.Log;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import activities.MainActivity;
import app.AppController;
import kiadi.restaurant.R;
import models.Table;
import utilitaires.UtilitaireTable;
import utilitaires.VariableStatic;

/**
 * Created by ravelosonkiadisoa on 04/04/2016.
 */
public class TableService
{
    private MainActivity activity;

    /**
     * Instantiates a new Table service.
     *
     * @param activity the activity
     */
    public TableService(MainActivity activity)
    {
        this.activity = activity;
    }

    /**
     * Gets table name.
     *
     * @param tableUID the table uid
     * @return the table name
     */
    public static String getTableName(String tableUID)
    {
        String ret = "";
        return ret;
    }

    /**
     * Gets table by uid.
     *
     * @param tableUID the table uid
     */
    public void getTableByUID(final String tableUID)
    {
        String url = VariableStatic.baseUrl + "tableRestos?idTagNfc="+tableUID;
        JsonArrayRequest platsReq = new JsonArrayRequest(url,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response)
                    {
                        Log.d("respons", response.toString());
                        try
                        {
                            JSONObject table =(JSONObject) response.get(0);
                            Table t = new Table();
                            t.nom = table.getString("nom");
                            t.idTagNfc = tableUID;
                            t._id = table.getString("_id");
                            t.nbrPlace = table.getLong("nbrPlace");
                            t.numero = table.getLong("numero");
                            Log.d("table.idTagNfc", t.idTagNfc);
                            UtilitaireTable.setTable(activity, t);
                            activity.commandeService.ajouterCommande();
                        }
                        catch (JSONException e)
                        {
                            Toast.makeText(activity, "Ce tag n'est associé à aucune table", Toast.LENGTH_SHORT).show();
                            e.printStackTrace();
                        }
                        if(activity.waitingDialog.isShowing()) activity.waitingDialog.dismiss();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                if(activity.waitingDialog.isShowing()) activity.waitingDialog.dismiss();
                Toast.makeText(activity, activity.getResources().getString(R.string.connexionError), Toast.LENGTH_LONG).show();
                if(activity.waitingDialog.isShowing()) activity.waitingDialog.dismiss();
            }
        });
        // Adding request to request queue

        AppController.getInstance().addToRequestQueue(platsReq);
    }
}
