package services;

import android.app.Fragment;
import android.util.Log;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.getbase.floatingactionbutton.FloatingActionButton;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;

import activities.MainActivity;
import app.AppController;
import fragments.fragmentForDrawer.detail.BaseCommandeFragment;
import fragments.fragmentForDrawer.detail.employe.CommandeFragment;
import fragments.fragmentForDrawer.detail.employe.DetailPlatEchangeFragment;
import fragments.fragmentForDrawer.detail.employe.TableCommandeFragment;
import models.CommandeTable;
import models.CommandeWS;
import models.Panier;
import models.PlatCommande;
import models.Table;
import models.Utilisateur;
import utilitaires.UtilitaireDate;
import utilitaires.UtilitaireList;
import utilitaires.UtilitaireString;
import utilitaires.UtilitaireTable;
import utilitaires.UtilitaireUser;
import utilitaires.VariableStatic;
import kiadi.restaurant.R;

/**
 * Created by ravelosonkiadisoa on 12/04/2016.
 */
public class CommandeService
{
    private static Gson gson = new Gson();
    private MainActivity activity;

    /**
     * Instantiates a new Commande service.
     *
     * @param activity the activity
     */
    public CommandeService(MainActivity activity)
    {
        this.activity = activity;
    }

    /**
     * Ajouter commande.
     */
    public void ajouterCommande()
    {
        final Utilisateur user = UtilitaireUser.getUser(activity);
        String url = VariableStatic.baseUrl + "ajoutCommandeResto";
        Table t = UtilitaireTable.getTable(activity);
        if(t.nom != null && t.nom.compareTo("")!= 0)
        {
            StringRequest stringRequest = new StringRequest(Request.Method.POST,url,
                    new Response.Listener<String>()
                    {
                        @Override
                        public void onResponse(String response)
                        {
                            if(activity.waitingDialog.isShowing()) activity.waitingDialog.dismiss();
                            Panier.clear(activity);
                            activity.nbItemInPanier.setText("0");
                            activity.mainActivityManager.afficherHitoriqueCommande();
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error)
                        {
                            Toast.makeText(activity, activity.getResources().getString(R.string.connexionError), Toast.LENGTH_LONG).show();
                        }
                    }){
                @Override
                protected Map<String, String> getParams() throws com.android.volley.AuthFailureError {
                    Map<String, String> params = new HashMap<String, String>();
                    CommandeWS cws = new CommandeWS();
                    cws.daty = Panier.getDateMiseEnPanier(activity);
                    cws.estPaye = false;
                    cws.quantite = Panier.getNbrItemInPanier(activity);
                    cws.plats = Panier.getListPlatInPanier(activity);
                    cws.total = Panier.getCommande(activity).getTotal();

                    CommandeTable ct = new CommandeTable();
                    ct.commande = cws;
                    ct.utilisateur = user;
                    ct.datePassageCommande = UtilitaireDate.getCurrentDate();
                    ct.table = UtilitaireTable.getTable(activity);
                    params.put("commande", gson.toJson(ct).toString());
                    return params;
                }
            };
            // Adding request to request queue
            AppController.getInstance().addToRequestQueue(stringRequest);
        }
        else
            activity.mainActivityManager.showDialogAskingForTableTag();
    }

    /**
     * Gets commande by table uid.
     *
     * @param table    the table
     * @param fragment the fragment
     */
    public void getCommandeByTableUID(Table table, final BaseCommandeFragment fragment)
    {
        String url = VariableStatic.baseUrl + "commandes/"+gson.toJson(table).toString();

        JsonArrayRequest platsReq = new JsonArrayRequest(url,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response)
                    {
                        Utilisateur leClient = null;
                        for(int i=0; i < response.length(); i++)
                        {
                            try
                            {
                                JSONObject object = response.getJSONObject(i);
                                JSONObject commande = object.getJSONObject("commande");
                                JSONObject client = object.getJSONObject("utilisateur");
                                leClient = gson.fromJson(client.toString(), Utilisateur.class);
                                CommandeWS cws = gson.fromJson(UtilitaireString.fixEncodingUnicode(commande.toString()), CommandeWS.class);
                                for(PlatCommande pc : cws.plats)
                                {
                                    fragment.listCommande.add(pc);
                                }
                                fragment.total += cws.total;
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                        if(fragment.listCommande.size() == 0)
                        {
                            if(fragment instanceof fragments.fragmentForDrawer.detail.employe.CommandeFragment)
                            {
                                ((CommandeFragment)fragment).btnPayer.setVisibility(View.GONE);
                            }
                            fragment.commandeVideLayout.setVisibility(View.VISIBLE);
                            fragment.mWebView.setVisibility(View.GONE);
                            activity.totalInPanier.setVisibility(View.GONE);
                        }
                        else
                        {
                            activity.totalInPanier.setVisibility(View.VISIBLE);
                            fragment.commandeVideLayout.setVisibility(View.GONE);
                            fragment.mWebView.setVisibility(View.VISIBLE);
                            WebSettings webSettings = fragment.mWebView.getSettings();
                            webSettings.setJavaScriptEnabled(true);
                            webSettings.setDefaultTextEncodingName("utf-8");
                            fragment.mWebView.setWebViewClient(new WebViewClient());
                            fragment.html = fragment.getFileAsString("commande.html");
                            fragment.loadDataIntoHTML(leClient);
                            if(fragment instanceof fragments.fragmentForDrawer.detail.employe.CommandeFragment)
                            {
                                ((CommandeFragment)fragment).btnPayer.setVisibility(View.VISIBLE);
                            }
                            fragment.mWebView.loadData(fragment.html, "text/html; charset=utf-8", "UTF-8");
                        }
                        if(activity.waitingDialog.isShowing()) activity.waitingDialog.dismiss();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error)
            {
                if(activity.waitingDialog.isShowing()) activity.waitingDialog.dismiss();
                if(fragment instanceof fragments.fragmentForDrawer.detail.employe.CommandeFragment)
                {
                    ((CommandeFragment)fragment).btnPayer.setVisibility(View.VISIBLE);
                }
                Toast.makeText(activity, activity.getResources().getString(R.string.connexionError), Toast.LENGTH_LONG).show();
            }
        });
        // Adding request to request queue

        AppController.getInstance().addToRequestQueue(platsReq);
    }

    /**
     * Gets table commandes.
     *
     * @param fragment the fragment
     */
    public void getTableCommandes(final TableCommandeFragment fragment)
    {
        String url = VariableStatic.baseUrl + "commandes/{}";

        JsonArrayRequest platsReq = new JsonArrayRequest(url,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response)
                    {
                        fragment.dataSet.clear();
                        Log.d("table", response.toString());
                        for(int i=0; i < response.length(); i++)
                        {
                            try
                            {
                                JSONObject object = response.getJSONObject(i);
                                JSONObject tableJSON = object.getJSONObject("table");
                                JSONObject commandeJSON = object.getJSONObject("commande");
                                float addition = Float.valueOf(commandeJSON.getString("total"));
                                Table table = gson.fromJson(tableJSON.toString(), Table.class);
                                table.addition = addition;
                                UtilitaireList.addTableUnique(fragment.mAdapter ,fragment.dataSet, table);
                            }

                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }

                        if(fragment.mAdapter.getItemCount() == 0)
                        {
                            fragment.commandeVideLayout.setVisibility(View.VISIBLE);
                            fragment.mRecyclerView.setVisibility(View.GONE);
                            activity.totalInPanier.setVisibility(View.GONE);
                        }
                        else
                        {
                            activity.totalInPanier.setVisibility(View.VISIBLE);
                            fragment.commandeVideLayout.setVisibility(View.GONE);
                            fragment.mRecyclerView.setVisibility(View.VISIBLE);
                        }
                        if(activity.waitingDialog.isShowing()) activity.waitingDialog.dismiss();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error)
            {
                if(activity.waitingDialog.isShowing()) activity.waitingDialog.dismiss();
                Toast.makeText(activity, activity.getResources().getString(R.string.connexionError), Toast.LENGTH_LONG).show();
                fragment.commandeVideLayout.setVisibility(View.VISIBLE);
                fragment.mRecyclerView.setVisibility(View.GONE);
                activity.totalInPanier.setVisibility(View.GONE);
            }
        });
        // Adding request to request queue

        AppController.getInstance().addToRequestQueue(platsReq);
    }

    /**
     * Payer commande table.
     *
     * @param fragment the fragment
     */
    public void payerCommandeTable(final CommandeFragment fragment)
    {
        String url = VariableStatic.baseUrl + "payerCommandes";
        StringRequest stringRequest = new StringRequest(Request.Method.PUT,url,
                new Response.Listener<String>()
                {
                    @Override
                    public void onResponse(String response)
                    {
                        activity.mainActivityManager.displayViewEmploye(0);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error)
                    {
                        Toast.makeText(activity, activity.getResources().getString(R.string.connexionError), Toast.LENGTH_LONG).show();
                    }
                }){
            @Override
            protected Map<String, String> getParams() throws com.android.volley.AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("table", gson.toJson(fragment.table).toString());
                Log.d("leClient", gson.toJson(fragment.leClient).toString());
                params.put("client", gson.toJson(fragment.leClient).toString());
                params.put("addition", String.valueOf(fragment.total));
                return params;
            }
        };
        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(stringRequest);
    }

    /**
     * Echanger jeton plat.
     *
     * @param fragment the fragment
     */
    public void echangerJetonPlat(final DetailPlatEchangeFragment fragment)
    {
        String url = VariableStatic.baseUrl + "echangerJetonPlat";
        StringRequest stringRequest = new StringRequest(Request.Method.POST,url,
                new Response.Listener<String>()
                {
                    @Override
                    public void onResponse(String response)
                    {
                        activity.mainActivityManager.displayViewEmploye(0);
                        Toast.makeText(activity, "Echange effectuée", Toast.LENGTH_SHORT).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error)
                    {
                        Toast.makeText(activity, activity.getResources().getString(R.string.connexionError), Toast.LENGTH_LONG).show();
                    }
                }){
            @Override
            protected Map<String, String> getParams() throws com.android.volley.AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("clientIdTagNfc", fragment.clientIdTagNfc);
                params.put("plat", gson.toJson(fragment.plat).toString());
                return params;
            }
        };
        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(stringRequest);
    }
}
