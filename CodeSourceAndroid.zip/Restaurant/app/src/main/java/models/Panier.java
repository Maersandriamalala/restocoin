package models;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

import utilitaires.UtilitaireDate;

/**
 * Created by ravelosonkiadisoa on 18/03/2016.
 */

/**
 * Classe pour gerer le panier
 */

public class Panier
{
    private static Gson gson = new Gson();

    /**
     * ajouter quelque chose au panier
     *
     * @param activity the activity
     * @param pc       the pc
     */
    public static void ajouterAuPanier(Activity activity, PlatCommande pc)
    {
        SharedPreferences sp = activity.getPreferences(Context.MODE_PRIVATE);
        Editor editor = sp.edit();
        Commande c;
        if(sp.getString("platDansPanier", null) != null)
        {
            c = gson.fromJson(sp.getString("platDansPanier", null), Commande.class);
        }
        else
        {
            c = new Commande();
            c.setPlatCommande(new ArrayList<PlatCommande>());
        }
        int quantity = getQuantitePlat(activity, pc);
        if(quantity != 0)
        {
            pc.setQuantite(pc.getQuantite() + quantity);
            pc.setPrixTotalCommande(pc.getQuantite() * pc.getPrix());
            updatePlat(activity, pc);
        }
        else
        {
            c.getPlatCommande().add(pc);
            editor.putString("platDansPanier", gson.toJson(c));
            editor.commit();
        }
        setDateMiseEnPanier(activity);
    }

    /**
     * Obtenir la liste des plats dans le panier
     *
     * @param activity the activity
     * @return list plat in panier
     */
    public static List<PlatCommande> getListPlatInPanier(Activity activity) {
        List<PlatCommande> ret = null;
        SharedPreferences sp = activity.getPreferences(Context.MODE_PRIVATE);
        if(sp.getString("platDansPanier", null) != null)
        {
            Commande c = gson.fromJson(sp.getString("platDansPanier", null), Commande.class);
            ret = c.getPlatCommande();
        }
        else ret = new ArrayList<PlatCommande>();
        return ret;
    }

    /**
     * Gets commande.
     *
     * @param activity the activity
     * @return the commande
     */
    public static Commande getCommande(Activity activity)
    {
        Commande ret = null;
        SharedPreferences sp = activity.getPreferences(Context.MODE_PRIVATE);
        if(sp.getString("platDansPanier", null) != null)
        {
            ret = gson.fromJson(sp.getString("platDansPanier", null), Commande.class);
        }
        else ret = new Commande();
        return ret;
    }

    /**
     * Delete plat commande from panier.
     *
     * @param activity the activity
     * @param pc       the pc
     */
    public static void deletePlatCommandeFromPanier(Activity activity,PlatCommande pc)
    {
        SharedPreferences sp = activity.getPreferences(Context.MODE_PRIVATE);
        Editor editor = sp.edit();
        if(sp.getString("platDansPanier", null) != null)
        {
            Commande c = gson.fromJson(sp.getString("platDansPanier", null), Commande.class);
            List<PlatCommande> lp = c.getPlatCommande();
            PlatCommande aEffacer = pc;
            for(PlatCommande temp : lp)
            {
                if(temp.getNom().compareTo(pc.getNom()) == 0)
                {
                    aEffacer = temp;
                }
            }
            lp.remove(aEffacer);
            editor.putString("platDansPanier", gson.toJson(c));
            editor.commit();
        }
        setDateMiseEnPanier(activity);
    }

    /**
     * Sets quantite plat commande.
     *
     * @param activity the activity
     * @param pc       the pc
     */
    public static void setQuantitePlatCommande(Activity activity, PlatCommande pc)
    {
        SharedPreferences sp = activity.getPreferences(Context.MODE_PRIVATE);
        Editor editor = sp.edit();
        if(sp.getString("platDansPanier", null) != null)
        {
            Commande c = gson.fromJson(sp.getString("platDansPanier", null), Commande.class);
            List<PlatCommande> lp = c.getPlatCommande();
            for(PlatCommande temp : lp)
            {
                if(temp.getNom().compareTo(pc.getNom()) == 0)
                {
                    temp.setQuantite(pc.getQuantite());
                    temp.setPrixTotalCommande(temp.getQuantite()*temp.getPrix());
                }
            }
            editor.putString("platDansPanier", gson.toJson(c));
            editor.commit();
        }
    }

    /**
     * Is empty boolean.
     *
     * @param activity the activity
     * @return the boolean
     */
    public static boolean isEmpty(Activity activity)
    {
        boolean ret = true;
        SharedPreferences sp = activity.getPreferences(Context.MODE_PRIVATE);
        if(sp.getString("platDansPanier", null) != null )
        {
            Commande c = gson.fromJson(sp.getString("platDansPanier", null), Commande.class);
            if(c.getPlatCommande().size() != 0)
            {
                ret = false;
            }
        }
        return ret;
    }

    /**
     * Clear.
     *
     * @param activity the activity
     */
    public static void clear(Activity activity)
    {
        SharedPreferences sp = activity.getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.remove("platDansPanier");
        editor.commit();

    }

    /**
     * Gets quantite plat.
     *
     * @param activity the activity
     * @param plat     the plat
     * @return the quantite plat
     */
    public static int getQuantitePlat(Activity activity, PlatCommande plat)
    {
        int ret = 0;
        SharedPreferences sp = activity.getPreferences(Context.MODE_PRIVATE);
        if(sp.getString("platDansPanier", null) != null )
        {
            Commande c = gson.fromJson(sp.getString("platDansPanier", null), Commande.class);
            for(PlatCommande pc : c.getPlatCommande())
            {
                if(pc.getIdPlat() == plat.getIdPlat())
                {
                    ret = pc.getQuantite();
                    break;
                }
            }
        }
        return ret;
    }

    /**
     * Update plat.
     *
     * @param activity the activity
     * @param pc       the pc
     */
    public static void updatePlat(Activity activity, PlatCommande pc)
    {
        SharedPreferences sp = activity.getPreferences(Context.MODE_PRIVATE);
        Editor editor = sp.edit();
        Commande c = gson.fromJson(sp.getString("platDansPanier", null), Commande.class);
        for(PlatCommande plc : c.getPlatCommande())
        {
            if(pc.getIdPlat() == plc.getIdPlat())
            {
                plc.setQuantite(pc.getQuantite());
                break;
            }
        }
        editor.putString("platDansPanier", gson.toJson(c));
        editor.commit();
    }

    /**
     * Gets nbr item in panier.
     *
     * @param activity the activity
     * @return the nbr item in panier
     */
    public static int getNbrItemInPanier(Activity activity)
    {
        int ret = 0;
        SharedPreferences sp = activity.getPreferences(Context.MODE_PRIVATE);
        if(sp.getString("platDansPanier", null) != null )
        {
            Commande c = gson.fromJson(sp.getString("platDansPanier", null), Commande.class);
            for(PlatCommande pc : c.getPlatCommande())
            {
                ret += pc.getQuantite();
            }
        }
        return ret;
    }

    /**
     * Gets date mise en panier.
     *
     * @param activity the activity
     * @return the date mise en panier
     */
    public static String getDateMiseEnPanier(Activity activity)
    {
        String ret = "";
        SharedPreferences sp = activity.getPreferences(Context.MODE_PRIVATE);
        if(sp.getString("dateMiseEnPanier", null) != null )
        {
            ret = sp.getString("dateMiseEnPanier", null);
        }
        return ret;
    }

    /**
     * Sets date mise en panier.
     *
     * @param activity the activity
     */
    public static void setDateMiseEnPanier(Activity activity)
    {
        SharedPreferences sp = activity.getPreferences(Context.MODE_PRIVATE);
        Editor editor = sp.edit();
        editor.putString("dateMiseEnPanier", UtilitaireDate.getCurrentDate());
        editor.commit();
    }
}
