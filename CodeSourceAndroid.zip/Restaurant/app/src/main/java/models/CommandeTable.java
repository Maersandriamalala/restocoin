package models;

/**
 * Created by ravelosonkiadisoa on 13/04/2016.
 */
public class CommandeTable
{
    /**
     * The Commande.
     */
    public CommandeWS commande;
    /**
     * The Date passage commande.
     */
    public String datePassageCommande;
    /**
     * The Table.
     */
    public Table table;
    /**
     * The Utilisateur.
     */
    public Utilisateur utilisateur;
}
