package models;

import java.util.List;

/**
 * Created by ravelosonkiadisoa on 13/04/2016.
 */
public class CommandeWS
{
    /**
     * The Daty.
     */
    public String daty;
    /**
     * The Est paye.
     */
    public boolean estPaye;
    /**
     * The Quantite.
     */
    public int quantite;
    /**
     * The Total.
     */
    public float total;
    /**
     * The Plats.
     */
    public List<PlatCommande> plats;
}
