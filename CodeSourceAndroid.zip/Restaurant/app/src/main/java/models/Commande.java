package models;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ravelosonkiadisoa on 17/03/2016.
 */

/**
 * Classe representant une commande
 */
public class Commande
{
    private List<PlatCommande> plats = new ArrayList<PlatCommande>();
    private int preferenceService;

    /**
     * Gets preference service.
     *
     * @return the preference service
     */
    public int getPreferenceService() {
        return preferenceService;
    }

    /**
     * Sets preference service.
     *
     * @param preferenceService the preference service
     */
    public void setPreferenceService(int preferenceService) {
        this.preferenceService = preferenceService;
    }

    /**
     * Instantiates a new Commande.
     */
    public Commande()
    {
    }

    /**
     * Instantiates a new Commande.
     *
     * @param listPlatCommande the list plat commande
     */
    public Commande(List<PlatCommande> listPlatCommande)
    {
        this.plats = listPlatCommande;
    }

    /**
     * Gets plat commande.
     *
     * @return the plat commande
     */
    public List<PlatCommande> getPlatCommande()
    {
        return plats;
    }

    /**
     * Sets plat commande.
     *
     * @param platCommande the plat commande
     */
    public void setPlatCommande(List<PlatCommande> platCommande)
    {
        this.plats = platCommande;
    }

    /**
     * Gets commande.
     *
     * @return the commande
     */
    public List<PlatCommande> getCommande()
    {
        return plats;
    }

    /**
     * Delete pc.
     *
     * @param pc the pc
     */
    public void deletePC(PlatCommande pc)
    {
        plats.remove(pc);

    }

    /**
     * Gets total.
     *
     * @return the total
     */
    public float getTotal()
    {
        List<PlatCommande> lp = plats;
        float ret = 0;
        for(PlatCommande p : lp)
        {
            ret += (p.getQuantite() * p.getPrix());
        }
        return ret;
    }
}
