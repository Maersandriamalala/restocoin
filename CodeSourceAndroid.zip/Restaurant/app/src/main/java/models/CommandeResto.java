package models;

/**
 * Created by ravelosonkiadisoa on 12/04/2016.
 */
public class CommandeResto
{
    private String tableName;
    private Utilisateur client;
    private PlatCommande platCommande;
    private boolean paye;

    /**
     * Instantiates a new Commande resto.
     */
    public CommandeResto() {
    }

    /**
     * Instantiates a new Commande resto.
     *
     * @param tableName    the table name
     * @param client       the client
     * @param platCommande the plat commande
     */
    public CommandeResto(String tableName, Utilisateur client, PlatCommande platCommande) {
        this.tableName = tableName;
        this.client = client;
        this.platCommande = platCommande;
    }

    /**
     * Instantiates a new Commande resto.
     *
     * @param tableName    the table name
     * @param client       the client
     * @param platCommande the plat commande
     * @param paye         the paye
     */
    public CommandeResto(String tableName, Utilisateur client, PlatCommande platCommande, boolean paye) {
        this.tableName = tableName;
        this.client = client;
        this.platCommande = platCommande;
        this.paye = paye;
    }

    /**
     * Gets table name.
     *
     * @return the table name
     */
    public String getTableName() {
        return tableName;
    }

    /**
     * Sets table name.
     *
     * @param tableName the table name
     */
    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    /**
     * Gets client.
     *
     * @return the client
     */
    public Utilisateur getClient() {
        return client;
    }

    /**
     * Sets client.
     *
     * @param client the client
     */
    public void setClient(Utilisateur client) {
        this.client = client;
    }

    /**
     * Gets plat commande.
     *
     * @return the plat commande
     */
    public PlatCommande getPlatCommande() {
        return platCommande;
    }

    /**
     * Sets plat commande.
     *
     * @param platCommande the plat commande
     */
    public void setPlatCommande(PlatCommande platCommande) {
        this.platCommande = platCommande;
    }

    /**
     * Is paye boolean.
     *
     * @return the boolean
     */
    public boolean isPaye() {
        return paye;
    }

    /**
     * Sets paye.
     *
     * @param paye the paye
     */
    public void setPaye(boolean paye) {
        this.paye = paye;
    }
}
