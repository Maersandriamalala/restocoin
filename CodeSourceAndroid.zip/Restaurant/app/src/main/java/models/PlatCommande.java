package models;
import java.io.Serializable;

/**
 * Created by ravelosonkiadisoa on 15/03/2016.
 */
public class PlatCommande implements Serializable
{
    private long idPlat;
    private String nom;
    private int quantite;
    private String image;
    private String description;
    private float prix;
    private float prixTotalCommande;
    private int tempsCuisson;
    private String ingredients;

    /**
     * Instantiates a new Plat commande.
     */
    public PlatCommande() {
    }

    /**
     * Instantiates a new Plat commande.
     *
     * @param nom               the nom
     * @param quantite          the quantite
     * @param image             the image
     * @param description       the description
     * @param prix              the prix
     * @param prixTotalCommande the prix total commande
     * @param tempsCuisson      the temps cuisson
     * @param ingredients       the ingredients
     */
    public PlatCommande(String nom, int quantite, String image, String description, float prix, float prixTotalCommande, int tempsCuisson, String ingredients) {
        this.nom = nom;
        this.quantite = quantite;
        this.image = image;
        this.description = description;
        this.prix = prix;
        this.prixTotalCommande = prixTotalCommande;
        this.tempsCuisson = tempsCuisson;
        this.ingredients = ingredients;
    }

    /**
     * Instantiates a new Plat commande.
     *
     * @param idPlat            the id plat
     * @param nom               the nom
     * @param quantite          the quantite
     * @param image             the image
     * @param description       the description
     * @param prix              the prix
     * @param prixTotalCommande the prix total commande
     * @param tempsCuisson      the temps cuisson
     * @param ingredients       the ingredients
     */
    public PlatCommande(long idPlat, String nom, int quantite, String image, String description, float prix, float prixTotalCommande, int tempsCuisson, String ingredients) {
        this.idPlat = idPlat;
        this.nom = nom;
        this.quantite = quantite;
        this.image = image;
        this.description = description;
        this.prix = prix;
        this.prixTotalCommande = prixTotalCommande;
        this.tempsCuisson = tempsCuisson;
        this.ingredients = ingredients;
    }

    /**
     * Gets id plat.
     *
     * @return the id plat
     */
    public long getIdPlat() {
        return idPlat;
    }

    /**
     * Sets id plat.
     *
     * @param idPlat the id plat
     */
    public void setIdPlat(long idPlat) {
        this.idPlat = idPlat;
    }

    /**
     * Gets nom.
     *
     * @return the nom
     */
    public String getNom() {
        return nom;
    }

    /**
     * Sets nom.
     *
     * @param nom the nom
     */
    public void setNom(String nom) {
        this.nom = nom;
    }

    /**
     * Gets quantite.
     *
     * @return the quantite
     */
    public int getQuantite() {
        return quantite;
    }

    /**
     * Sets quantite.
     *
     * @param quantite the quantite
     */
    public void setQuantite(int quantite) {
        this.quantite = quantite;
    }

    /**
     * Gets image.
     *
     * @return the image
     */
    public String getImage() {
        return image;
    }

    /**
     * Sets image.
     *
     * @param image the image
     */
    public void setImage(String image) {
        this.image = image;
    }

    /**
     * Gets description.
     *
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets description.
     *
     * @param description the description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Gets prix.
     *
     * @return the prix
     */
    public float getPrix() {
        return prix;
    }

    /**
     * Sets prix.
     *
     * @param prix the prix
     */
    public void setPrix(float prix) {
        this.prix = prix;
    }

    /**
     * Gets prix total commande.
     *
     * @return the prix total commande
     */
    public float getPrixTotalCommande() {
        return prixTotalCommande;
    }

    /**
     * Sets prix total commande.
     *
     * @param prixTotalCommande the prix total commande
     */
    public void setPrixTotalCommande(float prixTotalCommande) {
        this.prixTotalCommande = prixTotalCommande;
    }

    /**
     * Gets temps cuisson.
     *
     * @return the temps cuisson
     */
    public int getTempsCuisson() {
        return tempsCuisson;
    }

    /**
     * Sets temps cuisson.
     *
     * @param tempsCuisson the temps cuisson
     */
    public void setTempsCuisson(int tempsCuisson) {
        this.tempsCuisson = tempsCuisson;
    }

    /**
     * Gets ingredients.
     *
     * @return the ingredients
     */
    public String getIngredients() {
        return ingredients;
    }

    /**
     * Sets ingredients.
     *
     * @param ingredients the ingredients
     */
    public void setIngredients(String ingredients) {
        this.ingredients = ingredients;
    }
}
