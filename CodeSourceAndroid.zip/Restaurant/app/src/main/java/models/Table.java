package models;

import java.io.Serializable;

/**
 * Created by ravelosonkiadisoa on 30/03/2016.
 */
public class Table implements Serializable
{
    /**
     * The Id.
     */
    public String _id;
    /**
     * The Id tag nfc.
     */
    public String idTagNfc;
    /**
     * The Nbr place.
     */
    public long nbrPlace;
    /**
     * The Nom.
     */
    public String nom;
    /**
     * The Numero.
     */
    public long numero;
    /**
     * The Addition.
     */
    public float addition;

}
