package models;

/**
 * Created by ravelosonkiadisoa on 12/04/2016.
 */
public class Utilisateur
{
    private String _id;
    private String nom;
    private String idTagNfc;

    /**
     * Instantiates a new Utilisateur.
     */
    public Utilisateur() {
    }

    /**
     * Gets id.
     *
     * @return the id
     */
    public String get_id() {
        return _id;
    }

    /**
     * Sets id.
     *
     * @param objectId the object id
     */
    public void set_id(String objectId) {
        this._id = objectId;
    }

    /**
     * Gets nom.
     *
     * @return the nom
     */
    public String getNom() {
        return nom;
    }

    /**
     * Sets nom.
     *
     * @param nom the nom
     */
    public void setNom(String nom) {
        this.nom = nom;
    }

    /**
     * Gets id tag nfc.
     *
     * @return the id tag nfc
     */
    public String getIdTagNFC() {
        return idTagNfc;
    }

    /**
     * Sets id tag nfc.
     *
     * @param tagUID the tag uid
     */
    public void setIdTagNFC(String tagUID) {
        this.idTagNfc = tagUID;
    }
}
