package models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by ravelosonkiadisoa on 15/03/2016.
 */
public class Plat implements Serializable
{
    private long id;
    private long idType;
    private String idInNode;
    private String nom;
    private String image;
    private String ingredients;
    private int tempCuissonMin;
    private int tempCuissonMax;
    private float prix;
    private String description;

    /**
     * Gets description.
     *
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets description.
     *
     * @param description the description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Gets id type.
     *
     * @return the id type
     */
    public long getIdType() {
        return idType;
    }

    /**
     * Sets id type.
     *
     * @param idType the id type
     */
    public void setIdType(long idType) {
        this.idType = idType;
    }


    /**
     * Instantiates a new Plat.
     */
    public Plat() {
    }

    /**
     * Instantiates a new Plat.
     *
     * @param nom         the nom
     * @param ingredients the ingredients
     */
    public Plat(String nom, String ingredients)
    {
        this.setNom(nom);
        this.setIngredients(ingredients);
    }

    /**
     * Instantiates a new Plat.
     *
     * @param nom         the nom
     * @param ingredients the ingredients
     * @param prix        the prix
     */
    public Plat(String nom, String ingredients, float prix)
    {
        this.setNom(nom);
        this.setIngredients(ingredients);
        this.setPrix(prix);
    }

    /**
     * Instantiates a new Plat.
     *
     * @param id          the id
     * @param nom         the nom
     * @param ingredients the ingredients
     * @param prix        the prix
     * @param tMin        the t min
     * @param tMax        the t max
     */
    public Plat(long id,String nom, String ingredients, float prix, int tMin, int tMax)
    {
        this.setId(id);
        this.setNom(nom);
        this.setIngredients(ingredients);
        this.setPrix(prix);
        this.setTempCuissonMin(tMin);
        this.setTempCuissonMax(tMax);
    }

    /**
     * Instantiates a new Plat.
     *
     * @param idType         the id type
     * @param idInNode       the id in node
     * @param nom            the nom
     * @param image          the image
     * @param ingredients    the ingredients
     * @param tempCuissonMin the temp cuisson min
     * @param tempCuissonMax the temp cuisson max
     * @param prix           the prix
     */
    public Plat(long idType, String idInNode, String nom, String image, String ingredients, int tempCuissonMin, int tempCuissonMax, float prix) {

        this.idType = idType;
        this.idInNode = idInNode;
        this.nom = nom;
        this.image = image;
        this.setIngredients(ingredients);
        this.tempCuissonMin = tempCuissonMin;
        this.tempCuissonMax = tempCuissonMax;
        this.prix = prix;
    }

    /**
     * Instantiates a new Plat.
     *
     * @param idType         the id type
     * @param idInNode       the id in node
     * @param nom            the nom
     * @param image          the image
     * @param ingredients    the ingredients
     * @param tempCuissonMin the temp cuisson min
     * @param tempCuissonMax the temp cuisson max
     * @param prix           the prix
     * @param description    the description
     */
    public Plat(long idType, String idInNode, String nom, String image, String ingredients, int tempCuissonMin, int tempCuissonMax, float prix, String description) {

        this.idType = idType;
        this.idInNode = idInNode;
        this.nom = nom;
        this.image = image;
        this.setIngredients(ingredients);
        this.tempCuissonMin = tempCuissonMin;
        this.tempCuissonMax = tempCuissonMax;
        this.prix = prix;
        this.description = description;
    }

    /**
     * Gets prix.
     *
     * @return the prix
     */
    public float getPrix() { return prix;}

    /**
     * Gets nom.
     *
     * @return the nom
     */
    public String getNom() { return this.nom;}

    /**
     * Gets ingredients.
     *
     * @return the ingredients
     */
    public String getIngredients() { return this.ingredients;}

    /**
     * Gets temp cuisson min.
     *
     * @return the temp cuisson min
     */
    public int getTempCuissonMin() { return tempCuissonMin;}

    /**
     * Gets temp cuisson max.
     *
     * @return the temp cuisson max
     */
    public int getTempCuissonMax() {return tempCuissonMax;}

    /**
     * Sets nom.
     *
     * @param nom the nom
     */
    public void setNom(String nom) {
        this.nom = nom;
    }

    /**
     * Sets ingredients.
     *
     * @param ingredients the ingredients
     */
    public void setIngredients(String ingredients) {
        this.ingredients = ingredients;
    }

    /**
     * Sets prix.
     *
     * @param prix the prix
     */
    public void setPrix(float prix) {
        this.prix = prix;
    }

    /**
     * Sets temp cuisson min.
     *
     * @param tempCuissonMin the temp cuisson min
     */
    public void setTempCuissonMin(int tempCuissonMin) {
        this.tempCuissonMin = tempCuissonMin;
    }

    /**
     * Sets temp cuisson max.
     *
     * @param tempCuissonMax the temp cuisson max
     */
    public void setTempCuissonMax(int tempCuissonMax) {
        this.tempCuissonMax = tempCuissonMax;
    }

    /**
     * Gets plat.
     *
     * @return the plat
     */
    public static List<Plat> getPlat()
    {
        List<Plat> ret = new ArrayList<Plat>();
        for (int i = 1; i <= 15; i ++)
        {
            Plat plat = new Plat(0 ,"Plat numero " + i, "(Ingredient1, Ingredient2, Ingredient3, Ingredient4, Ingredient5,...)" , 10000, 10, 25);
            ret.add(plat);
        }
        return ret;
    }

    /**
     * Gets id in node.
     *
     * @return the id in node
     */
    public String getIdInNode() {
        return idInNode;
    }

    /**
     * Sets id in node.
     *
     * @param idInNode the id in node
     */
    public void setIdInNode(String idInNode) {
        this.idInNode = idInNode;
    }

    /**
     * Gets image.
     *
     * @return the image
     */
    public String getImage() {
        return image;
    }

    /**
     * Sets image.
     *
     * @param image the image
     */
    public void setImage(String image) {
        this.image = image;
    }

    /**
     * Gets id.
     *
     * @return the id
     */
    public long getId() {
        return id;
    }

    /**
     * Sets id.
     *
     * @param id the id
     */
    public void setId(long id) {
        this.id = id;
    }
}
