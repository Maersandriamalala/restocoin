package fragments.fragmentSplashscreen;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import com.google.gson.Gson;

import java.io.IOException;

import activities.MainActivity;
import kiadi.restaurant.R;
import metiers.dao.DatabaseHelper;
import services.NouritureService;

/**
 * Created by ravelosonkiadisoa on 25/03/2016.
 */

/**
 * Fragment pour le splashscreen
 */
public class SplashScreenFragment extends Fragment
{
    private ProgressDialog pDialog;
    private Gson gson = new Gson();
    private int progression = 0;
    private DatabaseHelper db;
    private ProgressBar progressBar;
    private MainActivity activity;
    private Thread t = new Thread(new Runnable()
    {
        public void run()
        {
            while (progression <= progressBar.getMax())
            {
                try
                {
                    if (progression == progressBar.getMax())
                    {
                        activity.runOnUiThread(new Runnable() {
                            public void run()
                            {
                                try
                                {
                                    activity.mainActivityManager.displayViewFromSplashScreen();
                                }
                                catch (IllegalStateException ise)
                                {

                                    ise.printStackTrace();
                                    activity.recreate();
                                }
                            }
                        });
                    }
                    progressBar.setProgress(progression + 1);
                    if (progressBar.getProgress() == 70) Thread.sleep(400);
                        Thread.sleep(30);
                }
                catch (InterruptedException e)
                {
                    e.printStackTrace();
                }
                progression++;
            }
        }
    });

    /**
     * Instantiates a new Splash screen fragment.
     */
    public SplashScreenFragment()
    {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View rootView = inflater.inflate(R.layout.splash_screen_layout, container, false);
        activity = (MainActivity) getActivity();
        progressBar = (ProgressBar) rootView.findViewById(R.id.progressBar);
        db = DatabaseHelper.getInstance(getActivity());
        progressBar = (ProgressBar) rootView.findViewById(R.id.progressBar);
        try
        {
            db.create();
            NouritureService nouritureService = new NouritureService(activity);
            nouritureService.remplireBase();
        }
        catch (IOException ioe)
        {
            //throw new Error("Can't create database");
        }
        t.start();
        // Inflate the layout for this fragment
        return rootView;
    }

    @Override
    public void onAttach(Activity activity)
    {
        super.onAttach(activity);

    }

    @Override
    public void onDetach()
    {
        super.onDetach();
    }
}
