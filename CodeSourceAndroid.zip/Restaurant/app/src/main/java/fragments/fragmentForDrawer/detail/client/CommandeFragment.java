package fragments.fragmentForDrawer.detail.client;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.RelativeLayout;

import java.util.ArrayList;
import java.util.List;

import activities.MainActivity;
import fragments.fragmentForDrawer.detail.BaseCommandeFragment;
import kiadi.restaurant.R;
import models.PlatCommande;
import utilitaires.UtilitaireNombres;
import utilitaires.UtilitaireTable;

/**
 * Created by ravelosonkiadisoa on 16/03/2016.
 */

/**
 * Fragment pour l'écran illustrant les commandes du client
 */
public class CommandeFragment extends BaseCommandeFragment
{
    /**
     * Instantiates a new Commande fragment.
     */
    public CommandeFragment()
    {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {

        activity = (MainActivity)getActivity();
        rootView = inflater.inflate(R.layout.commande_layout, container, false);
        mWebView = (WebView) rootView.findViewById(R.id.commande_webview);
        commandeVideLayout = (RelativeLayout) rootView.findViewById(R.id.commandeVideLayout);
        listCommande = new ArrayList<PlatCommande>();
        commandeVideLayout.setVisibility(View.GONE);
        mWebView.setVisibility(View.GONE);
        activity.waitingDialog.show();
        if(UtilitaireTable.getTableTag(activity)!=null && UtilitaireTable.getTableTag(activity).compareTo("")!=0)
            activity.commandeService.getCommandeByTableUID(UtilitaireTable.getTable(activity), this);
        else activity.mainActivityManager.showDialogAskingForTableTag();
        return rootView;
    }

    /**
     * Chargement des données dans le webview
     */
    public void loadDataIntoHTML()
    {
        loadTitle();
        loadBody(listCommande);
        loadTotal();
    }
    public void loadBody(List<PlatCommande> listCommande)
    {
        String body = "";
        for(PlatCommande plat : listCommande)
        {
            body += "<tr>";
            body += "<td class=\"quantiteVal\">" + plat.getQuantite() + "</td>";
            body += "<td class=\"platVal\">" + plat.getNom() + "</td>";
            body += "<td class=\"prixVal\">" + UtilitaireNombres.addThousandSeparator(plat.getPrixTotalCommande()) + "Ar" + "</td>";
            body += "</tr>";
        }
        html = html.replace("$body", body);
    }
    public void loadTotal()
    {
        String totalString = UtilitaireNombres.addThousandSeparator(total);
        html = html.replace("$total", totalString + " Ar");
        activity.totalInPanier.setText("Total = " + totalString + "Ar");
    }
    public void loadTitle()
    {
        html = html.replace("$quantiteTitle", activity.getResources().getString(R.string.quantiteTitle));
        html = html.replace("$platTitle", activity.getResources().getString(R.string.designation));
        html = html.replace("$prixTitle", activity.getResources().getString(R.string.prixTitle));
    }
    @Override
    public void onAttach(Activity activity)
    {
        super.onAttach(activity);
    }

    @Override
    public void onDetach()
    {
        super.onDetach();
    }
}