package fragments.fragmentForDrawer.detail;

import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.webkit.WebView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import activities.MainActivity;
import kiadi.restaurant.R;
import models.PlatCommande;
import models.Utilisateur;
import utilitaires.UtilitaireNombres;

/**
 * Created by ravelosonkiadisoa on 14/04/2016.
 */

/**
 * Base classe des classes commandes
 */
public class BaseCommandeFragment extends Fragment
{
    /**
     * The Le client.
     */
    public Utilisateur leClient = null;
    /**
     * The L layout.
     */
    public LinearLayoutManager lLayout;
    /**
     * The M recycler view.
     */
    public RecyclerView mRecyclerView;
    /**
     * The M adapter.
     */
    public RecyclerView.Adapter mAdapter;
    /**
     * The M layout manager.
     */
    public RecyclerView.LayoutManager mLayoutManager;
    /**
     * The Activity.
     */
    protected MainActivity activity;
    /**
     * The M web view.
     */
    public WebView mWebView;
    /**
     * The Html.
     */
    public String html;
    /**
     * The List commande.
     */
    public List<PlatCommande> listCommande;
    /**
     * The Commande vide layout.
     */
    public RelativeLayout commandeVideLayout;
    /**
     * The Root view.
     */
    public View rootView;
    /**
     * The Total.
     */
    public float total;

    /**
     * Gets file as string.
     *
     * @param fileName the file name
     * @return the file as string
     */
    public String getFileAsString(String fileName)
    {
        activity = (MainActivity) getActivity();
        InputStream input;
        html = "";
        try
        {
            input = activity.assetManager.open(fileName);

            int size = input.available();

            byte[] buffer = new byte[size];

            int bytesRead = input.read(buffer);

            input.close();

            html = new String(buffer, 0, bytesRead, "UTF-8");

        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

        return html;
    }

    /**
     * Chargement des données dans le html
     *
     * @param leClient the le client
     */
    public void loadDataIntoHTML(Utilisateur leClient)
    {
        loadTitle();
        loadBody(listCommande);
        loadTotal();
        this.leClient = leClient;
    }

    /**
     * Load body.
     *
     * @param listCommande the list commande
     */
    public void loadBody(List<PlatCommande> listCommande)
    {
        String body = "";
        for(PlatCommande plat : listCommande)
        {
            body += "<tr>";
            body += "<td class=\"quantiteVal\">" + plat.getQuantite() + "</td>";
            body += "<td class=\"platVal\">" + plat.getNom() + "</td>";
            body += "<td class=\"prixVal\">" + UtilitaireNombres.addThousandSeparator(plat.getPrixTotalCommande()) + "Ar" + "</td>";
            body += "</tr>";
        }
        html = html.replace("$body", body);
    }

    /**
     * Load total.
     */
    public void loadTotal()
    {
        String totalString = UtilitaireNombres.addThousandSeparator(total);
        activity.totalLayout.setVisibility(View.VISIBLE);
        activity.totalInPanier.setVisibility(View.VISIBLE);
        activity.totalInPanier.setText("Total = " + totalString + "Ar");
        if(this instanceof fragments.fragmentForDrawer.detail.client.CommandeFragment)
        {
            html = html.replace("$total", totalString + " Ar");
        }
        else html = html.replace("$total", "");
    }

    /**
     * Load title.
     */
    public void loadTitle()
    {
        html = html.replace("$quantiteTitle", activity.getResources().getString(R.string.quantiteTitle));
        html = html.replace("$platTitle", activity.getResources().getString(R.string.designation));
        html = html.replace("$prixTitle", activity.getResources().getString(R.string.prixTitle));
    }
}
