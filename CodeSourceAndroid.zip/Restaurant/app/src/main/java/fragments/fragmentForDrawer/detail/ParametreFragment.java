package fragments.fragmentForDrawer.detail;

import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.preference.ListPreference;
import java.util.Locale;
import utilitaires.PreferenceFragment;
import kiadi.restaurant.R;
import utilitaires.UtilitaireLangue;

/**
 * Created by ravelosonkiadisoa on 26/03/2016.
 */

/**
 * Fragment pour l'écran de préférence
 */
public class ParametreFragment extends PreferenceFragment implements SharedPreferences.OnSharedPreferenceChangeListener
{
    private ListPreference listeLanguePreference;
    private final int positionFrancais = 0;
    private final int positionAnglais = 1;
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        // Load the preferences from an XML resource
        addPreferencesFromResource(R.xml.preferences);
        listeLanguePreference = (ListPreference) getPreferenceScreen().findPreference("langueList");

        if(UtilitaireLangue.getLangueEnCours(getActivity()).compareTo("en") == 0)
        {
            listeLanguePreference.setValueIndex(1);
            listeLanguePreference.setSummary(getResources().getString(R.string.anglais));
        }
        else
        {
            listeLanguePreference.setValueIndex(0);
            listeLanguePreference.setSummary(getResources().getString(R.string.francais));
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        // Set up a listener whenever a key changes
        getPreferenceScreen().getSharedPreferences().registerOnSharedPreferenceChangeListener(this);

    }

    @Override
    public void onPause() {
        super.onPause();
        // Set up a listener whenever a key changes
        getPreferenceScreen().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(this);
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key)
    {
        if (key.equals("langueList"))
        {
            String langue = "fr";
            switch (Integer.parseInt(listeLanguePreference.getValue()))
            {
                case positionAnglais:
                    langue = "en";
                    listeLanguePreference.setSummary(getResources().getString(R.string.anglais));
                    break;
                case positionFrancais:
                    langue = "fr";
                    listeLanguePreference.setSummary(getResources().getString(R.string.francais));
                    break;
                default:
                    break;
            }
            UtilitaireLangue.setLangueEnCours(getActivity(), langue);

            Locale locale = new Locale(langue);
            Locale.setDefault(locale);
            Configuration config = new Configuration();
            config.locale = locale;
            getResources().updateConfiguration(config, null);
            getActivity().recreate();
        }
    }
}