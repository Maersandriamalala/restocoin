package fragments.fragmentForDrawer.detail.client;

import android.app.Activity;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import activities.MainActivity;
import kiadi.restaurant.R;
import listeners.BoutonAjoutPanierListener;
import listeners.BoutonMoinsDetailListener;
import listeners.BoutonPlusDetailListener;
import models.Plat;
import utilitaires.UtilitaireView;

/**
 * Created by ravelosonkiadisoa on 16/03/2016.
 */

/**
 * Fragment pour l'écran détails des plats
 */
public class DetailPlatFragment extends Fragment
{
    private Plat plat;
    private EditText quantite;
    private Button btnMoins;
    private Button btnPlus;
    private RelativeLayout relativeBtnAjouterAuPanier;
    private MainActivity activity;
    private TextView tempsCuisson;
    private TextView ingredients;
    private View rootView;
    private ImageView imagePlat;
    private Button btnAjouterPanier2;

    /**
     * Instantiates a new Detail plat fragment.
     */
    public DetailPlatFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        //plat = savedInstanceState.getParcelable("plat");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        activity = (MainActivity)getActivity();
        rootView = inflater.inflate(R.layout.detail_plat_layout, container, false);
        plat = (Plat)this.getArguments().getSerializable("plat");
        ((TextView) rootView.findViewById(R.id.platNomDetail)).setText(plat.getNom());
        String tempsCuissonLabel = plat.getTempCuissonMin() + " " + getResources().getString(R.string.a) + " " + plat.getTempCuissonMax() + " minutes";

        quantite = (EditText) rootView.findViewById(R.id.quantite);
        tempsCuisson = (TextView) rootView.findViewById(R.id.tempsDeCuisson);

        tempsCuisson.setText(tempsCuissonLabel);

        ingredients = (TextView) rootView.findViewById(R.id.ingredients);
        ingredients.setText(plat.getIngredients());

        btnMoins = (Button) rootView.findViewById(R.id.btnMoins);
        btnMoins.setOnClickListener(new BoutonMoinsDetailListener(quantite));
        btnPlus = (Button) rootView.findViewById(R.id.btnPlus);
        btnPlus.setOnClickListener(new BoutonPlusDetailListener(quantite));
        btnAjouterPanier2 = (Button) rootView.findViewById(R.id.btnAjoutPanier2);
        relativeBtnAjouterAuPanier = (RelativeLayout) rootView.findViewById(R.id.relativeBtnAjouterAuPanier);
        relativeBtnAjouterAuPanier.setOnClickListener(new BoutonAjoutPanierListener(quantite, activity, plat));
        btnAjouterPanier2.setOnClickListener(new BoutonAjoutPanierListener(quantite, activity, plat));
        imagePlat = (ImageView) rootView.findViewById(R.id.imagePlat);
        Log.d("image", plat.getImage());
        Picasso.with(activity)
                .load(plat.getImage())
                .placeholder(R.drawable.ic_plat_detail) // optional
                .error(R.drawable.ic_plat_detail)         // optional
                .into(imagePlat);
        if(UtilitaireView.getOrientationScreen(getActivity()) == Configuration.ORIENTATION_LANDSCAPE)
        {
            btnAjouterPanier2.setVisibility(View.VISIBLE);
        }
        else if(UtilitaireView.getOrientationScreen(getActivity()) == Configuration.ORIENTATION_PORTRAIT)
        {
            btnAjouterPanier2.setVisibility(View.GONE);
        }

        // Inflate the layout for this fragment
        return rootView;
    }
    @Override
    public void onConfigurationChanged(Configuration newConfig)
    {
        super.onConfigurationChanged(newConfig);
        if(newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE)
        {
            btnAjouterPanier2.setVisibility(View.VISIBLE);
        }
        else if(newConfig.orientation == Configuration.ORIENTATION_PORTRAIT)
        {
            btnAjouterPanier2.setVisibility(View.GONE);
        }
    }
    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }
}