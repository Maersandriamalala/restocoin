package fragments.fragmentForDrawer.detail.client;

import android.app.Activity;
import android.graphics.Color;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.getbase.floatingactionbutton.FloatingActionButton;
import com.getbase.floatingactionbutton.FloatingActionsMenu;

import java.util.ArrayList;

import activities.MainActivity;
import adapters.ActionTabsViewPagerAdapter;
import fragments.fragmentForTab.BoissonTabFragment;
import fragments.fragmentForTab.DessertTabFragment;
import fragments.fragmentForTab.DiversTabFragment;
import fragments.fragmentForTab.EntreeTabFragment;
import fragments.fragmentForTab.PlatTabFragment;
import listeners.BoutonAfficherPanierListener;
import utilitaires.UtilitaireView;
import views.SlidingTabLayout;
import kiadi.restaurant.R;
/**
 * Created by ravelosonkiadisoa on 15/03/2016.
 */

/**
 * Fragment pour l'écran des cartes
 */
public class CarteFragment extends Fragment
{
    private SlidingTabLayout slidingTabLayout;
    private ViewPager viewPager;
    private ArrayList<Fragment> fragments;
    private ActionTabsViewPagerAdapter myViewPageAdapter;
    private FloatingActionsMenu multiple_actions;
    private FloatingActionButton floatButtonPanier;
    private FloatingActionButton floatButtonSearch;
    private MainActivity activity;
    private View rootView;

    /**
     * Instantiates a new Carte fragment.
     */
    public CarteFragment()
    {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        String className = this.getClass().getName();

    }

    //@Override
    //public void onResume(Bundle savedInstaceState)
    //{
    //    Toast.makeText(MainActivity.context,"resumeExercice",Toast.LENGTH_SHORT).show();
    //}
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {

        rootView = inflater.inflate(R.layout.carte_layout, container, false);

        activity = (MainActivity) getActivity();
        activity.waitingDialog.show();
        fragments = new ArrayList<Fragment>();

        fragments.add(new PlatTabFragment());

        fragments.add(new EntreeTabFragment());

        fragments.add(new DessertTabFragment());

        fragments.add(new BoissonTabFragment());

        fragments.add(new DiversTabFragment());

        slidingTabLayout = (SlidingTabLayout) rootView.findViewById(R.id.tab);
        slidingTabLayout.setBackgroundColor(Color.parseColor("#ffffff"));
        slidingTabLayout.setSelectedIndicatorColors(Color.parseColor("#0099cc"));

        viewPager = (ViewPager) rootView.findViewById(R.id.viewpager);

        multiple_actions = ((FloatingActionsMenu) rootView.findViewById(R.id.multiple_actions));
        floatButtonPanier = (FloatingActionButton)rootView.findViewById(R.id.floatButtonPanier);
        floatButtonPanier.setIconDrawable(UtilitaireView.convertColorDrawable(R.drawable.ic_panier, Color.parseColor("#FFFFFF"), getActivity()));
        floatButtonSearch = (FloatingActionButton)rootView.findViewById(R.id.floatButtonSearch);
         floatButtonSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(activity, "Fonctionnalité en cours de finalisation", Toast.LENGTH_SHORT).show();
            }
        });
        floatButtonPanier.setOnClickListener(new BoutonAfficherPanierListener(activity));
        configOnglet();
        activity.waitingDialog.dismiss();
        return rootView;
    }
    /**
     * Configuration des onglets des plats
     */
    private void configOnglet()
    {
        myViewPageAdapter = new ActionTabsViewPagerAdapter(getChildFragmentManager(), fragments, getActivity());

        viewPager.setAdapter(myViewPageAdapter);

        slidingTabLayout.setDistributeEvenly(true);

        slidingTabLayout.setViewPager(viewPager);
    }

    /**
     * Gestion des evennements de clicks des floatingButton
     *
     * @param v the v
     */
    public void onClick(View v)
    {
        switch (v.getId()) {
            case R.id.floatButtonSearch:
                ((FloatingActionsMenu) rootView.findViewById(R.id.multiple_actions)).collapse();
                //Toast.makeText(this, "Passer la commande", Toast.LENGTH_SHORT).show();
                break;
            case R.id.btnMessage:
                activity.mainActivityManager.afficherContact();
                break;
            default:
                break;
        }
    }
    @Override
    public void onAttach(Activity activity)
    {
        super.onAttach(activity);
    }

    @Override
    public void onDetach()
    {
        super.onDetach();
    }
}