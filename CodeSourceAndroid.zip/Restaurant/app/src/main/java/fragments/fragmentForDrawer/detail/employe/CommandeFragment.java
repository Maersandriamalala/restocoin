package fragments.fragmentForDrawer.detail.employe;

import android.app.Activity;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.RelativeLayout;

import java.util.ArrayList;

import activities.MainActivity;
import fragments.fragmentForDrawer.detail.BaseCommandeFragment;
import fragments.fragmentForDrawer.detail.client.DetailPlatFragment;
import kiadi.restaurant.R;
import listeners.BoutonPayerListener;
import models.Plat;
import models.PlatCommande;
import models.Table;
import utilitaires.UtilitaireTable;

/**
 * Created by ravelosonkiadisoa on 16/03/2016.
 */

/**
 * Fragment pour l'écran affichant tous les commandes en cours
 */
public class CommandeFragment extends BaseCommandeFragment
{
    /**
     * The Table.
     */
    public Table table;
    /**
     * The Btn payer.
     */
    public FloatingActionButton btnPayer;
    private MainActivity activity;

    /**
     * Instantiates a new Commande fragment.
     */
    public CommandeFragment()
    {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        activity = (MainActivity)getActivity();
        rootView = inflater.inflate(R.layout.commande_addition_layout, container, false);
        mWebView = (WebView) rootView.findViewById(R.id.commande_webview);
        commandeVideLayout = (RelativeLayout) rootView.findViewById(R.id.commandeVideLayout);
        listCommande = new ArrayList<PlatCommande>();
        commandeVideLayout.setVisibility(View.GONE);
        mWebView.setVisibility(View.GONE);
        activity.waitingDialog.show();
        table = (Table)this.getArguments().getSerializable("table");
        activity.commandeService.getCommandeByTableUID(table, this);
        btnPayer = (FloatingActionButton) rootView.findViewById(R.id.btnPayer);
        btnPayer.setOnClickListener(new BoutonPayerListener(activity, this));
        return rootView;
    }

    @Override
    public void onAttach(Activity activity)
    {
        super.onAttach(activity);
    }

    @Override
    public void onDetach()
    {
        super.onDetach();
    }
}