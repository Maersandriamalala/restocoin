package fragments.fragmentForDrawer.detail.employe;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import kiadi.restaurant.R;

/**
 * Created by ravelosonkiadisoa on 06/04/2016.
 */

/**
 * Fragment pour l'écran à propos de l'application
 */
public class DemandeTagFragment extends Fragment
{
    /**
     * Instantiates a new Demande tag fragment.
     */
    public DemandeTagFragment()
    {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View rootView = inflater.inflate(R.layout.demande_tag_echange_jeton, container, false);
        return rootView;
    }

    @Override
    public void onAttach(Activity activity)
    {
        super.onAttach(activity);
    }

    @Override
    public void onDetach()
    {
        super.onDetach();
    }
}
