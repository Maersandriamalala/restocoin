package fragments.fragmentForDrawer.detail.employe;

import android.app.Activity;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import activities.MainActivity;
import kiadi.restaurant.R;
import listeners.BoutonAjoutPanierListener;
import listeners.BoutonCommanderContreJetonListener;
import listeners.BoutonMoinsDetailListener;
import listeners.BoutonPlusDetailListener;
import models.Plat;
import utilitaires.UtilitaireView;

/**
 * Created by ravelosonkiadisoa on 16/03/2016.
 */

/**
 * Fragment pour l'écran affichant le detail du plat à échanger
 */
public class DetailPlatEchangeFragment extends Fragment
{
    /**
     * The Plat.
     */
    public Plat plat;
    private Button btnCommander;
    private MainActivity activity;
    private TextView tempsCuisson;
    private TextView ingredients;
    private View rootView;
    private ImageView imagePlat;
    /**
     * The Valeur jeton.
     */
    public float valeurJeton;
    /**
     * The Client id tag nfc.
     */
    public String clientIdTagNfc;

    /**
     * Instantiates a new Detail plat echange fragment.
     */
    public DetailPlatEchangeFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        //plat = savedInstanceState.getParcelable("plat");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        activity = (MainActivity)getActivity();
        rootView = inflater.inflate(R.layout.detail_plat_echange_jeton, container, false);
        plat = (Plat)this.getArguments().getSerializable("plat");
        valeurJeton = this.getArguments().getFloat("valeur");
        clientIdTagNfc = this.getArguments().getString("clientIdTagNfc");
        ((TextView) rootView.findViewById(R.id.platNomDetail)).setText(plat.getNom());
        String tempsCuissonLabel = plat.getTempCuissonMin() + " " + getResources().getString(R.string.a) + " " + plat.getTempCuissonMax() + " minutes";

        tempsCuisson = (TextView) rootView.findViewById(R.id.tempsDeCuisson);

        tempsCuisson.setText(tempsCuissonLabel);

        ingredients = (TextView) rootView.findViewById(R.id.ingredients);
        ingredients.setText(plat.getIngredients());
        btnCommander = (Button) rootView.findViewById(R.id.btnCommanderContreJeton);
        btnCommander.setOnClickListener(new BoutonCommanderContreJetonListener(this, activity));
        imagePlat = (ImageView) rootView.findViewById(R.id.imagePlat);
        Log.d("image", plat.getImage());
        Picasso.with(activity)
                .load(plat.getImage())
                .placeholder(R.drawable.ic_plat_detail) // optional
                .error(R.drawable.ic_plat_detail)         // optional
                .into(imagePlat);

        // Inflate the layout for this fragment
        return rootView;
    }
    @Override
    public void onConfigurationChanged(Configuration newConfig)
    {
        super.onConfigurationChanged(newConfig);
    }
    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }
}