package fragments.fragmentForDrawer.detail.employe;

import android.app.Activity;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import activities.MainActivity;
import adapters.PlatItemCardViewAdapter;
import adapters.PlatJetonItemCardViewAdapter;
import kiadi.restaurant.R;
import metiers.dao.NourritureDAO;
import models.Plat;
import utilitaires.UtilitaireNombres;

/**
 * Created by ravelosonkiadisoa on 16/04/2016.
 */

/**
 * Fragment pour l'écran affichant les plats pouvant etre echangés
 */
public class PlatFragment extends Fragment
{
    private NourritureDAO nourritureDAO;
    private LinearLayoutManager lLayout;
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private MainActivity activity;
    /**
     * The Valeur jeton text.
     */
    public TextView valeurJetonText;
    /**
     * The Client id tag nfc.
     */
    public String clientIdTagNfc;
    /**
     * The Valeur jeton.
     */
    public float valeurJeton;
    //private NourritureDAO ndao;
    private RecyclerView.LayoutManager mLayoutManager;

    /**
     * Instantiates a new Plat fragment.
     */
    public PlatFragment()
    {
        //ndao = new NourritureDAO(MainActivity.context);
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View rootView = inflater.inflate(R.layout.plat_jeton_layout, container, false);
        activity = (MainActivity) getActivity();
        clientIdTagNfc = this.getArguments().getString("clientIdTagNfc");
        valeurJeton = this.getArguments().getFloat("valeur");
        nourritureDAO = new NourritureDAO(activity);
        mRecyclerView = (RecyclerView) rootView.findViewById(R.id.platRecyclerView);
        valeurJetonText = (TextView) rootView.findViewById(R.id.valeurJeton);
        valeurJetonText.setText(UtilitaireNombres.addThousandSeparator(valeurJeton)+"Ar");
        mRecyclerView.setHasFixedSize(true);
        lLayout = new LinearLayoutManager(activity);
        mAdapter = new PlatJetonItemCardViewAdapter(nourritureDAO.getListAllWithDetailByIDTypeAndTokenValue(nourritureDAO.plat_idType, valeurJeton), activity, this);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(lLayout);
        // Inflate the layout for this fragment
        return rootView;
    }
    @Override
    public void onConfigurationChanged(Configuration newConfig)
    {
        super.onConfigurationChanged(newConfig);
    }
    @Override
    public void onAttach(Activity activity)
    {
        super.onAttach(activity);
    }

    @Override
    public void onDetach()
    {
        super.onDetach();
    }
}
