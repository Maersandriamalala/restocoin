package fragments.fragmentForDrawer.detail.client;

import android.app.Activity;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import activities.MainActivity;
import adapters.PanierItemCardviewAdapter;
import kiadi.restaurant.R;
import listeners.BoutonPasserCommandeListener;
import models.Panier;
import utilitaires.UtilitaireView;

/**
 * Created by ravelosonkiadisoa on 16/03/2016.
 */

/**
 * Fragment pour l'écran affichant le panier du client
 */
public class PanierFragment extends Fragment
{
    /**
     * The L layout.
     */
    public LinearLayoutManager lLayout;
    /**
     * The M recycler view.
     */
    public RecyclerView mRecyclerView;
    /**
     * The M adapter.
     */
    public RecyclerView.Adapter mAdapter;
    /**
     * The M layout manager.
     */
    public RecyclerView.LayoutManager mLayoutManager;
    private MainActivity activity;
    private View rootView;
    private Bundle bundle;

    /**
     * Instantiates a new Panier fragment.
     */
//private final Bundle bundle = bundle1;
    public PanierFragment()
    {
        // Required empty public constructor
    }
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, final Bundle savedInstanceState)
    {
        activity = (MainActivity)getActivity();
        bundle = savedInstanceState;
        rootView = inflater.inflate(R.layout.panier_layout, container, false);
        if(Panier.isEmpty(activity))
        {
            rootView.findViewById(R.id.commandeItemRecycler).setVisibility(View.INVISIBLE);
            rootView.findViewById(R.id.btnPasserCommande).setVisibility(View.INVISIBLE);
            rootView.findViewById(R.id.btnPasserCommande2).setVisibility(View.INVISIBLE);
            rootView.findViewById(R.id.panierVideLayout).setVisibility(View.VISIBLE);
        }
        else
        {
            if(UtilitaireView.getOrientationScreen(getActivity()) == Configuration.ORIENTATION_LANDSCAPE)
            {
                rootView.findViewById(R.id.btnPasserCommande).setVisibility(View.GONE);
                rootView.findViewById(R.id.btnPasserCommande2).setVisibility(View.VISIBLE);
            }
            else if(UtilitaireView.getOrientationScreen(getActivity()) == Configuration.ORIENTATION_PORTRAIT)
            {
                rootView.findViewById(R.id.btnPasserCommande).setVisibility(View.VISIBLE);
                rootView.findViewById(R.id.btnPasserCommande2).setVisibility(View.GONE);
            }
            rootView.findViewById(R.id.panierVideLayout).setVisibility(View.INVISIBLE);
            mRecyclerView = (RecyclerView) rootView.findViewById(R.id.commandeItemRecycler);
            lLayout = new LinearLayoutManager(getActivity());
            mAdapter = new PanierItemCardviewAdapter(Panier.getListPlatInPanier(activity), activity, this);
            mRecyclerView.setAdapter(mAdapter);
            mRecyclerView.setHasFixedSize(true);
            mRecyclerView.setLayoutManager(lLayout);
            rootView.findViewById(R.id.btnPasserCommande).setOnClickListener(new BoutonPasserCommandeListener(mAdapter, activity, savedInstanceState));
            rootView.findViewById(R.id.btnPasserCommande2).setOnClickListener(new BoutonPasserCommandeListener(mAdapter, activity, savedInstanceState));
        }

        // Inflate the layout for this fragment
        return rootView;
    }

    /**
     * actualisation du panier
     */
    public void refresh()
    {
        rootView.findViewById(R.id.commandeItemRecycler).setVisibility(View.INVISIBLE);
        rootView.findViewById(R.id.btnPasserCommande).setVisibility(View.INVISIBLE);
        rootView.findViewById(R.id.btnPasserCommande2).setVisibility(View.INVISIBLE);
        rootView.findViewById(R.id.panierVideLayout).setVisibility(View.VISIBLE);
        activity.nbItemInPanier.setText(String.valueOf(Panier.getNbrItemInPanier(activity)));
    }
    @Override
    public void onAttach(Activity activity)
    {
        super.onAttach(activity);
    }

    @Override
    public void onDetach()
    {
        super.onDetach();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig)
    {
        super.onConfigurationChanged(newConfig);
        if(Panier.isEmpty(getActivity()))
        {
            rootView.findViewById(R.id.btnPasserCommande).setVisibility(View.GONE);
            rootView.findViewById(R.id.btnPasserCommande2).setVisibility(View.GONE);
        }
        else
        {
            if(newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE)
            {
                rootView.findViewById(R.id.btnPasserCommande).setVisibility(View.GONE);
                rootView.findViewById(R.id.btnPasserCommande2).setVisibility(View.VISIBLE);
            }
            else if(newConfig.orientation == Configuration.ORIENTATION_PORTRAIT)
            {
                rootView.findViewById(R.id.btnPasserCommande).setVisibility(View.VISIBLE);
                rootView.findViewById(R.id.btnPasserCommande2).setVisibility(View.GONE);
            }
        }


    }
}