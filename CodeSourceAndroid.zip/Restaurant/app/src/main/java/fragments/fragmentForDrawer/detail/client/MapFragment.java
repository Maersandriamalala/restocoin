package fragments.fragmentForDrawer.detail.client;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.support.design.widget.FloatingActionButton;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import activities.MainActivity;
import kiadi.restaurant.R;

/**
 * Created by ravelosonkiadisoa on 24/03/2016.
 */

/**
 * Fragment pour l'écran de geolocalisation
 */
public class MapFragment extends Fragment
{
    private MapView mapView;
    private GoogleMap map;
    private FloatingActionButton btnMessage;
    private View rootview;
    private MainActivity activity;

    /**
     * Instantiates a new Map fragment.
     */
    public MapFragment()
    {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        rootview = inflater.inflate(R.layout.map_layout, container, false);
        activity = (MainActivity) getActivity();
        // Gets the MapView from the XML layout and creates it
        mapView = (MapView) rootview.findViewById(R.id.mapView);
        mapView.onCreate(savedInstanceState);

        // Gets to GoogleMap from the MapView and does initialization stuff
        map = mapView.getMap();
        map.getUiSettings().setMyLocationButtonEnabled(true);
        map.setMyLocationEnabled(true);

        // Needs to call MapsInitializer before doing any CameraUpdateFactory calls
        MapsInitializer.initialize(activity);

        // Updates the location and zoom of the MapView
        LatLng itu = new LatLng(-18.985939, 47.532755);
        //-18.985939, 47.532755
        map.addMarker(new MarkerOptions().position(itu).title("Marque sur Restocoin"));
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(itu, 10));

        btnMessage = (FloatingActionButton)rootview.findViewById(R.id.btnMessage);
        btnMessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                activity.mainActivityManager.afficherContact();
            }
        });
        return rootview;
    }
    @Override
    public void onResume() {
        //mapView.onResume();
        super.onResume();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        // mapView.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        //  mapView.onLowMemory();
    }
    @Override
    public void onDetach()
    {
        super.onDetach();
    }
    //-18.985939, 47.532755
}
