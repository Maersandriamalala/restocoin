package fragments.fragmentForDrawer.detail.employe;

import android.app.Activity;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import java.util.ArrayList;
import java.util.List;

import activities.MainActivity;
import adapters.PlatItemCardViewAdapter;
import adapters.TableItemCardViewAdapter;
import kiadi.restaurant.R;
import models.Table;

/**
 * Created by ravelosonkiadisoa on 14/04/2016.
 */

/**
 * Fragment pour l'écran affichant les tables ayant passé commande
 */
public class TableCommandeFragment extends Fragment
{
    /**
     * The Root view.
     */
    public View rootView;
    /**
     * The M recycler view.
     */
    public RecyclerView mRecyclerView;
    /**
     * The L layout.
     */
    public LinearLayoutManager lLayout;
    /**
     * The Data set.
     */
    public List<Table> dataSet;
    /**
     * The M adapter.
     */
    public RecyclerView.Adapter mAdapter;
    private MainActivity activity;
    /**
     * The Commande vide layout.
     */
    public RelativeLayout commandeVideLayout;

    /**
     * Instantiates a new Table commande fragment.
     */
    public TableCommandeFragment()
    {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        rootView = inflater.inflate(R.layout.table_commande_layout, container, false);
        activity = (MainActivity) getActivity();
        //Inflate the layout for this fragment
        commandeVideLayout = (RelativeLayout) rootView.findViewById(R.id.commandeVideLayout);
        mRecyclerView = (RecyclerView) rootView.findViewById(R.id.tableRecyclerView);
        mRecyclerView.setHasFixedSize(true);
        lLayout = new LinearLayoutManager(activity);
        dataSet = new ArrayList<Table>();
        mAdapter = new TableItemCardViewAdapter(dataSet, activity, this);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(lLayout);
        activity.waitingDialog.show();
        activity.commandeService.getTableCommandes(this);
        return rootView;
    }

    @Override
    public void onAttach(Activity activity)
    {
        super.onAttach(activity);
    }

    @Override
    public void onDetach()
    {
        super.onDetach();
    }
}
