package fragments.fragmentAuthentification;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import activities.MainActivity;
import kiadi.restaurant.R;
import listeners.BoutonConnexionEmployeListener;

/**
 * Fragment pour la connexion d'un employé
 */
public class ConnexionEmployeFragment extends Fragment
{
    private Button btnConnexion;
    private MainActivity activity;
    private EditText username;
    private EditText password;

    /**
     * Instantiates a new Connexion employe fragment.
     */
    public ConnexionEmployeFragment()
    {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View rootView = inflater.inflate(R.layout.connexion_employe_fragment, container, false);
        activity = (MainActivity) getActivity();
        btnConnexion = (Button)rootView.findViewById(R.id.btnConnexion);
        username = (EditText)rootView.findViewById(R.id.nom);
        password = (EditText)rootView.findViewById(R.id.motDePasse);
        btnConnexion.setOnClickListener(new BoutonConnexionEmployeListener(activity, username, password));
        // Inflate the layout for this fragment
        return rootView;
    }

    @Override
    public void onAttach(Activity activity)
    {
        super.onAttach(activity);
    }

    @Override
    public void onDetach()
    {
        super.onDetach();
    }
}
