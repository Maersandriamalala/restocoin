
package fragments.fragmentAuthentification;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import activities.MainActivity;
import kiadi.restaurant.R;
import listeners.BoutonChoixTypeUserListener;

/**
 * Fragment pour le choix du type d'utilisateur
 */
public class ChoixTypeUserFragment extends Fragment
{
    private Button btnClient;
    private Button btnEmploye;
    private MainActivity activity;

    /**
     * Instantiates a new Choix type user fragment.
     */
    public ChoixTypeUserFragment()
    {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        activity = (MainActivity)getActivity();
        View rootView = inflater.inflate(R.layout.choix_type_user_layout, container, false);
        // Inflate the layout for this fragment
        btnClient = (Button)rootView.findViewById(R.id.btnClient);
        btnEmploye = (Button)rootView.findViewById(R.id.btnEmploye);

        btnClient.setOnClickListener(new BoutonChoixTypeUserListener("client", 11, activity));
        btnEmploye.setOnClickListener(new BoutonChoixTypeUserListener("employe", 12, activity));

        return rootView;
    }

    @Override
    public void onAttach(Activity activity)
    {
        super.onAttach(activity);
    }

    @Override
    public void onDetach()
    {
        super.onDetach();
    }
}


