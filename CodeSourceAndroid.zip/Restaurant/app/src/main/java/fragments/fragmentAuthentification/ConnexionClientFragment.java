package fragments.fragmentAuthentification;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import activities.MainActivity;
import kiadi.restaurant.R;
import listeners.BoutonCreerCompteListener;
import listeners.TextJePossedeDejaListener;

/**
 * Fragment pour la connexion d'un client
 */
public class ConnexionClientFragment extends Fragment
{
    private Button btnCreerCompte;
    private TextView textJePossedeDeja;
    private MainActivity activity;

    /**
     * Instantiates a new Connexion client fragment.
     */
    public ConnexionClientFragment()
    {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        activity = (MainActivity)getActivity();
        View rootView = inflater.inflate(R.layout.connexion_client_layout, container, false);
        final EditText nom = (EditText)rootView.findViewById(R.id.nom);
        textJePossedeDeja = (TextView)rootView.findViewById(R.id.textJePossedeDeja);
        btnCreerCompte = (Button)rootView.findViewById(R.id.btnCreerCompte);
        btnCreerCompte.setOnClickListener(new BoutonCreerCompteListener(activity, nom));
        textJePossedeDeja.setOnClickListener(new TextJePossedeDejaListener(activity));
        // Inflate the layout for this fragment
        return rootView;
    }

    @Override
    public void onAttach(Activity activity)
    {
        super.onAttach(activity);
    }

    @Override
    public void onDetach()
    {
        super.onDetach();
    }
}
