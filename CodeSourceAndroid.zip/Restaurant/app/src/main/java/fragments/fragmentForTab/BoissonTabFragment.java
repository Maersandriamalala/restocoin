package fragments.fragmentForTab;

import android.app.Activity;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import adapters.PlatItemCardViewAdapter;
import metiers.dao.NourritureDAO;
import kiadi.restaurant.R;
import activities.MainActivity;

/**
 * Created by ravelosonkiadisoa on 15/03/2016.
 */

/**
 * Fragment pour l'onglet plat
 */
public class BoissonTabFragment extends Fragment
{
    private NourritureDAO nourritureDAO;
    private LinearLayoutManager lLayout;
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private MainActivity activity;
    //private NourritureDAO ndao;
    private RecyclerView.LayoutManager mLayoutManager;

    /**
     * Instantiates a new Boisson tab fragment.
     */
    public BoissonTabFragment()
    {
        //ndao = new NourritureDAO(MainActivity.context);
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View rootView = inflater.inflate(R.layout.plat_tab_layout, container, false);
        activity = (MainActivity) getActivity();
        nourritureDAO = new NourritureDAO(activity);
        mRecyclerView = (RecyclerView) rootView.findViewById(R.id.platRecyclerView);
        mRecyclerView.setHasFixedSize(true);
        lLayout = new LinearLayoutManager(activity);
        mAdapter = new PlatItemCardViewAdapter(nourritureDAO.getListAllWithDetailByIDType(nourritureDAO.boisson_idType), activity);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(lLayout);
        // Inflate the layout for this fragment
        return rootView;
    }
    @Override
    public void onConfigurationChanged(Configuration newConfig)
    {
        super.onConfigurationChanged(newConfig);
    }
    @Override
    public void onAttach(Activity activity)
    {
        super.onAttach(activity);
    }

    @Override
    public void onDetach()
    {
        super.onDetach();
    }
}
