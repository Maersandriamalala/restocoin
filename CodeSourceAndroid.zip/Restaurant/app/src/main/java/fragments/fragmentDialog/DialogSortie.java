package fragments.fragmentDialog;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.os.Bundle;
import android.view.View;

import activities.MainActivity;
import kiadi.restaurant.R;
import listeners.BoutonCancelDialogListener;
import listeners.BoutonFinishActivityListener;

/**
 * Fragment pour le dialogue demandant si l'utilisateur veut vraiment quitter l'application
 */

public class DialogSortie extends DialogFragment implements View.OnClickListener
{
    private Bundle bundle;
    private MainActivity activity;

    /**
     * Instantiates a new Dialog sortie.
     */
    public DialogSortie()
    {
        super();
    }

    /**
     * Show dialog.
     *
     * @param b the b
     * @param a the a
     */
    public void showDialog(Bundle b, MainActivity a)
    {
        activity = a;
        Dialog d = this.onCreateDialog(b);
        d.show();
    }
    public void onClick(View v)
    {
        Dialog d = this.onCreateDialog(bundle);
        d.show();
    }
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setMessage(activity.getResources().getString(R.string.string_close_app))
            .setPositiveButton(activity.getResources().getString(R.string.string_yes), new BoutonFinishActivityListener(activity))
            .setNegativeButton(activity.getResources().getString(R.string.string_no), new BoutonCancelDialogListener(activity));
        return builder.create();
    }
}
