package fragments.fragmentDialog;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.RadioGroup;

import activities.MainActivity;
import kiadi.restaurant.R;
import listeners.BoutonCancelDialogListener;
import listeners.BoutonPositifDialogPreferenceListener;

/**
 * Fragment pour le dialogue demandant la préférence de service
 */
public class AskingPreferenceFragment extends DialogFragment implements View.OnClickListener
{
    private Bundle bundle;
    private MainActivity activity;
    private View rootView;
    private RadioGroup radioGroup;

    /**
     * Instantiates a new Asking preference fragment.
     */
    public AskingPreferenceFragment()
    {
        super();
    }

    /**
     * Show dialog.
     *
     * @param b the b
     * @param a the a
     */
    public void showDialog(Bundle b, MainActivity a)
    {
        activity = a;
        Dialog d = this.onCreateDialog(b);
        d.show();
    }
    public void onClick(View v)
    {
        Dialog d = this.onCreateDialog(bundle);
        d.show();
    }
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState)
    {
        LayoutInflater inflater = activity.getLayoutInflater();
        rootView = inflater.inflate(R.layout.asking_preference_layout, null);
        radioGroup = (RadioGroup)rootView.findViewById(R.id.radioGroup);
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setView(rootView);
        builder.setTitle(activity.getResources().getString(R.string.preference_service_title));
        builder.setPositiveButton(activity.getResources().getString(R.string.valider), new BoutonPositifDialogPreferenceListener(activity, radioGroup, rootView))
                .setNegativeButton(activity.getResources().getString(R.string.annuler), new BoutonCancelDialogListener(activity));
        return builder.create();
    }
}
